package sinosoft.project.cctv.service;

import java.io.CharArrayReader;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.input.SAXBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import sinosoft.framework.core.base.BaseServiceImpl;
import sinosoft.framework.core.beans.PageParam;
import sinosoft.framework.core.beans.PageVo;
import sinosoft.framework.core.utils.FDate;
import sinosoft.platform.riskType.beans.Point;
import sinosoft.platform.utils.DictUtil;
import sinosoft.platform.utils.MapContext;
import sinosoft.platform.utils.PageUtil;
import sinosoft.platform.utils.Util;
import sinosoft.platform.webservice.axis2.util.Axis2Util;
import sinosoft.platform.webservice.infservice.EasyScanInterface;
import sinosoft.project.cctv.dao.CctvMapper;
import sinosoft.project.company.Vo.CompanyVo;
import sinosoft.project.dao.CompanyMapper;
import sinosoft.project.dao.DynastyCorporationMapper;
import sinosoft.project.entity.Company;
import sinosoft.project.entity.DynastyCorporation;

@Service("cctvService")
@Scope("prototype")
public class CctvService extends BaseServiceImpl{

	private Logger logger = LoggerFactory.getLogger(CctvService.class);

	@Resource
	private CctvMapper cctvMapper;
	public String save(CCtv cCtv) {
		String doccode="CCTV"+cCtv.getMangcode()+"-"+cCtv.getNo()+"-"+FDate.formatDate(new Date(), "yyyyMMddhhmmss");
		doccode.substring(3);
		CCtv cCtv2 = cctvMapper.cxvProduct(cCtv.getRisktypeName());
		String Xml="<TRANSDATA>"
				+ "<TRANSBODY>"
				+ "<VIDEO>"
				+ "<ISFIRSTBUY>0</ISFIRSTBUY>"
				+ "<DOCCODE>"+doccode+"</DOCCODE>"//业务流水号
				+ "<NUMPAGES></NUMPAGES>"
				+ "<STARTSCANDATE>"+FDate.formatDate(cCtv.getStartscandateStr(), "yyyy-MM-dd HH:mm:ss")+"</STARTSCANDATE>"
				+ "<BANKNETWORK></BANKNETWORK>"
				+ "<APPNTSEX>0</APPNTSEX><ISADVANCEDAGE>0</ISADVANCEDAGE>"
				+ "<APPNTNO>"+cCtv.getAppntno()+"</APPNTNO>"//客户号
				+ "<AGENTID>"+cCtv.getAgentid()+"</AGENTID>"//员工号
				+ "<AGENTNAME>001的</AGENTNAME>"
				+ "<RECDATE>"+FDate.formatDate(new Date(), "yyyy-MM-dd")+"</RECDATE>"
				+ "<UPLOADDATE>"+FDate.formatDate(new Date(), "yyyy-MM-dd")+"</UPLOADDATE>"
				+ "<BUSINESSNO>"+Util.getUUID()+"</BUSINESSNO>"
				+ "<APPNTNAME></APPNTNAME>"
				+ "<TYPE>A</TYPE>"
				+ "<FINANCEDCOMCODE>"+cCtv.getMangcode()+"</FINANCEDCOMCODE>"//理财室网点编号
				+ "<RISKTYPECODE>cpbh0930</RISKTYPECODE>"	
				+ "<PAGES>"
					+ "<PAGE>"
						+ "<PAGENAME>"+cCtv.getPathname()+"</PAGENAME>"
						+ "<FILESIZE></FILESIZE>"
						+ "<RECDATE>"+FDate.formatDate(new Date(), "yyyy-MM-dd")+"</RECDATE>"
						+ "<RECDURATION></RECDURATION>"
						+ "<PAGESUFFIX></PAGESUFFIX>"
						+ "<RECTIME>"+FDate.formatDate(new Date(), "HH:mm:ss")+"</RECTIME>"
						+ "<FILETYPE>6</FILETYPE>"
						+ "<URL>"+cCtv.getPath()+"</URL>"
					+ "</PAGE>"
					+ "<PAGECOUNT>1</PAGECOUNT>"
				+ "</PAGES>"
					+ "<COMCODE>"+cCtv.getMangcode()+"</COMCODE>"//理财室网点
					+ "<POLAPPLYDATE></POLAPPLYDATE>"
					+ "<RECTIME>"+FDate.formatDate(new Date(), "HH:mm:ss")+"</RECTIME><APPNTAGE>1</APPNTAGE>"
					+ "<ENDSCANDATE>"+FDate.formatDate(cCtv.getEndscandateStr(), "yyyy-MM-dd HH:mm:ss")+"</ENDSCANDATE>"
					+ "<COMPANY>24001</COMPANY>"
					+ "<NUMPRODUCTS>1</NUMPRODUCTS>"
					+ "<FINANCEDCODE>"+cCtv.getNo()+"</FINANCEDCODE>"//理财室编号
					+ "<HOSTNAME>COS</HOSTNAME><CHANNEL>1</CHANNEL><BANKCODE>110000</BANKCODE>"
					+ "<UPLOADTIME>"+FDate.formatDate(new Date(), "HH:mm:ss")+"</UPLOADTIME>"
					+ "<PRODUCTS>"
						+ "<PRODUCT>"
							+ "<PRODUCTTYPECODE>"+cCtv2.getProducttypecode()+"</PRODUCTTYPECODE>"
							+ "<BUSINESSTYPENAME>"+cCtv2.getBusinesstype()+"</BUSINESSTYPENAME>"
							+ "<INVESTMENT></INVESTMENT>"
							+ "<BUSINESSTYPECODE>"+cCtv2.getBusinesstypeno()+"</BUSINESSTYPECODE>"
							+ "<PRODUCTTYPENAME></PRODUCTTYPENAME>"
							+ "<PRODUCTNAME>"+cCtv2.getProductname()+"</PRODUCTNAME>"
							+ "<PRODUCTCODE>"+cCtv.getRisktypeName()+"</PRODUCTCODE>"
							+ "</PRODUCT>"
					+ "</PRODUCTS>"
						+ "<ISFIXEDPERSON>0</ISFIXEDPERSON>"
						+ "<APPNTBIRTHDAY></APPNTBIRTHDAY>"
						+ "<APPNTRISKGRADE>6</APPNTRISKGRADE>"
				+ "</VIDEO></TRANSBODY><TRANSHEAD><TRANSCODE>82006</TRANSCODE><VERSION>1.0</VERSION><TRANUSER>admin</TRANUSER><TRANPASSWD>111111</TRANPASSWD><BUSINESSNO>f89c8c4e-47a8-4aeb-828b-67a287411468</BUSINESSNO><SYSCODE>002</SYSCODE><COMPANY>24001</COMPANY></TRANSHEAD></TRANSDATA>";
		EasyScanInterface easyScanInterface = new EasyScanInterface();
		try {
			String res = easyScanInterface.easyScanInterface(Xml);

			//解析结果
			SAXBuilder saxBuilder = new SAXBuilder();
			Document document = saxBuilder.build(new CharArrayReader(res.toCharArray()));
			Element rootElement = document.getRootElement();
			Element TRANSBODY = rootElement.getChild("TRANSBODY");
			Element TRANSRESULT = TRANSBODY.getChild("TRANSRESULT");
			String RETURNCODE =  TRANSRESULT.getChildText("RETURNCODE");
			String MESSAGE =  TRANSRESULT.getChildText("MESSAGE");
			logger.info(RETURNCODE+"======"+MESSAGE);
			return  RETURNCODE+"======"+MESSAGE;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "操作失败";
		}
	}
	public int selectVideoMain(String doccode) {
		
		return cctvMapper.selectVideoMain(doccode);
	}
	public int selectVideoMainCount(String doccode) {
		return cctvMapper.selectVideoMainCount(doccode);
	}
	public String getInterfaceAddress(String string) {
		
		return cctvMapper.getInterfaceAddress(string);
	}
}
