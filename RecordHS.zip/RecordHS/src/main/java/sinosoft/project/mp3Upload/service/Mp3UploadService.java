package sinosoft.project.mp3Upload.service;

import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import sinosoft.framework.core.base.BaseServiceImpl;
import sinosoft.framework.core.beans.PageParam;
import sinosoft.framework.core.beans.PageVo;
import sinosoft.framework.core.utils.FDate;
import sinosoft.platform.riskType.beans.Describe;
import sinosoft.platform.riskType.beans.Point;
import sinosoft.platform.utils.DictUtil;
import sinosoft.platform.utils.MapContext;
import sinosoft.platform.utils.PageUtil;
import sinosoft.platform.utils.Result;
import sinosoft.platform.utils.Util;
import sinosoft.platform.webservice.axis2.util.Axis2Util;
import sinosoft.platform.webservice.infservice.EasyScanInterface;
import sinosoft.project.cctv.dao.CctvMapper;
import sinosoft.project.company.Vo.CompanyVo;
import sinosoft.project.dao.CompanyMapper;
import sinosoft.project.dao.DynastyCorporationMapper;
import sinosoft.project.entity.Company;
import sinosoft.project.entity.DynastyCorporation;
import sinosoft.project.mp3Upload.dao.Mp3UploadMapper;

/**
 * @author 1
 */
@Service("mp3UploadService")
@Scope("prototype")
public class Mp3UploadService extends BaseServiceImpl{	
	@Resource
	private Mp3UploadMapper mp3UploadMapper;
	public Result<Object> saveMp3(Describe mp3)  {
		Result<Object> pv = new Result<Object>();
		/*try {*/
			Describe a_describe=new Describe();
			a_describe.setPath(mp3.getPath());
			if(a_describe.getPath()==null){
				a_describe.setIsUpload("0");
			}else if(a_describe.getPath()!=null){
				a_describe.setIsUpload("1");
			}
			a_describe.setDescribeId(mp3.getDescribeId());
			a_describe.setModifyDatetime(new Date());
			mp3UploadMapper.updateMp3(a_describe);
		/*} catch (DuplicateKeyException e) {
			pv.success=false;
			pv.msg="已存在该数据";
		}*/
		return pv;
	}
	
	public String selectPathById(String describeId) {
		return mp3UploadMapper.selectPathById(describeId);
	}
}
