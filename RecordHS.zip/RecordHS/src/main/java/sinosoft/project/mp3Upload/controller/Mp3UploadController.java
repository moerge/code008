package sinosoft.project.mp3Upload.controller;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import sinosoft.framework.core.base.BaseControllerImpl;
import sinosoft.platform.riskType.beans.Describe;
import sinosoft.project.cctv.service.SqlUtil;
import sinosoft.project.cctv.service.WebConfig;
import sinosoft.project.mp3Upload.service.Mp3Upload;
import sinosoft.project.mp3Upload.service.Mp3UploadService;
import sinosoft.platform.utils.Util;
/**
 * 用例conroller
 * 
 * @date 2016年07月20日 下午17:44:49
 * @author zhenglei
 *
 */
@Controller("mp3UploadController")
@Scope("prototype")
@RequestMapping("/mp3Upload")
public class Mp3UploadController extends BaseControllerImpl {
	
	@Resource
	private Mp3UploadService mp3UploadService;
	@Resource
	private WebConfig webConfig;
	// ---------------------------------------用例-----start-----------------------------------------
	@RequestMapping(value = "/addFinancing")
	public @ResponseBody String addFinancing(HttpServletRequest request,@RequestParam(value="id")String id, @RequestParam(value="contractFile")MultipartFile contractFile){		
	        //在这里对获取到的文件做一些业务上的逻辑操作就可以了			
			String dir = webConfig.getInterface("mp3");
			if(dir==null){
				return "上传失败，获取保存路径失败";
			}
			if(contractFile==null){
				return "上传失败,请确保上传文件";
			}
	        String fileName = contractFile.getOriginalFilename();
	        if(fileName!=null&&!"".equals(fileName)&&fileName.length()>0&&fileName.contains(".")){
	        	String suffix = fileName.substring(fileName.lastIndexOf("."));
	        	if(".mp3".equalsIgnoreCase(suffix)){
	        		String oldName = fileName.substring(0,fileName.lastIndexOf("."));
					String path = uploadMultipartFile(contractFile, dir,oldName + "_" + id);
					if("上传失败".equals(path)){
						return "上传失败";
					}
	    			Describe mp3 = new Describe();
	    			mp3.setPath(path);
	    			mp3.setDescribeId(id);
	    			mp3UploadService.saveMp3(mp3);
	    	        return "上传成功";
	    			
	        	}else{
	        		
	        		 return "上传失败,请确保文件是MP3文件";
	        	}
	        }else{
	        	
	        	return "上传失败,请上传文件！";
	        }
	        
	        
	        
	        
	        
	        
			
	}
	/**
	 * struts或springmvc上传
	 * 
	 * @param file
	 *            上传文件
	 * @param dir
	 *            存放的目录
	 * @param id 
	 * @return
	 */
	private static String uploadMultipartFile(MultipartFile file, String dir, String id) {
		if(id==null || dir ==null ){
			return "上传失败";
		}
		// 判断文件是否为空
		if (!file.isEmpty()) {
			try {
				// 保存的文件路径(如果用的是Tomcat服务器，文件会上传到\\%TOMCAT_HOME%\\webapps\\YourWebProject\\upload\\文件夹中
				// )
				// String filePath = request.getSession().getServletContext()
				// .getRealPath("/") + "upload/" + file.getOriginalFilename();
				String fileName = file.getOriginalFilename();
				String suffix = fileName.substring(fileName.lastIndexOf("."));
				String uuid = UUID.randomUUID().toString().replace("-", "").replace("_", "");
				dir = StringUtils.removeEnd(dir, "/");
				dir = StringUtils.removeEnd(dir, "//");
				dir = StringUtils.removeEnd(dir, "\\");
				String name = uuid + suffix;
				/*String filePath = dir + File.separator + id+name;*/
				String filePath =dir+ File.separator +id+name;
				File saveDir = new File(filePath);
				if (!saveDir.getParentFile().exists()) {
					// saveDir.getParentFile().mkdirs();
					File f = saveDir.getParentFile();
					if (!f.exists()) {
						f.mkdirs();
					}
				}
				// 转存文件
				file.transferTo(saveDir);
				String res = id+name;
				return res;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return "上传失败";
	}
	
	/**
	 * 下载mp3
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/downloadMP3", method = RequestMethod.GET)
	public String downloadMP3(@RequestParam(value="key")String id, HttpServletRequest request) throws Exception {
		String dir = webConfig.getInterface("mp3");
		String filename = mp3UploadService.selectPathById(id);
		String path = dir+File.separator+filename;
		File file = new File(path);
		Util.download(filename, file);
		return "";
	}
	public static void main(String[] args) {
		File f = new File("103-192842baf83404813b9de9c0b9cea471a.jpg");
		System.out.println(f.getName());
		
	}
	
	
}
