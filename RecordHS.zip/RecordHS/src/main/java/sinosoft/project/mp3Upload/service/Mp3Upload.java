package sinosoft.project.mp3Upload.service;

import java.util.Date;

public class Mp3Upload {
	private String path;
	private String pathname;
	private Date startscandateStr;
	private Date endscandateStr;	
	
	public Date getStartscandateStr() {
		return startscandateStr;
	}
	public void setStartscandateStr(Date startscandateStr) {
		this.startscandateStr = startscandateStr;
	}
	public Date getEndscandateStr() {
		return endscandateStr;
	}
	public void setEndscandateStr(Date endscandateStr) {
		this.endscandateStr = endscandateStr;
	}		
	public String getPathname() {
		return pathname;
	}
	public void setPathname(String pathname) {
		this.pathname = pathname;
	}
	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
	
}
