package sinosoft.project.mp3Upload.dao;

import sinosoft.platform.riskType.beans.Describe;

public interface Mp3UploadMapper {
	String getInterface(String type);
	
	int updateMp3(Describe mp3);
	
	String selectPathById(String describeId);
   
}

