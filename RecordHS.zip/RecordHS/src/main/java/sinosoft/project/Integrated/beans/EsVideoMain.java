package sinosoft.project.Integrated.beans;

import java.util.Date;

public class EsVideoMain {
    private String docid;

    private String doccode;

    private String businessno;

    private String beforebusinessno;

    private String channel;

    private String busstype;

    private String subtype;

    private String type;

    private String numpages;

    private String agentid;

    private String agentname;

    private String company;

    private String risktypecode;

    private String appntname;

    private String appntidtype;

    private String appntidno;

    private Date appntbirthday;

    private String appntadress;

    private String appntsex;

    private String appntage;

    private String insuredname;

    private String insuredtype;

    private String insuredno;

    private Date insuredbirthday;

    private String insuredadress;

    private String insuredsex;

    private String insuredage;

    private Date polapplydate;

    private String status;

    private String verdict;

    private String qcoperator;

    private Date createDate;

    private Date modifyDate;

    private String operator;

    public String getDocid() {
        return docid;
    }

    public void setDocid(String docid) {
        this.docid = docid == null ? null : docid.trim();
    }

    public String getDoccode() {
        return doccode;
    }

    public void setDoccode(String doccode) {
        this.doccode = doccode == null ? null : doccode.trim();
    }

    public String getBusinessno() {
        return businessno;
    }

    public void setBusinessno(String businessno) {
        this.businessno = businessno == null ? null : businessno.trim();
    }

    public String getBeforebusinessno() {
        return beforebusinessno;
    }

    public void setBeforebusinessno(String beforebusinessno) {
        this.beforebusinessno = beforebusinessno == null ? null : beforebusinessno.trim();
    }

    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel == null ? null : channel.trim();
    }

    public String getBusstype() {
        return busstype;
    }

    public void setBusstype(String busstype) {
        this.busstype = busstype == null ? null : busstype.trim();
    }

    public String getSubtype() {
        return subtype;
    }

    public void setSubtype(String subtype) {
        this.subtype = subtype == null ? null : subtype.trim();
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type == null ? null : type.trim();
    }

    public String getNumpages() {
        return numpages;
    }

    public void setNumpages(String numpages) {
        this.numpages = numpages == null ? null : numpages.trim();
    }

    public String getAgentid() {
        return agentid;
    }

    public void setAgentid(String agentid) {
        this.agentid = agentid == null ? null : agentid.trim();
    }

    public String getAgentname() {
        return agentname;
    }

    public void setAgentname(String agentname) {
        this.agentname = agentname == null ? null : agentname.trim();
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company == null ? null : company.trim();
    }

    public String getRisktypecode() {
        return risktypecode;
    }

    public void setRisktypecode(String risktypecode) {
        this.risktypecode = risktypecode == null ? null : risktypecode.trim();
    }

    public String getAppntname() {
        return appntname;
    }

    public void setAppntname(String appntname) {
        this.appntname = appntname == null ? null : appntname.trim();
    }

    public String getAppntidtype() {
        return appntidtype;
    }

    public void setAppntidtype(String appntidtype) {
        this.appntidtype = appntidtype == null ? null : appntidtype.trim();
    }

    public String getAppntidno() {
        return appntidno;
    }

    public void setAppntidno(String appntidno) {
        this.appntidno = appntidno == null ? null : appntidno.trim();
    }

    public Date getAppntbirthday() {
        return appntbirthday;
    }

    public void setAppntbirthday(Date appntbirthday) {
        this.appntbirthday = appntbirthday;
    }

    public String getAppntadress() {
        return appntadress;
    }

    public void setAppntadress(String appntadress) {
        this.appntadress = appntadress == null ? null : appntadress.trim();
    }

    public String getAppntsex() {
        return appntsex;
    }

    public void setAppntsex(String appntsex) {
        this.appntsex = appntsex == null ? null : appntsex.trim();
    }

    public String getAppntage() {
        return appntage;
    }

    public void setAppntage(String appntage) {
        this.appntage = appntage == null ? null : appntage.trim();
    }

    public String getInsuredname() {
        return insuredname;
    }

    public void setInsuredname(String insuredname) {
        this.insuredname = insuredname == null ? null : insuredname.trim();
    }

    public String getInsuredtype() {
        return insuredtype;
    }

    public void setInsuredtype(String insuredtype) {
        this.insuredtype = insuredtype == null ? null : insuredtype.trim();
    }

    public String getInsuredno() {
        return insuredno;
    }

    public void setInsuredno(String insuredno) {
        this.insuredno = insuredno == null ? null : insuredno.trim();
    }

    public Date getInsuredbirthday() {
        return insuredbirthday;
    }

    public void setInsuredbirthday(Date insuredbirthday) {
        this.insuredbirthday = insuredbirthday;
    }

    public String getInsuredadress() {
        return insuredadress;
    }

    public void setInsuredadress(String insuredadress) {
        this.insuredadress = insuredadress == null ? null : insuredadress.trim();
    }

    public String getInsuredsex() {
        return insuredsex;
    }

    public void setInsuredsex(String insuredsex) {
        this.insuredsex = insuredsex == null ? null : insuredsex.trim();
    }

    public String getInsuredage() {
        return insuredage;
    }

    public void setInsuredage(String insuredage) {
        this.insuredage = insuredage == null ? null : insuredage.trim();
    }

    public Date getPolapplydate() {
        return polapplydate;
    }

    public void setPolapplydate(Date polapplydate) {
        this.polapplydate = polapplydate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status == null ? null : status.trim();
    }

    public String getVerdict() {
        return verdict;
    }

    public void setVerdict(String verdict) {
        this.verdict = verdict == null ? null : verdict.trim();
    }

    public String getQcoperator() {
        return qcoperator;
    }

    public void setQcoperator(String qcoperator) {
        this.qcoperator = qcoperator == null ? null : qcoperator.trim();
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getModifyDate() {
        return modifyDate;
    }

    public void setModifyDate(Date modifyDate) {
        this.modifyDate = modifyDate;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator == null ? null : operator.trim();
    }
}