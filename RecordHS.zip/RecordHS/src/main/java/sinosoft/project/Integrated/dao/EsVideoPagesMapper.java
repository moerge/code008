package sinosoft.project.Integrated.dao;

import java.util.List;

import sinosoft.project.Integrated.beans.EsVideoPages;
import sinosoft.project.qcac.vo.VideoMainVo;

public interface EsVideoPagesMapper {
    int deleteByPrimaryKey(String pageid);

    int insert(EsVideoPages record);

    int insertSelective(EsVideoPages record);

    EsVideoPages selectByPrimaryKey(String pageid);

    int updateByPrimaryKeySelective(EsVideoPages record);

    int updateByPrimaryKey(EsVideoPages record);
    
    EsVideoPages selectById(String docId);
    
    /*List<EsVideoMainVo> selectByFilter(MapContext map);*/
    
    EsVideoPages  queryPagesHis(String docid);
	
    EsVideoPages  queryPages(String docid);
    
	VideoMainVo selectRec(String docid);

	List<VideoMainVo> selectImg(String docid);

	List<VideoMainVo> selectOtherDocuments(String docid);

	List<VideoMainVo> selectOtherImg(String docid);
	
	
}