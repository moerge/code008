package sinosoft.project.Integrated.vo;

import java.util.Date;

public class QcBackVo {	
	public static final String SEQ_QCSECOND = "SEQ_QCSECOND";
	private String id;
	private String doccode;
	private String status;
	private String verdict;
	private String operator;
	private String businessno;
    private Date createDatetime;//创建时间
    private Date modifyDatetime;//修改时间
    private Date backdatetime;//回退时间
    private String qcoperator;//质检人
    private String mangcode;
    private String operation;
    
    public String getOperation() {
		return operation;
	}
	public void setOperation(String operation) {
		this.operation = operation;
	}
	private String inspectdate;
    private String incode;
    
    private String backtype;
    
    private String backremarks;
    
    
	public String getInspectdate() {
		return inspectdate;
	}
	public void setInspectdate(String inspectdate) {
		this.inspectdate = inspectdate;
	}
	public String getMangcode() {
		return mangcode;
	}
	public void setMangcode(String mangcode) {
		this.mangcode = mangcode;
	}
	public String getIncode() {
		return incode;
	}
	public void setIncode(String incode) {
		this.incode = incode;
	}
	public String getBacktype() {
		return backtype;
	}
	public void setBacktype(String backtype) {
		this.backtype = backtype;
	}
	public String getBackremarks() {
		return backremarks;
	}
	public void setBackremarks(String backremarks) {
		this.backremarks = backremarks;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getDoccode() {
		return doccode;
	}
	public void setDoccode(String doccode) {
		this.doccode = doccode;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getVerdict() {
		return verdict;
	}
	public void setVerdict(String verdict) {
		this.verdict = verdict;
	}
	public String getOperator() {
		return operator;
	}
	public void setOperator(String operator) {
		this.operator = operator;
	}
	public String getBusinessno() {
		return businessno;
	}
	public void setBusinessno(String businessno) {
		this.businessno = businessno;
	}

	public Date getCreateDatetime() {
		return createDatetime;
	}
	public void setCreateDatetime(Date createDatetime) {
		this.createDatetime = createDatetime;
	}
	public Date getModifyDatetime() {
		return modifyDatetime;
	}
	public void setModifyDatetime(Date modifyDatetime) {
		this.modifyDatetime = modifyDatetime;
	}
	public Date getBackdatetime() {
		return backdatetime;
	}
	public void setBackdatetime(Date backdatetime) {
		this.backdatetime = backdatetime;
	}
	public String getQcoperator() {
		return qcoperator;
	}
	public void setQcoperator(String qcoperator) {
		this.qcoperator = qcoperator;
	}
	public static String getSeqQcsecond() {
		return SEQ_QCSECOND;
	}


}
