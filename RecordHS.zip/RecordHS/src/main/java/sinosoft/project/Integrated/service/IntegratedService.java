package sinosoft.project.Integrated.service;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;

import sinosoft.framework.core.base.BaseServiceImpl;
import sinosoft.framework.core.beans.PageParam;
import sinosoft.framework.core.beans.PageVo;
import sinosoft.framework.core.utils.FDate;
import sinosoft.platform.config.isholiday.util.HolidayUtil;
import sinosoft.platform.permission.organization.entity.Organ;
import sinosoft.platform.permission.organization.util.OrganUtil;
import sinosoft.platform.permission.user.beans.OrgUser;
import sinosoft.platform.permission.user.beans.UserRole;
import sinosoft.platform.permission.user.dao.OrgUserMapper;
import sinosoft.platform.permission.user.dao.UserRoleMapper;
import sinosoft.platform.utils.B64Util;
import sinosoft.platform.utils.DictUtil;
import sinosoft.platform.utils.ExcelPoiUtil;
import sinosoft.platform.utils.MapContext;
import sinosoft.platform.utils.PageUtil;
import sinosoft.platform.utils.Result;
import sinosoft.platform.utils.Util;
import sinosoft.project.Integrated.beans.EsVideoMain;
import sinosoft.project.Integrated.beans.EsVideoPages;
import sinosoft.project.Integrated.dao.EsVideoMainMapper;
import sinosoft.project.Integrated.dao.EsVideoPagesMapper;
import sinosoft.project.Integrated.vo.EsVideoMainVo;
import sinosoft.project.Integrated.vo.QcBackVo;
import sinosoft.project.dao.QcMainMapper;
import sinosoft.project.dao.TroubleInfosMapper;
import sinosoft.project.dao.VideoMainMapper;
import sinosoft.project.dockingface.easyrecordinfos.EasyRecordinfosBean;
import sinosoft.project.dockingface.easyrecordinfos.EasyRecordinfosService;
import sinosoft.project.dockingface.util.WebSocketFace;
import sinosoft.project.entity.ProductManage;
import sinosoft.project.entity.QcMain;
import sinosoft.project.entity.TroubleInfos;
import sinosoft.project.entity.VideoMain;
import sinosoft.project.overtime.dao.QcOvertimeMapper;
import sinosoft.project.qcac.vo.QcMainVo;
import sinosoft.project.qcac.vo.VideoMainVo;
import sinosoft.project.video.service.VideoPagesService;


@Service("integratedService")
@Scope("prototype")
public class IntegratedService extends BaseServiceImpl{

	private static final Logger logger = LoggerFactory.getLogger(IntegratedService.class);

	@Resource
	private EsVideoMainMapper esVideoMainMapper;
	@Resource
	private EsVideoPagesMapper esVideoPagesMapper;//注入dao
	@Resource
	private QcMainMapper qcMainMapper;
	@Resource
	private VideoMainMapper videoMainMapper;
	@Resource
	private TroubleInfosMapper troubleInfosMapper;
	@Resource
	private EasyRecordinfosService easyRecordinfosService;
	@Resource
	private VideoPagesService videoPagesService;
	@Resource
	private QcOvertimeMapper qcOvertimeMapper; //注入dao
	@Resource
	private UserRoleMapper userRoleMapper;//用户与角色关联的dao
	@Resource
	private OrgUserMapper orgUserMapper;//用户机构关联
	public PageVo<EsVideoMainVo> queryAllPage(EsVideoMainVo esVideoMainVo, PageParam pageParam) throws Exception {
		if(esVideoMainVo.getEndScanDate()!=null){
			int day=1000*60*60*24-1;
			esVideoMainVo.setEndScanDate(new Date(esVideoMainVo.getEndScanDate().getTime()+day));
		}
		String userNo = this.getUserSession().getUserNo();
		String RuleName = userRoleMapper.selectRuleNameByUserId(userNo);
		List<String> rulelist = new ArrayList<String>();

		//用户和网点关联的对象
		List<OrgUser> selectByuserId = orgUserMapper.selectByuserId(userNo);
		if(selectByuserId!=null&&selectByuserId.size()>0){
			//查ld_code表中对总网点的设置bigOrganizationCode
			String bigOrganizationCode = userRoleMapper.selectBigOrganizationCode();//查询总行网点编码
			String agentRuleName = userRoleMapper.selectRuleNamefromldcode();
			if(bigOrganizationCode.equals((selectByuserId.get(0).getOrganizationCode()))){

			}else if(agentRuleName.equals(RuleName)){
				if("".equals(esVideoMainVo.getAgentid())){
					esVideoMainVo.setAgentid(userNo);
				}else{
					esVideoMainVo.setAgentid("客户经理查不到其他客户经理的");
				}
			}else{
				esVideoMainVo.setMangcode(selectByuserId.get(0).getOrganizationCode());
			}
		}else{
			List<EsVideoMainVo> list2=new ArrayList<EsVideoMainVo>();
			pageParam.setRows(0);
			pageParam.setTotalCount(0);
			return  PageUtil.getPage(list2, pageParam);
		}


		/*
		 * rulelist = userRoleMapper.selectRuleNamefromldcode();
		 * for (int i = 0; i < rulelist.size(); i++) {
			String[] split = rulelist.get(i).split(",");
			if(split[1].equals(RuleName)&&"hangzhangrulename".equals(split[0])){
				break;
			}else if(split[1].equals(RuleName)&&"fenhangrulename".equals(split[0])){
				List<OrgUser> selectByuserId = orgUserMapper.selectByuserId(userNo);
				if(selectByuserId!=null&&selectByuserId.size()>0){
					esVideoMainVo.setMangcode(selectByuserId.get(0).getOrganizationCode());
				break;
				}
			}
			if(i==rulelist.size()-1){
				if("".equals(esVideoMainVo.getAgentid())){
					esVideoMainVo.setAgentid(userNo);
				}else{
					esVideoMainVo.setAgentid("客户经理查不到其他客户经理的");
				}

			}
		}*/
		List<EsVideoMainVo> list1=new ArrayList<EsVideoMainVo>();
				MapContext map = MapContext.newOne();
				String status = esVideoMainVo.getStatus();
				if("0".equals(status)){
					esVideoMainVo.setStatus("");
					esVideoMainVo.setStatus2("1");
				}
				if("2".equals(status)){
					esVideoMainVo.setStatus("");
					esVideoMainVo.setStatus3("1");
				}
				if("3".equals(status)){
					esVideoMainVo.setStatus("");
					esVideoMainVo.setStatus4("1");
				}
				if("4".equals(status)){
					esVideoMainVo.setStatus("");
					esVideoMainVo.setStatus5("1");
				}
				if("5".equals(status)){
					esVideoMainVo.setStatus("");
					esVideoMainVo.setStatus6("1");
				}
				if("6".equals(status)){
					esVideoMainVo.setStatus("");
					esVideoMainVo.setStatus8("1");
				}
				if("11".equals(status)){
					esVideoMainVo.setStatus("");
					esVideoMainVo.setStatus7("1");
				}
				map.put("esVideoMainVo", esVideoMainVo);
				map.put(PageUtil.PAGEPARAM, pageParam);
				list1 =esVideoMainMapper.selectByFilter(map);
				for (EsVideoMainVo esVideoMainVo2 : list1) {
					if(status!=null&&"0".equals(status)){
							esVideoMainVo2.setStatus("0");
					}else if(status!=null&&"2".equals(status)){
							esVideoMainVo2.setStatus("2");
					}else if(status!=null&&"3".equals(status)){
						esVideoMainVo2.setStatus("3");
					}else if(status!=null&&"4".equals(status)){
						esVideoMainVo2.setStatus("4");
					}else if(status!=null&&"5".equals(status)){
						esVideoMainVo2.setStatus("5");
					}else if(status!=null&&"6".equals(status)){
						esVideoMainVo2.setStatus("6");
					}else if(status!=null&&"11".equals(status)){
						esVideoMainVo2.setStatus("11");
					}else{
						/*if("7".equals(esVideoMainVo2.getStatus())){
							esVideoMainVo2.setStatus("10");
						}else if("6".equals(esVideoMainVo2.getStatus())){
							esVideoMainVo2.setStatus("9");
						}else if("5".equals(esVideoMainVo2.getStatus())){
							esVideoMainVo2.setStatus("8");
						}else if("4".equals(esVideoMainVo2.getStatus())){
							esVideoMainVo2.setStatus("7");
						}else*/
						if("0".equals(esVideoMainVo2.getStatus())){
							esVideoMainVo2.setStatus("6");
						}else if("2".equals(esVideoMainVo2.getStatus())&&!"5".equals(esVideoMainVo2.getVerdict())){
							esVideoMainVo2.setStatus("6");
						}else if("2".equals(esVideoMainVo2.getStatus())&&"5".equals(esVideoMainVo2.getVerdict())){
							esVideoMainVo2.setStatus("5");
						}else if("1".equals(esVideoMainVo2.getStatus())&&"0".equals(esVideoMainVo2.getVerdict())){
							esVideoMainVo2.setStatus("0");
						}else if("1".equals(esVideoMainVo2.getStatus())&&"2".equals(esVideoMainVo2.getVerdict())){
							esVideoMainVo2.setStatus("2");
						}else if("1".equals(esVideoMainVo2.getStatus())&&"3".equals(esVideoMainVo2.getVerdict())){
							esVideoMainVo2.setStatus("3");
						}else if("1".equals(esVideoMainVo2.getStatus())&&"4".equals(esVideoMainVo2.getVerdict())){
							esVideoMainVo2.setStatus("4");
						}else if("1".equals(esVideoMainVo2.getStatus())&&"5".equals(esVideoMainVo2.getVerdict())){
							esVideoMainVo2.setStatus("5");
						}else if("1".equals(esVideoMainVo2.getStatus())&&"11".equals(esVideoMainVo2.getVerdict())){
							esVideoMainVo2.setStatus("11");
						}
					}
					esVideoMainVo2.setStatus(DictUtil.getDictToString("isPass4", esVideoMainVo2.getStatus()));
						/*esVideoMainVo2.setAppntsex(DictUtil.getDictToString("Sex", esVideoMainVo2.getAppntsex()));*/
						/*esVideoMainVo2.setStatus(DictUtil.getDictToString("zhijian", esVideoMainVo2.getStatus()));
						esVideoMainVo2.setVerdict(DictUtil.getDictToString("isPass4", esVideoMainVo2.getVerdict()));
						esVideoMainVo2.setResourse(DictUtil.getDictToString("resourse", esVideoMainVo2.getResourse()));
						esVideoMainVo2.setDatatype(DictUtil.getDictToString("datatype", esVideoMainVo2.getDatatype()));*/
//					}
					esVideoMainVo2.setPlayer(!"".equals(esVideoMainVo2.getPlayer())&&esVideoMainVo2.getPlayer()!=null?DictUtil.getDictToString("player", esVideoMainVo2.getPlayer()):"");
				}
				return  PageUtil.getPage(list1, pageParam);
			}

	public List<EsVideoMainVo> getAllPageHis(String docid) throws Exception {
		EsVideoMain esVideoMain=esVideoMainMapper.selectByPrimaryKey(docid);
		List<EsVideoMainVo> list=esVideoMainMapper.selectByFilterHis(esVideoMain.getDoccode());
		for (EsVideoMainVo esVideoMainVo2 : list) {
			List<ProductManage> productLst = esVideoMainMapper.selectProductsByDocid(esVideoMain.getDocid());
			if(productLst.size() > 1){
				esVideoMainVo2.setProductName("捆绑型产品");
				esVideoMainVo2.setBusinessTypeName("捆绑型产品");
			} else {
				ProductManage productItem = productLst.get(0);
				esVideoMainVo2.setProductName(productItem.getProductName());
				esVideoMainVo2.setBusinessTypeName(productItem.getBusinessTypeName());
			}

			if("1".equals(esVideoMainVo2.getStatus())&&"0".equals(esVideoMainVo2.getVerdict())){
				esVideoMainVo2.setStatus("0");
			}else if("1".equals(esVideoMainVo2.getStatus())&&"2".equals(esVideoMainVo2.getVerdict())){
				esVideoMainVo2.setStatus("2");
			}else if("1".equals(esVideoMainVo2.getStatus())&&"3".equals(esVideoMainVo2.getVerdict())){
				esVideoMainVo2.setStatus("3");
			}else if("1".equals(esVideoMainVo2.getStatus())&&"4".equals(esVideoMainVo2.getVerdict())){
				esVideoMainVo2.setStatus("4");
			}else if("1".equals(esVideoMainVo2.getStatus())&&"5".equals(esVideoMainVo2.getVerdict())){
				esVideoMainVo2.setStatus("5");
			}else if("1".equals(esVideoMainVo2.getStatus())&&"11".equals(esVideoMainVo2.getVerdict())){
				esVideoMainVo2.setStatus("11");
			}
				/*esVideoMainVo2.setStatus(DictUtil.getDictToString("zhijian", esVideoMainVo2.getStatus()));*/
			esVideoMainVo2.setStatus(DictUtil.getDictToString("isPass4", esVideoMainVo2.getStatus()));

			esVideoMainVo2.setPlayer(!"".equals(esVideoMainVo2.getPlayer())&&esVideoMainVo2.getPlayer()!=null?DictUtil.getDictToString("player", esVideoMainVo2.getPlayer()):"");
		}
		return  list;
	}

	public EsVideoMain getById(String docid) throws Exception {

		EsVideoMain esVideoMain=esVideoMainMapper.selectByPrimaryKey(docid);

		return  esVideoMain;
	}
	public EsVideoMainVo getByIdHis(String docid) throws Exception {

		EsVideoMainVo esVideoMainVo=esVideoMainMapper.selectByPrimaryKeyHis(docid);

		return  esVideoMainVo;
	}
	/**
	 * 十五天校验
	 *
	 * @return
	 */
	public boolean check(String docid,String modifyDate) {
		if(StringUtils.isNotEmpty(docid)){
			String[] strs=docid.split(",");
			for (String id : strs) {

				}
			return true;
			}
		return false;
	}

	/**
	 * 十五天校验
	 *
	 * @return
	 * @throws Exception
	 */
//	public Result<TroubleInfos> nopass(TroubleInfos troubleInfos) throws Exception {

		public Result<Object> nopass(TroubleInfos troubleInfos) throws Exception {
			Result<Object> re = new Result<>();
			try {
			String buno = troubleInfos.getBusinessno();
			QcMain qcMain=qcMainMapper.queryByBusno(troubleInfos.getBusinessno());
			List<VideoMainVo> doccodes = videoMainMapper.selectDoccodes(buno);
			String doccodess = "";
			for (VideoMainVo videoMainVo2 : doccodes) {
				doccodess+=videoMainVo2.getDoccode()+",";
			}
			doccodess = doccodess.substring(0,doccodess.length()-1);
			troubleInfos.setQcid(qcMain.getId());
			troubleInfos.setAgentid(qcMain.getAgentid());
			troubleInfos.setDoccode(doccodess);
			troubleInfos.setOperator(this.getUserSession().getUserNo());
			troubleInfos.setIssuedate(new Date());
			troubleInfos.setStatus("0");
			troubleInfos.setModifyDatetime(new Date());
			troubleInfos.setId(this.getMaxNo("ES_TROUBLE_INFO"));
			troubleInfos.setQcoperator(this.getUserSession().getUserNo());

			int result = troubleInfosMapper.insertSelective(troubleInfos);

				String qcoperator = videoMainMapper.selectQCOperator(buno);
//				if(qcoperator!=null&&!"".equalsIgnoreCase(qcoperator)){
//					ps.success=false;
//					ps.msg="质检失败，该任务已经被"+qcoperator+"质检，请刷新！";
//				}else{
					qcMain.setModifyDatatime(new Date());
					qcMain.setStatus("1");
					qcMain.setVerdict("1");
					String maxid = qcMainMapper.selectMaxId();
					qcMain.setId(maxid);
					VideoMainVo videoMainVo = new VideoMainVo();
					videoMainVo.setQcoperator(this.getUserSession().getUserNo());
					videoMainVo.setDoccode(qcMain.getDoccode());
					qcMain.setBusinessno(buno);
					videoMainVo.setBuno(buno);
					videoMainVo.setStatus("1");
					videoMainVo.setVerdict("1");
					videoMainMapper.updateBydocCodeQC(this.newSqlParam().add("videoMainVo", videoMainVo));
					int result1 = qcMainMapper.updatSelective(qcMain);

					if("1".equalsIgnoreCase(qcMain.getVerdict())){
//						WebSocketFace.qualityXml(qcMain.getDoccode(),qcMain.getVerdict());
						WebSocketFace.qualityXml(buno,qcMain.getVerdict());
					}
					for (VideoMainVo videoMainVo2 : doccodes) {
						/**查询该单双录情况**/
//						List<EasyRecordinfosBean> ls = easyRecordinfosService.czQuery(videoMainVo2.getDoccode());
						List<EasyRecordinfosBean> ls = easyRecordinfosService.czQuery(videoMainVo2.getDoccode());
						/**将改单双录情况存入es_message_sink表中,并处理发送报文到前置机**/
						videoPagesService.insertEasyRecord(ls,videoMainVo2.getDoccode());
					}
					if(result1>0 && result>0){
						re.success=true;
						re.msg="处理成功";

					}else{
						re.success=false;
						re.msg="处理失败";

					}
		} catch (DuplicateKeyException e) {

			re.success=false;
			re.msg="处理失败";

		}
//		return ps;
		return re;
	}

	/**
	 * 查询十五天的工作日截止日期
	 * @param docid
	 * @return
	 */
	public int queryDate(String docid) {
		int num=esVideoMainMapper.queryNum();

		return num;
	}

	/**
	 * 查询视频地址
	 * @param docid
	 * @return
	 */
	public VideoMainVo queryRec(String docid) {
		VideoMainVo videoMainVo = esVideoPagesMapper.selectRec(docid);
		String temp = B64Util.mTOa(videoMainVo.getVideoUrl()).replaceAll("&gt;", ">").replaceAll("&lt;", "<");
	    temp = temp.replace("\"", "\\"+"\"");
	    temp = temp.replaceAll("\r|\n", "");
		videoMainVo.setVideoUrl(temp);
		return videoMainVo;
	}

	/**
	 * 查询图片地址
	 * @param docid
	 * @return
	 */
	public VideoMainVo queryImg(String docid) {
		String imgurl = "";
		String imgtimepoint = "";
		String pointtext = "";
		VideoMain videoMain  = videoMainMapper.selectByPrimaryKey("his",docid);
		int resultLength = videoMain.getMangcode().length();
		String organida = videoMain.getMangcode();
		String organid = "";
		/*for (int i = 0; i < resultLength; i++) {
			if(i==0){
				organid  = videoMainMapper.selectOrganidByDocid(organida,"his");
			}else{
				organida = videoMainMapper.selectCode(organida);
				organid  = videoMainMapper.selectOrganidByDocid(organida,"his");
			}
			if(!"".equalsIgnoreCase(organid)&&organid!=null){
				break;
			}
			List<VideoMainVo> list = esVideoPagesMapper.selectImg(docid,organid);//组织机构写固定值86了
		}*/

		List<VideoMainVo> list = esVideoPagesMapper.selectImg(docid);//组织机构写固定值86了
		int i = 0;
		for (VideoMainVo videoMainVo : list) {
			i++;
			imgurl += Util.readProperties("recordIP")+videoMainVo.getImgUrl() + "|";
			imgtimepoint += videoMainVo.getTimpoint() + "|";
			pointtext += i + "、" + videoMainVo.getPointtext() + "|";
		}
		if(!"".equalsIgnoreCase(imgurl)){
			imgurl = imgurl.substring(0, imgurl.length() - 1);
			/*imgurl = B64Util.mTOa(imgurl).replaceAll("&gt;", ">").replaceAll("&lt;", "<");*/
			imgurl = imgurl.replace("\"", "\\" + "\"");
			imgurl = imgurl.replaceAll("\r|\n", "");
			imgtimepoint=imgtimepoint.replaceAll("\r|\n", "");
			imgtimepoint = imgtimepoint.substring(0, imgtimepoint.length() - 1);
			pointtext=pointtext.replaceAll("\r|\n", "");
			pointtext = pointtext.substring(0, pointtext.length() - 1);
		}
		VideoMainVo videoMainVo = new VideoMainVo();
		videoMainVo.setImgUrl(imgurl);
		videoMainVo.setTimpoint(imgtimepoint);
		videoMainVo.setPointtext(pointtext);
		return videoMainVo;

	}
	public Result<EsVideoMainVo> querydoccode(String doccode){
		Result<EsVideoMainVo> ps=new Result<EsVideoMainVo>();
		String buno = qcMainMapper.selectBussno(doccode);
		if(!"".equals(buno) && buno!=null){
			QcMain qcMain=qcMainMapper.queryByBusno(buno);
			if(!"".equals(qcMain) && qcMain!=null){
				ps.success = true;
				ps.msg = "投保单"+qcMain.getDoccode()+"进行质检回退，将回退到质检员的个人工作池进行重新质检。是否确认？";
			}else{
				ps.success = false;
				ps.msg = "本单可能进行了回退操作。请刷新页面！";
			}
		}else{
			ps.success = false;
			ps.msg = "本单可能进行了回退操作。请刷新页面！";
		}
		return ps;
	}
	//将待整改保单状态超过90天的置为整改过期
	public void autoRectifyoverdue() throws Exception {
		int date = Integer.parseInt(Util.readProperties("controller.rectifyoverduedate"));
		List<VideoMainVo> list = videoMainMapper.cxRectifyoverdue(date);
		if(list!=null&&list.size()>0){
			int result=0;
			int sum=0;
			for (VideoMainVo videoMainVo : list) {
				EsVideoMain mainVo2 = esVideoMainMapper.selectDocidByBusinessno(videoMainVo.getBusinessno());
				EsVideoMainVo esVideoMainVo = new EsVideoMainVo();
				esVideoMainVo.setStatus("1");
				esVideoMainVo.setVerdict("5");
				esVideoMainVo.setModifyDate(new Date());
				esVideoMainVo.setBusinessno(videoMainVo.getBusinessno());
				esVideoMainMapper.updateBybussno2(this.newSqlParam().add("esVideoMainVo", esVideoMainVo));
				QcMain qcMain=new QcMain();
				qcMain.setStatus("1");
				qcMain.setVerdict("5");
				qcMain.setModifyDatatime(new Date());
				qcMain.setBusinessno(videoMainVo.getBusinessno());
				String inspectdate = qcMainMapper.selectinspectdate(videoMainVo.getBusinessno());
				inspectdate = inspectdate.substring(0, inspectdate.lastIndexOf("."));
				String remarks = qcMainMapper.selectRemarks(videoMainVo.getBusinessno());
				String operation = qcOvertimeMapper.selectoperation(videoMainVo.getBusinessno());
				qcMainMapper.updateByDoccodeSelective2(qcMain);
				QcBackVo QcBackVo = new QcBackVo();
				QcBackVo.setId(this.getMaxNo(QcBackVo.SEQ_QCSECOND));
				QcBackVo.setBackdatetime(new Date());
				QcBackVo.setStatus("1");
				QcBackVo.setVerdict("2");
				QcBackVo.setBusinessno(videoMainVo.getBusinessno());
				QcBackVo.setDoccode(videoMainVo.getDoccode());
				QcBackVo.setCreateDatetime(new Date());
				QcBackVo.setModifyDatetime(new Date());
				QcBackVo.setQcoperator(mainVo2.getQcoperator());
				QcBackVo.setMangcode(mainVo2.getCompany());
				QcBackVo.setBackremarks(remarks);
				QcBackVo.setInspectdate(inspectdate);
				QcBackVo.setOperation(operation);
				qcMainMapper.insertQCBack(QcBackVo);
				//整改过期状态
				WebSocketFace.qualityXml(videoMainVo.getBusinessno(),"13");
			}
		}
	}
	//质检回退
	public Result<EsVideoMainVo> qcback(String doccode1,String docid1,String backtype,String backremarks) throws Exception {
		Result<EsVideoMainVo> ps = new Result<EsVideoMainVo>();
		/*List<Organ> list2 = OrganUtil.getMangerOrganByUserId(this.getUserSession().getUserNo());
		String code = "";
		if(list2!=null&&list2.size()>0){
			for (Organ organ : list2) {
				code = organ.getCode();
			}
		}*/
		String[] docid2=docid1.split(",");
		String[] doccode2=doccode1.split(",");
		int count1=0;
		for (int i = 0; i < doccode2.length; i++) {
			String docid=docid2[i];
			String doccode=doccode2[i];
			VideoMainVo mainVo = videoMainMapper.selectAllMain(doccode, docid);
//			QcMain QcMain=qcMainMapper.queryByBusno(mainVo.getBusinessno());
			List<VideoMainVo> doccodes = videoMainMapper.selectDoccodes(mainVo.getBusinessno());
			String doccodess = "";
			for (VideoMainVo videoMainVo2 : doccodes) {
				doccodess += videoMainVo2.getDoccode() + ",";
			}
			doccodess=doccodess.substring(0, doccodess.length() - 1);
			if( mainVo.getStatus() == null||"".equals(mainVo.getStatus()) ){
					ps.success = false;
					ps.msg = "此保单可能已经再次上传，请核实！";
			}else if("2".equals(mainVo.getStatus())){
				ps.success = false;
				ps.msg = "此保单已经进行了回退操作，不允许再次回退，请核实！";
			}else if("1".equals(mainVo.getStatus())){
				int result=0;
				int sum=0;
				int count=0;
				//质检回退,向客户端发送报文,前台将保单置为待质检
				String code = WebSocketFace.qualityXml(mainVo.getBusinessno(),"12");
				if("000000".equals(code)){
					EsVideoMainVo esVideoMainVo = new EsVideoMainVo();
					esVideoMainVo.setStatus("2");
					esVideoMainVo.setVerdict("");
					if("11".equals(mainVo.getVerdict())){
						esVideoMainVo.setStatus("2");
						esVideoMainVo.setVerdict("5");
					}
					esVideoMainVo.setModifyDate(new Date());
					if(mainVo.getQcrecordcount()==null){
						mainVo.setQcrecordcount("1");
					}
					String inspectdate = qcMainMapper.selectinspectdate(mainVo.getBusinessno());
					logger.info("qcMainMapper.selectinspectdate(mainVo.getBusinessno(): {}) >> {}",
							mainVo.getBusinessno(), inspectdate
							);
					if(StringUtils.isNotEmpty(inspectdate)){
						if(inspectdate.lastIndexOf(".") >= 0) inspectdate = inspectdate.substring(0, inspectdate.lastIndexOf("."));
					}else{
						logger.info("获取质检日期失败,日期赋值为当前时间");
						SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
						inspectdate=simpleDateFormat.format(new Date());
					}
					esVideoMainVo.setQcrecordcount(mainVo.getQcrecordcount());
					esVideoMainVo.setBusinessno(mainVo.getBusinessno());
					esVideoMainVo.setOperator(this.getUserSession().getUserNo());
					result=esVideoMainMapper.updateBybussno(this.newSqlParam().add("esVideoMainVo", esVideoMainVo));
					QcMain qcMain=new QcMain();
					qcMain.setStatus("2");
					qcMain.setVerdict("");
					if("11".equals(mainVo.getVerdict())){
						qcMain.setStatus("2");
						qcMain.setVerdict("5");
					}
					qcMain.setModifyDatatime(new Date());
					qcMain.setBusinessno(mainVo.getBusinessno());
					String remarks = qcMainMapper.selectRemarks(mainVo.getBusinessno());
					if(remarks==null){
						remarks="";
					}
					String operation = qcOvertimeMapper.selectoperation(mainVo.getBusinessno());
					if(operation==null){
						operation="";
					}
					sum=qcMainMapper.updateByDoccodeSelective2(qcMain);
					QcBackVo QcBackVo = new QcBackVo();
					QcBackVo.setId(this.getMaxNo(QcBackVo.SEQ_QCSECOND));
					QcBackVo.setBackdatetime(new Date());
					QcBackVo.setOperator(this.getUserSession().getUserNo());
					QcBackVo.setStatus(mainVo.getStatus());
					QcBackVo.setVerdict(mainVo.getVerdict());
					QcBackVo.setBusinessno(mainVo.getBusinessno());
					QcBackVo.setDoccode(doccodess);
					QcBackVo.setCreateDatetime(new Date());
					QcBackVo.setModifyDatetime(new Date());
					QcBackVo.setQcoperator(mainVo.getQcoperator());
					QcBackVo.setMangcode(mainVo.getMangcodecode());
					QcBackVo.setBacktype(backtype);
					QcBackVo.setBackremarks(remarks);
					QcBackVo.setInspectdate(inspectdate);
					QcBackVo.setOperation(operation);
					//update 2021-01  add IssueTypes IssueDesc
					count=qcMainMapper.insertQCBack(QcBackVo);
					if(result>0 && sum>0 && count>0){
						count1++;
						//质检回退,向客户端发送报文,前台将保单置为待质检
						//WebSocketFace.qualityXml(mainVo.getBusinessno(),"12");
					}

				}else{
					ps.success = false;
					ps.msg = "操作失败,客户端处理异常,或者客户经理已经重新上传！";
					return ps;
				}

				}
		}
		if(count1==docid2.length){
			ps.success = true;
			ps.msg = "操作成功";
		}else if(count1>0&&count1<docid2.length){
			ps.success = true;
			ps.msg = "回退成功"+count1+"条!";
		}else{
			ps.success = false;
			ps.msg = "操作失败";
		}
		return ps;
	}

	public static void main(String[] args) {
		System.out.println(FDate.getCurrentDateTime());
	}


	//已经质检的带整改保单查询
	public PageVo<EsVideoMainVo> getAllPageQuality(EsVideoMainVo esVideoMainVo, PageParam pageParam) throws Exception {
		/*List<Organ> list2 = OrganUtil.getMangerOrganByUserId(this.getUserSession().getUserNo());

		String incode="";
		esVideoMainVo.setIncode(incode);*/
//		esVideoMainVo.setStartScanDate(esVideoMainVo.getStartScanDate()!=null&&!"".equalsIgnoreCase(esVideoMainVo.getStartScanDate())?esVideoMainVo.getStartScanDate():esVideoMainVo.getStartDate());
//		esVideoMainVo.setEndScanDate(esVideoMainVo.getEndScanDate()!=null&&!"".equalsIgnoreCase(esVideoMainVo.getEndScanDate()&&esVideoMainVo.getStartScanDate()>=esVideoMainVo.getStartDate())?esVideoMainVo.getStartScanDate():esVideoMainVo.getStartDate());
		/*if(list2!=null&&list2.size()>0){
			for (Organ organ : list2) {
				incode=videoMainMapper.selectParentCode(organ.getCode());
				esVideoMainVo.setIncode(incode);*/
				if(esVideoMainVo.getEndScanDate()!=null){
					long day=1000*60*60*24-1;
					esVideoMainVo.setEndScanDate(new Date(esVideoMainVo.getEndScanDate().getTime()+day));
				}
				String status = esVideoMainVo.getStatus();
				if("0".equals(status)){
					esVideoMainVo.setStatus("");
					esVideoMainVo.setStatus2("1");
				}
				if("2".equals(status)){
					esVideoMainVo.setStatus("");
					esVideoMainVo.setStatus3("1");
				}
				if("3".equals(status)){
					esVideoMainVo.setStatus("");
					esVideoMainVo.setStatus4("1");
				}
				if("4".equals(status)){
					esVideoMainVo.setStatus("");
					esVideoMainVo.setStatus5("1");
				}
				if("11".equals(status)){
					esVideoMainVo.setStatus("");
					esVideoMainVo.setStatus7("1");
				}
				List<EsVideoMainVo> list1=new ArrayList<EsVideoMainVo>();
				MapContext map = MapContext.newOne();
//				esVideoMainVo.setQcoperator(this.getUserSession().getUserNo());
				map.put("esVideoMainVo", esVideoMainVo);
				map.put(PageUtil.PAGEPARAM, pageParam);
				List<EsVideoMainVo> list=esVideoMainMapper.selectByFilterQC2(map);
				for (EsVideoMainVo esVideoMainVo2 : list) {
					if("1".equals(esVideoMainVo2.getStatus())&&"0".equals(esVideoMainVo2.getVerdict())){
						esVideoMainVo2.setStatus("0");
					}else if("1".equals(esVideoMainVo2.getStatus())&&"2".equals(esVideoMainVo2.getVerdict())){
						esVideoMainVo2.setStatus("2");
					}else if("1".equals(esVideoMainVo2.getStatus())&&"3".equals(esVideoMainVo2.getVerdict())){
						esVideoMainVo2.setStatus("3");
					}else if("1".equals(esVideoMainVo2.getStatus())&&"4".equals(esVideoMainVo2.getVerdict())){
						esVideoMainVo2.setStatus("4");
					}else if("1".equals(esVideoMainVo2.getStatus())&&"11".equals(esVideoMainVo2.getVerdict())){
						esVideoMainVo2.setStatus("11");
					}
					esVideoMainVo2.setStatus(DictUtil.getDictToString("isPass4", esVideoMainVo2.getStatus()));

					list1.add(esVideoMainVo2);
				}
				return  PageUtil.getPage(list1, pageParam);
	}


		/*}else{
			MapContext map = MapContext.newOne();
			map.put("esVideoMainVo", esVideoMainVo);
			map.put(PageUtil.PAGEPARAM, pageParam);
			List<EsVideoMainVo> list=esVideoMainMapper.selectByFilterQC(map);
			for (EsVideoMainVo esVideoMainVo2 : list) {
				//银保质检部分不显示注释
//				if("1".equals(esVideoMainVo2.getResourse())&&"A".equals(esVideoMainVo2.getType())){
//					esVideoMainVo2.setBirthday("");
//					esVideoMainVo2.setAppntsex("");
//					esVideoMainVo2.setAppntidtype("");
//					esVideoMainVo2.setInsuredtype("");
//					esVideoMainVo2.setAppntage("");
//					esVideoMainVo2.setAppntidno("");
//				}else{
					esVideoMainVo2.setBirthday(FDate.formatDate(esVideoMainVo2.getAppntbirthday(), "yyyy-MM-dd"));
					esVideoMainVo2.setAppntsex(DictUtil.getDictToString("Sex", esVideoMainVo2.getAppntsex()));
					esVideoMainVo2.setAppntidtype(DictUtil.getDictToString("IDType", esVideoMainVo2.getAppntidtype()));
					esVideoMainVo2.setInsuredtype(DictUtil.getDictToString("IDType", esVideoMainVo2.getInsuredtype()));
//				}
				esVideoMainVo2.setRisktypecode(esVideoMainVo2.getRisktypename()!=null&&!"".equals(esVideoMainVo2.getRisktypename())?esVideoMainVo2.getRisktypename():"捆绑型产品");
				esVideoMainVo2.setRecdates(FDate.formatDate(esVideoMainVo2.getRecdate(), "yyyy-MM-dd")+" "+esVideoMainVo2.getRectime());
				esVideoMainVo2.setUploaddates(FDate.formatDate(esVideoMainVo2.getUploaddate(), "yyyy-MM-dd")+" "+esVideoMainVo2.getUploadtime());
				esVideoMainVo2.setStatus(DictUtil.getDictToString("zhijian", esVideoMainVo2.getStatus()));
				esVideoMainVo2.setVerdict(DictUtil.getDictToString("isFlag", esVideoMainVo2.getVerdict()));
				esVideoMainVo2.setRecduration(esVideoMainVo2.getRecduration()+"秒");
				esVideoMainVo2.setType(DictUtil.getDictToString("rectype", esVideoMainVo2.getType()));
				esVideoMainVo2.setResourse(DictUtil.getDictToString("resourse", esVideoMainVo2.getResourse()));
				list1.add(esVideoMainVo2);
			}
		}
		return  PageUtil.getPage(list1, pageParam);
	}*/


	public PageVo<EsVideoMainVo> getNotReply(EsVideoMainVo esVideoMainVo, PageParam pageParam) throws Exception {
		List<Organ> list2 = OrganUtil.getMangerOrganByUserId(this.getUserSession().getUserNo());
		List<EsVideoMainVo> list1=new ArrayList<EsVideoMainVo>();
		String incode="";
		esVideoMainVo.setIncode(incode);
		if(list2!=null&&list2.size()>0){
			for (Organ organ : list2) {
				incode=videoMainMapper.selectParentCode(organ.getCode());
				esVideoMainVo.setIncode(incode);
				MapContext map = MapContext.newOne();
				map.put("esVideoMainVo", esVideoMainVo);
				map.put(PageUtil.PAGEPARAM, pageParam);
				List<EsVideoMainVo> list=esVideoMainMapper.selectNotReply(map);
				for (EsVideoMainVo esVideoMainVo2 : list) {
					//银保质检部分不显示注释
//					if("1".equals(esVideoMainVo2.getResourse())&&"A".equals(esVideoMainVo2.getType())){
//						esVideoMainVo2.setRisktypecode(esVideoMainVo2.getRisktypename()!=null&&!"".equals(esVideoMainVo2.getRisktypename())?esVideoMainVo2.getRisktypename():"捆绑型产品");
//						esVideoMainVo2.setBirthday("");
//						esVideoMainVo2.setRecdates(FDate.formatDate(esVideoMainVo2.getRecdate(), "yyyy-MM-dd")+" "+esVideoMainVo2.getRectime());
//						esVideoMainVo2.setUploaddates(FDate.formatDate(esVideoMainVo2.getUploaddate(), "yyyy-MM-dd")+" "+esVideoMainVo2.getUploadtime());
//						/*FDate.formatDate(company.getActivationTime(), "yyyy-MM-dd HH:mm:ss");*/
//						esVideoMainVo2.setStatus(DictUtil.getDictToString("zhijian", esVideoMainVo2.getStatus()));
//						esVideoMainVo2.setAppntsex("");
//						esVideoMainVo2.setVerdict(DictUtil.getDictToString("Reply", esVideoMainVo2.getVerdict()));
//						esVideoMainVo2.setAppntidtype("");
//						esVideoMainVo2.setInsuredtype("");
//						esVideoMainVo2.setAppntidno("");
//						esVideoMainVo2.setAppntage("");
//						esVideoMainVo2.setRecduration(esVideoMainVo2.getRecduration()+"秒");
//					}else{
//						EsVideoPages esVideoPages=esVideoPagesMapper.selectById(esVideoMainVo2.getDocid());
						/*esVideoMainVo2.setCompany(DictUtil.getDictToString("Company_state", esVideoMainVo2.getCompany()));*/
						esVideoMainVo2.setRisktypecode(esVideoMainVo2.getRisktypename()!=null&&!"".equals(esVideoMainVo2.getRisktypename())?esVideoMainVo2.getRisktypename():"捆绑型产品");
						esVideoMainVo2.setBirthday(FDate.formatDate(esVideoMainVo2.getAppntbirthday(), "yyyy-MM-dd"));
						esVideoMainVo2.setRecdates(FDate.formatDate(esVideoMainVo2.getRecdate(), "yyyy-MM-dd")+" "+esVideoMainVo2.getRectime());
						esVideoMainVo2.setUploaddates(FDate.formatDate(esVideoMainVo2.getUploaddate(), "yyyy-MM-dd")+" "+esVideoMainVo2.getUploadtime());
						/*FDate.formatDate(company.getActivationTime(), "yyyy-MM-dd HH:mm:ss");*/
						esVideoMainVo2.setStatus(DictUtil.getDictToString("zhijian", esVideoMainVo2.getStatus()));
						esVideoMainVo2.setAppntsex(DictUtil.getDictToString("Sex", esVideoMainVo2.getAppntsex()));
						esVideoMainVo2.setVerdict(DictUtil.getDictToString("Reply", esVideoMainVo2.getVerdict()));
						esVideoMainVo2.setAppntidtype(DictUtil.getDictToString("IDType", esVideoMainVo2.getAppntidtype()));
						esVideoMainVo2.setInsuredtype(DictUtil.getDictToString("IDType", esVideoMainVo2.getInsuredtype()));
						esVideoMainVo2.setRecduration(esVideoMainVo2.getRecduration()+"秒");
//					}

					list1.add(esVideoMainVo2);
				}
			}
		}else{
			MapContext map = MapContext.newOne();
			map.put("esVideoMainVo", esVideoMainVo);
			map.put(PageUtil.PAGEPARAM, pageParam);
			List<EsVideoMainVo> list=esVideoMainMapper.selectNotReply(map);
			for (EsVideoMainVo esVideoMainVo2 : list) {
				//银保质检部分不显示注释
//				if("1".equals(esVideoMainVo2.getResourse())&&"A".equals(esVideoMainVo2.getType())){
//				esVideoMainVo2.setRisktypecode(esVideoMainVo2.getRisktypename()!=null&&!"".equals(esVideoMainVo2.getRisktypename())?esVideoMainVo2.getRisktypename():"捆绑型产品");
//				esVideoMainVo2.setBirthday("");
//				esVideoMainVo2.setRecdates(FDate.formatDate(esVideoMainVo2.getRecdate(), "yyyy-MM-dd")+" "+esVideoMainVo2.getRectime());
//				esVideoMainVo2.setUploaddates(FDate.formatDate(esVideoMainVo2.getUploaddate(), "yyyy-MM-dd")+" "+esVideoMainVo2.getUploadtime());
//				/*FDate.formatDate(company.getActivationTime(), "yyyy-MM-dd HH:mm:ss");*/
//				esVideoMainVo2.setStatus(DictUtil.getDictToString("zhijian", esVideoMainVo2.getStatus()));
//				esVideoMainVo2.setAppntsex("");
//				esVideoMainVo2.setVerdict(DictUtil.getDictToString("Reply", esVideoMainVo2.getVerdict()));
//				esVideoMainVo2.setAppntidtype("");
//				esVideoMainVo2.setInsuredtype("");
//				esVideoMainVo2.setAppntidno("");
//				esVideoMainVo2.setAppntage("");
//				esVideoMainVo2.setRecduration(esVideoMainVo2.getRecduration()+"秒");
//			}else{
//				EsVideoPages esVideoPages=esVideoPagesMapper.selectById(esVideoMainVo2.getDocid());
				/*esVideoMainVo2.setCompany(DictUtil.getDictToString("Company_state", esVideoMainVo2.getCompany()));*/
				esVideoMainVo2.setRisktypecode(esVideoMainVo2.getRisktypename()!=null&&!"".equals(esVideoMainVo2.getRisktypename())?esVideoMainVo2.getRisktypename():"捆绑型产品");
				esVideoMainVo2.setBirthday(FDate.formatDate(esVideoMainVo2.getAppntbirthday(), "yyyy-MM-dd"));
				esVideoMainVo2.setRecdates(FDate.formatDate(esVideoMainVo2.getRecdate(), "yyyy-MM-dd")+" "+esVideoMainVo2.getRectime());
				esVideoMainVo2.setUploaddates(FDate.formatDate(esVideoMainVo2.getUploaddate(), "yyyy-MM-dd")+" "+esVideoMainVo2.getUploadtime());
				/*FDate.formatDate(company.getActivationTime(), "yyyy-MM-dd HH:mm:ss");*/
				esVideoMainVo2.setStatus(DictUtil.getDictToString("zhijian", esVideoMainVo2.getStatus()));
				esVideoMainVo2.setAppntsex(DictUtil.getDictToString("Sex", esVideoMainVo2.getAppntsex()));
				esVideoMainVo2.setVerdict(DictUtil.getDictToString("Reply", esVideoMainVo2.getVerdict()));
				esVideoMainVo2.setAppntidtype(DictUtil.getDictToString("IDType", esVideoMainVo2.getAppntidtype()));
				esVideoMainVo2.setInsuredtype(DictUtil.getDictToString("IDType", esVideoMainVo2.getInsuredtype()));
				esVideoMainVo2.setRecduration(esVideoMainVo2.getRecduration()+"秒");
//			}
				list1.add(esVideoMainVo2);
			}
		}
		return  PageUtil.getPage(list1, pageParam);
	}
	//按照基本规则查询，查询15个工作日的日期
	public PageVo<EsVideoMainVo> getNotReplyByRule(EsVideoMainVo esVideoMainVo, PageParam pageParam) throws Exception {
		List<Organ> list2 = OrganUtil.getMangerOrganByUserId(this.getUserSession().getUserNo());
		List<EsVideoMainVo> list1=new ArrayList<EsVideoMainVo>();
		String incode="";
		esVideoMainVo.setIncode(incode);
		Calendar calendar = Calendar.getInstance();
        Date date = new Date(System.currentTimeMillis());
        calendar.setTime(date);
        int day=Integer.parseInt(Util.readProperties("days"));
        int num=(day%5);
        int week=(day/5);
        int countDays=0;
        if(num==0){
        	countDays=7*week;
        }else{
        	countDays=7*week+num;
        }
//        System.out.println("天数"+day+"%%%%"+num+"$$$$"+week+"*************"+countDays);
//        calendar.add(Calendar.WEEK_OF_YEAR, -1);
//        calendar.add(Calendar.DATE, -21);
        calendar.add(Calendar.DATE, -countDays);
        date = calendar.getTime();
        int days=HolidayUtil.calWorkdays(date, new Date());
        int m=0;
//        if(days>=15){
        if(days>=day){
        	esVideoMainVo.setModifyDate(date);
        }else{
        	m=day-days;
        	calendar.add(Calendar.DATE,-m);
        	date = calendar.getTime();
        	esVideoMainVo.setModifyDate(date);
        }
		if(list2!=null&&list2.size()>0){
			for (Organ organ : list2) {
				incode=videoMainMapper.selectParentCode(organ.getCode());
				esVideoMainVo.setIncode(incode);
				MapContext map = MapContext.newOne();
				map.put("esVideoMainVo", esVideoMainVo);
				map.put(PageUtil.PAGEPARAM, pageParam);
				List<EsVideoMainVo> list=esVideoMainMapper.selectNotReplyByRule(map);
				for (EsVideoMainVo esVideoMainVo2 : list) {
					//银保质检部分不显示注释
//					if("1".equals(esVideoMainVo2.getResourse())&&"A".equals(esVideoMainVo2.getType())){
//						esVideoMainVo2.setRisktypecode(esVideoMainVo2.getRisktypename()!=null&&!"".equals(esVideoMainVo2.getRisktypename())?esVideoMainVo2.getRisktypename():"捆绑型产品");
//						esVideoMainVo2.setBirthday("");
//						esVideoMainVo2.setRecdates(FDate.formatDate(esVideoMainVo2.getRecdate(), "yyyy-MM-dd"));
//						/*FDate.formatDate(company.getActivationTime(), "yyyy-MM-dd HH:mm:ss");*/
//						esVideoMainVo2.setStatus(DictUtil.getDictToString("zhijian", esVideoMainVo2.getStatus()));
//						esVideoMainVo2.setAppntsex("");
//						esVideoMainVo2.setVerdict(DictUtil.getDictToString("Reply", esVideoMainVo2.getVerdict()));
//						esVideoMainVo2.setAppntidtype("");
//						esVideoMainVo2.setInsuredtype("");
//						esVideoMainVo2.setRecduration(esVideoMainVo2.getRecduration()+"秒");
//						esVideoMainVo2.setAgentname(esVideoMainVo2.getProperson());
//						esVideoMainVo2.setAppntidno("");
//						esVideoMainVo2.setAppntage("");
//					}else{
						esVideoMainVo2.setRisktypecode(esVideoMainVo2.getRisktypename()!=null&&!"".equals(esVideoMainVo2.getRisktypename())?esVideoMainVo2.getRisktypename():"捆绑型产品");
						esVideoMainVo2.setBirthday(FDate.formatDate(esVideoMainVo2.getAppntbirthday(), "yyyy-MM-dd"));
						esVideoMainVo2.setRecdates(FDate.formatDate(esVideoMainVo2.getRecdate(), "yyyy-MM-dd"));
						/*FDate.formatDate(company.getActivationTime(), "yyyy-MM-dd HH:mm:ss");*/
						esVideoMainVo2.setStatus(DictUtil.getDictToString("zhijian", esVideoMainVo2.getStatus()));
						esVideoMainVo2.setAppntsex(DictUtil.getDictToString("Sex", esVideoMainVo2.getAppntsex()));
						esVideoMainVo2.setVerdict(DictUtil.getDictToString("Reply", esVideoMainVo2.getVerdict()));
						esVideoMainVo2.setAppntidtype(DictUtil.getDictToString("IDType", esVideoMainVo2.getAppntidtype()));
						esVideoMainVo2.setInsuredtype(DictUtil.getDictToString("IDType", esVideoMainVo2.getInsuredtype()));
						esVideoMainVo2.setRecduration(esVideoMainVo2.getRecduration()+"秒");
//					}
					list1.add(esVideoMainVo2);
				}
			}
		}else{
			MapContext map = MapContext.newOne();
			map.put("esVideoMainVo", esVideoMainVo);
			map.put(PageUtil.PAGEPARAM, pageParam);
			List<EsVideoMainVo> list=esVideoMainMapper.selectNotReplyByRule(map);
			for (EsVideoMainVo esVideoMainVo2 : list) {
				//银保质检部分不显示注释
//				if("1".equals(esVideoMainVo2.getResourse())&&"A".equals(esVideoMainVo2.getType())){
//					esVideoMainVo2.setRisktypecode(esVideoMainVo2.getRisktypename()!=null&&!"".equals(esVideoMainVo2.getRisktypename())?esVideoMainVo2.getRisktypename():"捆绑型产品");
//					esVideoMainVo2.setBirthday("");
//					esVideoMainVo2.setRecdates(FDate.formatDate(esVideoMainVo2.getRecdate(), "yyyy-MM-dd"));
//					/*FDate.formatDate(company.getActivationTime(), "yyyy-MM-dd HH:mm:ss");*/
//					esVideoMainVo2.setStatus(DictUtil.getDictToString("zhijian", esVideoMainVo2.getStatus()));
//					esVideoMainVo2.setAppntsex("");
//					esVideoMainVo2.setVerdict(DictUtil.getDictToString("Reply", esVideoMainVo2.getVerdict()));
//					esVideoMainVo2.setAppntidtype("");
//					esVideoMainVo2.setInsuredtype("");
//					esVideoMainVo2.setRecduration(esVideoMainVo2.getRecduration()+"秒");
//					esVideoMainVo2.setAgentname(esVideoMainVo2.getProperson());
//					esVideoMainVo2.setAppntidno("");
//					esVideoMainVo2.setAppntage("");
//				}else{
					esVideoMainVo2.setRisktypecode(esVideoMainVo2.getRisktypename()!=null&&!"".equals(esVideoMainVo2.getRisktypename())?esVideoMainVo2.getRisktypename():"捆绑型产品");
					esVideoMainVo2.setBirthday(FDate.formatDate(esVideoMainVo2.getAppntbirthday(), "yyyy-MM-dd"));
					esVideoMainVo2.setRecdates(FDate.formatDate(esVideoMainVo2.getRecdate(), "yyyy-MM-dd"));
					/*FDate.formatDate(company.getActivationTime(), "yyyy-MM-dd HH:mm:ss");*/
					esVideoMainVo2.setStatus(DictUtil.getDictToString("zhijian", esVideoMainVo2.getStatus()));
					esVideoMainVo2.setAppntsex(DictUtil.getDictToString("Sex", esVideoMainVo2.getAppntsex()));
					esVideoMainVo2.setVerdict(DictUtil.getDictToString("Reply", esVideoMainVo2.getVerdict()));
					esVideoMainVo2.setAppntidtype(DictUtil.getDictToString("IDType", esVideoMainVo2.getAppntidtype()));
					esVideoMainVo2.setInsuredtype(DictUtil.getDictToString("IDType", esVideoMainVo2.getInsuredtype()));
					esVideoMainVo2.setRecduration(esVideoMainVo2.getRecduration()+"秒");
//				}
				list1.add(esVideoMainVo2);
			}
		}
		return  PageUtil.getPage(list1, pageParam);
	}



	/**
	 * 目前没用   也没被调用
	 * @param docid
	 * @return
	 */
	public QcMainVo queryQCPoint(String doccode) {
		return esVideoMainMapper.queryQCPointDEsc(doccode).get(0);
	}
	//用于质检不通过的保单查询
	public EsVideoMainVo queryVideoMain(String docid) {
		EsVideoMainVo esVideoMainVo = esVideoMainMapper.selectByID(docid);
		esVideoMainVo.setRisktypecode(esVideoMainVo.getRisktypename()!=null&&!"".equals(esVideoMainVo.getRisktypename())?esVideoMainVo.getRisktypename():"捆绑型产品");
		return esVideoMainVo;
	}
	public String queryQCPointDEsc(String doccode) {
		List<QcMainVo> list = esVideoMainMapper.queryQCPointDEsc(doccode);
		String qc = "";
		if(list!=null&&list.size()>0){
			qc = "1";
		}else{
			qc = "0";
		}
		return qc;
	}
	public String queryQCVerdict(String doccode)
	{
		List<QcMainVo> list = esVideoMainMapper.queryQCPointDEsc(doccode);
		QcMainVo qcMainVo=list.get(0);
		return qcMainVo.getVerdict();
	}
	public String queryQCVerdictHis(String businessno)
	{
		List<QcMainVo> list = esVideoMainMapper.queryQCVerdictHis(businessno);
		QcMainVo qcMainVo=list.get(0);
		return qcMainVo.getVerdict();
	}
	/**
	 * 用于历史查寻
	 * @param docid
	 * @return
	 */
	public QcMainVo queryQCPointHis(String docid) {
		return esVideoMainMapper.queryQCPointDEscHis(docid).get(0);
	}
	public String queryQCPointDEscHis(String docid) {
		List<QcMainVo> list = esVideoMainMapper.queryQCPointDEscHis(docid);
		String qc = "";
		if(list!=null&&list.size()>0){
			qc = "1";
		}else{
			qc = "0";
		}
		return qc;
	}
	public VideoMainVo selectAllMain(String docid) throws Exception {
		VideoMainVo mainVo = esVideoMainMapper.selectAllMain(docid);
		mainVo.setAppntidtype(DictUtil.getDictToString("IDType", mainVo.getAppntidtype()));
		mainVo.setAppntsex(DictUtil.getDictToString("Sex", mainVo.getAppntsex()));
		mainVo.setInsuredtype(DictUtil.getDictToString("IDType", mainVo.getInsuredtype()));
		mainVo.setInsuredsex(DictUtil.getDictToString("Sex", mainVo.getInsuredsex()));
		mainVo.setAgentWorkFlag(DictUtil.getDictToString("work_flag", mainVo.getAgentWorkFlag()));
		mainVo.setProperson(mainVo.getProperson());
		if(!"".equalsIgnoreCase(mainVo.getTxt())&&mainVo.getTxt()!=null){
			mainVo.setTxt(mainVo.getTxt().replaceAll("\n", "^"));
		}else{
			mainVo.setTxt("");
		}
		return mainVo;
	}
	/**
	 * 导出双录信息Excel
	 * @param dumpid
	 * @throws Exception
	 */
	public void integratedExport_excel(EsVideoMainVo esVideoMainVo) throws Exception {
		List<EsVideoMainVo> list1=new ArrayList<EsVideoMainVo>();
				MapContext map = MapContext.newOne();
				String status = esVideoMainVo.getStatus();
				if("0".equals(status)){
					esVideoMainVo.setStatus("");
					esVideoMainVo.setStatus2("1");
				}
				if("2".equals(status)){
					esVideoMainVo.setStatus("");
					esVideoMainVo.setStatus3("1");
				}
				if("3".equals(status)){
					esVideoMainVo.setStatus("");
					esVideoMainVo.setStatus4("1");
				}
				if("4".equals(status)){
					esVideoMainVo.setStatus("");
					esVideoMainVo.setStatus5("1");
				}
				if("5".equals(status)){
					esVideoMainVo.setStatus("");
					esVideoMainVo.setStatus6("1");
				}
				if("6".equals(status)){
					esVideoMainVo.setStatus("");
					esVideoMainVo.setStatus8("1");
				}
				if("11".equals(status)){
					esVideoMainVo.setStatus("");
					esVideoMainVo.setStatus7("1");
				}
				//1024添加(客户经理,分行行长,总行长不同的查询结果)

				if(esVideoMainVo.getEndScanDate()!=null){
					int day=1000*60*60*24-1;
					esVideoMainVo.setEndScanDate(new Date(esVideoMainVo.getEndScanDate().getTime()+day));
				}

				String userNo = this.getUserSession().getUserNo();
				String RuleName = userRoleMapper.selectRuleNameByUserId(userNo);
				List<String> rulelist = new ArrayList<String>();

				//用户和网点关联的对象
				List<OrgUser> selectByuserId = orgUserMapper.selectByuserId(userNo);
				if(selectByuserId!=null&&selectByuserId.size()>0){
					//查ld_code表中对总网点的设置bigOrganizationCode
					String bigOrganizationCode = userRoleMapper.selectBigOrganizationCode();//查询总行网点编码
					String agentRuleName = userRoleMapper.selectRuleNamefromldcode();
					if(bigOrganizationCode.equals((selectByuserId.get(0).getOrganizationCode()))){

					}else if(agentRuleName.equals(RuleName)){
						if("".equals(esVideoMainVo.getAgentid())){
							esVideoMainVo.setAgentid(userNo);
						}else{
							esVideoMainVo.setAgentid("客户经理查不到其他客户经理的");
						}
					}else{
						esVideoMainVo.setMangcode(selectByuserId.get(0).getOrganizationCode());
					}
				}else{
					integratedExport_excel(list1);
					return;
				}


				map.put("esVideoMainVo", esVideoMainVo);
				list1 =esVideoMainMapper.selectByFilter(map);
				for (EsVideoMainVo esVideoMainVo2 : list1) {

				if(status!=null&&"0".equals(status)){
						esVideoMainVo2.setStatus("0");
				}else if(status!=null&&"2".equals(status)){
						esVideoMainVo2.setStatus("2");
				}else if(status!=null&&"3".equals(status)){
					esVideoMainVo2.setStatus("3");
				}else if(status!=null&&"4".equals(status)){
					esVideoMainVo2.setStatus("4");
				}else if(status!=null&&"5".equals(status)){
					esVideoMainVo2.setStatus("5");
				}else if(status!=null&&"6".equals(status)){
					esVideoMainVo2.setStatus("6");
				}else if(status!=null&&"11".equals(status)){
					esVideoMainVo2.setStatus("11");
				}else{
					if("0".equals(esVideoMainVo2.getStatus())){
						esVideoMainVo2.setStatus("6");
					}else if("2".equals(esVideoMainVo2.getStatus())&&!"5".equals(esVideoMainVo2.getVerdict())){
						esVideoMainVo2.setStatus("6");
					}else if("2".equals(esVideoMainVo2.getStatus())&&"5".equals(esVideoMainVo2.getVerdict())){
						esVideoMainVo2.setStatus("5");
					}else if("1".equals(esVideoMainVo2.getStatus())&&"0".equals(esVideoMainVo2.getVerdict())){
						esVideoMainVo2.setStatus("0");
					}else if("1".equals(esVideoMainVo2.getStatus())&&"2".equals(esVideoMainVo2.getVerdict())){
						esVideoMainVo2.setStatus("2");
					}else if("1".equals(esVideoMainVo2.getStatus())&&"3".equals(esVideoMainVo2.getVerdict())){
						esVideoMainVo2.setStatus("3");
					}else if("1".equals(esVideoMainVo2.getStatus())&&"4".equals(esVideoMainVo2.getVerdict())){
						esVideoMainVo2.setStatus("4");
					}else if("1".equals(esVideoMainVo2.getStatus())&&"5".equals(esVideoMainVo2.getVerdict())){
						esVideoMainVo2.setStatus("5");
					}else if("1".equals(esVideoMainVo2.getStatus())&&"11".equals(esVideoMainVo2.getVerdict())){
						esVideoMainVo2.setStatus("11");
					}
				}
				esVideoMainVo2.setStatus(DictUtil.getDictToString("isPass4", esVideoMainVo2.getStatus()));


					/*esVideoMainVo2.setAppntsex(DictUtil.getDictToString("Sex", esVideoMainVo2.getAppntsex()));
					esVideoMainVo2.setAppntidtype(DictUtil.getDictToString("IDType", esVideoMainVo2.getAppntidtype()));
					esVideoMainVo2.setVerdict(DictUtil.getDictToString("isFlag", esVideoMainVo2.getVerdict()));
					esVideoMainVo2.setResourse(DictUtil.getDictToString("resourse", esVideoMainVo2.getResourse()));
					esVideoMainVo2.setDatatype(DictUtil.getDictToString("datatype", esVideoMainVo2.getDatatype()));*/
				}
				integratedExport_excel(list1);
			}



	/**
	 * 导出待整改Excel
	 * @param dumpid
	 * @throws Exception
	 */
	public void export_excel(EsVideoMainVo esVideoMainVo) throws Exception {

		List<EsVideoMainVo> list1=new ArrayList<EsVideoMainVo>();
				MapContext map = MapContext.newOne();
				map.put("esVideoMainVo", esVideoMainVo);
				List<EsVideoMainVo> list=esVideoMainMapper.selectNotReply(map);
				for (EsVideoMainVo esVideoMainVo2 : list) {

						esVideoMainVo2.setRisktypecode(esVideoMainVo2.getRisktypename()!=null&&!"".equals(esVideoMainVo2.getRisktypename())?esVideoMainVo2.getRisktypename():"捆绑型产品");
						esVideoMainVo2.setBirthday(FDate.formatDate(esVideoMainVo2.getAppntbirthday(), "yyyy-MM-dd"));
						esVideoMainVo2.setRecdates(FDate.formatDate(esVideoMainVo2.getRecdate(), "yyyy-MM-dd")+" "+esVideoMainVo2.getRectime());
						esVideoMainVo2.setUploaddates(FDate.formatDate(esVideoMainVo2.getUploaddate(), "yyyy-MM-dd")+" "+esVideoMainVo2.getUploadtime());
						esVideoMainVo2.setStatus(DictUtil.getDictToString("zhijian", esVideoMainVo2.getStatus()));
						esVideoMainVo2.setAppntsex(DictUtil.getDictToString("Sex", esVideoMainVo2.getAppntsex()));
						esVideoMainVo2.setVerdict(DictUtil.getDictToString("Reply", esVideoMainVo2.getVerdict()));
						esVideoMainVo2.setAppntidtype(DictUtil.getDictToString("IDType", esVideoMainVo2.getAppntidtype()));
						esVideoMainVo2.setInsuredtype(DictUtil.getDictToString("IDType", esVideoMainVo2.getInsuredtype()));
						esVideoMainVo2.setRecduration(esVideoMainVo2.getRecduration()+"秒");
						list1.add(esVideoMainVo2);
				}

			replyexport_excel(list1);

	}
//excel格式待重录
public void replyexport_excel(List<EsVideoMainVo> list1) throws Exception {
		List<List<String>> entityDataList = new ArrayList<List<String>>();
		if (list1 != null && !list1.isEmpty()) {
			for (EsVideoMainVo esVideoMainVo3 : list1) {
				List<String> list3 = new ArrayList<String>();
				list3.add(esVideoMainVo3.getDoccode());
				list3.add(esVideoMainVo3.getAppntname());
				list3.add( esVideoMainVo3.getAppntidtype());
				list3.add(esVideoMainVo3.getAppntidno());
				list3.add(esVideoMainVo3.getAppntsex());
				list3.add(esVideoMainVo3.getAppntage());
				list3.add(FDate.formatDate(esVideoMainVo3.getAppntbirthday(), "yyyy-MM-dd"));
				list3.add(esVideoMainVo3.getRisktypecode());
				list3.add(esVideoMainVo3.getMangcode());
				list3.add(esVideoMainVo3.getRecdates());
//				list3.add(esVideoMainVo3.getRectime());
				list3.add(esVideoMainVo3.getRecduration());
				list3.add(esVideoMainVo3.getUploaddates());
//				list3.add(esVideoMainVo3.getUploadtime());
				list3.add(esVideoMainVo3.getAgentname());
				list3.add(esVideoMainVo3.getQcoperator());
				entityDataList.add(list3);
			}
		}
		String[] titles = new String[] { "投保单号", "投保人名称", "证件类型", "证件号码","性别","年龄","出生日期","产品名称","管理机构","录制时间","录制时长","上传时间","代理人","质检员"};
		String dir = Util.readProperties("file.Integrated");
//		String dir ="c:/afcFile";
		List<Integer> columnWidth = new ArrayList<Integer>();
		for (int i=0; i<titles.length; i++) {
			Integer width = titles[i].getBytes().length;
			if(i==0){
				width = 20;//投保单号
			}else if(i==1){
				width = 15;//投保人名称
			}else if(i==2){
				width = 10;//证件类型
			}else if(i==3){
				width = 30;//证件号码
			}else if(i==4){
				width = 10;//性别
			}else if(i==5){
				width = 10;//年龄
			}else if(i==6){
				width = 15;//出生日期
			}else if(i==7){
				width = 30;//产品类型
			}else if(i==8){
				width = 15;//管理机构
			}
			else if(i==9){
				width = 20;//录制日期
			}
			else if(i==10){
				width = 15;//录制时长
			}
			else if(i==11){
				width = 15;//上传日期
			}
			else if(i==12){
				width = 15;//代理人
			}
			else if(i==13){
				width = 15;//质检员
			}
			columnWidth.add(width);
		}
		File file = new File(ExcelPoiUtil.createExcel(dir, titles, entityDataList,columnWidth,"待整改任务清单"));
		Util.download("待整改任务清单.xlsx", file);
		if (file.exists()) {
			file.delete();
		}
	}

//双录信息excel格式
	public void integratedExport_excel(List<EsVideoMainVo> list1) throws Exception {
		List<List<String>> entityDataList = new ArrayList<List<String>>();
		if (list1 != null && !list1.isEmpty()) {
			for (EsVideoMainVo esVideoMainVo3 : list1) {
				List<String> list3 = new ArrayList<String>();
				list3.add(esVideoMainVo3.getDoccode());//
				list3.add(esVideoMainVo3.getMangcode());//
				list3.add(esVideoMainVo3.getAppntNo());//
				list3.add(esVideoMainVo3.getAgentid());//
				list3.add(esVideoMainVo3.getMangShortName());//
				list3.add(esVideoMainVo3.getBusinessTypeName());//
				list3.add(esVideoMainVo3.getProductname());//ProductName对象中有两个,用N接收不到
				list3.add(esVideoMainVo3.getRisktypecode());//
//				list3.add(esVideoMainVo3.getStartScanDate()+"");//
				list3.add(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(esVideoMainVo3.getStartScanDate()));//
//				list3.add(esVideoMainVo3.getEndScanDate()+"");//
				list3.add(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(esVideoMainVo3.getEndScanDate()));//
				list3.add(esVideoMainVo3.getStatus());//
				list3.add(esVideoMainVo3.getFinancedCode());//
				list3.add(esVideoMainVo3.getFinancedShortName());//
				list3.add(esVideoMainVo3.getQcoperator());
				list3.add(esVideoMainVo3.getQcoperator1());
				entityDataList.add(list3);
			}
		}
		String[] titles = new String[] { "业务流水号", "网点名称", "客户号", "员工号","员工网点缩写"
				,"业务类型","产品名称","产品编号","录制开始日期","录制结束日期","记录状态",
				"理财室编号","理财室网点缩写","质检员","质检员工号"};
		String dir = Util.readProperties("file.Integrated");
//		String dir ="c:/afcFile";
		List<Integer> columnWidth = new ArrayList<Integer>();
		for (int i=0; i<titles.length; i++) {
			Integer width = titles[i].getBytes().length;
			if(i==0){
				width = 20;//业务流水号
			}else if(i==1){
				width = 15;//网点名称
			}else if(i==2){
				width = 20;//客户号
			}else if(i==3){
				width = 30;//员工号
			}else if(i==4){
				width = 20;//员工网点缩写
			}else if(i==5){
				width = 15;//业务类型
			}else if(i==6){
				width = 15;//产品名称
			}else if(i==7){
				width = 15;//产品编号
			}else if(i==8){
				width = 15;//录制开始日期
			}else if(i==9){
				width = 15;//录制结束日期
			}else if(i==10){
				width = 10;//记录状态
			}else if(i==11){
				width = 15;//理财室编号
			}else if(i==12){
				width = 20;//理财室网点缩写
			}
			columnWidth.add(width);
		}
		File file = new File(ExcelPoiUtil.createExcel(dir, titles, entityDataList,columnWidth,"双录信息查询清单"));
		Util.download("双录信息查询清单.xlsx", file);
		if (file.exists()) {
			file.delete();
		}
	}

	public VideoMainVo queryOtherDocuments(String docid, String string) {

		String otherDocumentsUrl = "";
		String otherDocumentsName = "";
		VideoMain videoMain  = videoMainMapper.selectByPrimaryKey("his",docid);
		int resultLength = videoMain.getMangcode().length();
		List<VideoMainVo> list = esVideoPagesMapper.selectOtherDocuments(docid);//组织机构写固定值86了
		for (VideoMainVo videoMainVo : list) {
			otherDocumentsUrl += Util.readProperties("recordIP")+videoMainVo.getOtherDocumentsUrl() + "|";
			otherDocumentsName +=videoMainVo.getDocumentsName() + "|";
		}
		if (!"".equalsIgnoreCase(otherDocumentsUrl)) {
			otherDocumentsUrl = otherDocumentsUrl.substring(0, otherDocumentsUrl.length() - 1);
			otherDocumentsUrl = B64Util.mTOa(otherDocumentsUrl).replaceAll("&gt;", ">").replaceAll("&lt;", "<");
			otherDocumentsUrl = otherDocumentsUrl.replace("\"", "\\" + "\"");
			otherDocumentsUrl = otherDocumentsUrl.replaceAll("\r|\n", "");
			otherDocumentsName=otherDocumentsName.replaceAll("\r|\n", "");
			otherDocumentsName = otherDocumentsName.substring(0, otherDocumentsName.length() - 1);
		}
		VideoMainVo videoMainVo = new VideoMainVo();
		videoMainVo.setOtherDocumentsUrl(otherDocumentsUrl);
		videoMainVo.setDocumentsName(otherDocumentsName);
		return videoMainVo;

	}
	public VideoMainVo queryOtherImg(String docid, String string) {

		String otherImgUrl = "";
		String otherImgName = "";
		VideoMain videoMain  = videoMainMapper.selectByPrimaryKey("his",docid);
		List<VideoMainVo> list = esVideoPagesMapper.selectOtherImg(docid);//组织机构写固定值86了
		for (VideoMainVo videoMainVo : list) {
			otherImgUrl +=Util.readProperties("recordIP")+ videoMainVo.getOtherImgUrl() + "|";
			otherImgName +=videoMainVo.getOtherImgName() + "|";
		}
		if (!"".equalsIgnoreCase(otherImgUrl)) {
			otherImgUrl = otherImgUrl.substring(0, otherImgUrl.length() - 1);
			otherImgUrl = B64Util.mTOa(otherImgUrl).replaceAll("&gt;", ">").replaceAll("&lt;", "<");
			otherImgUrl = otherImgUrl.replace("\"", "\\" + "\"");
			otherImgUrl = otherImgUrl.replaceAll("\r|\n", "");
			otherImgName=otherImgName.replaceAll("\r|\n", "");
			otherImgName = otherImgName.substring(0, otherImgName.length() - 1);
		}
		VideoMainVo videoMainVo = new VideoMainVo();
		videoMainVo.setOtherImgUrl(otherImgUrl);
		videoMainVo.setOtherImgName(otherImgName);
		return videoMainVo;
	}


}
