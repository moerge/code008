package sinosoft.project.Integrated.dao;

import java.util.List;

import sinosoft.framework.core.beans.SqlParam;
import sinosoft.platform.utils.MapContext;
import sinosoft.project.Integrated.beans.EsVideoMain;
import sinosoft.project.Integrated.vo.EsVideoMainVo;
import sinosoft.project.entity.ProductManage;
import sinosoft.project.qcac.vo.QcMainVo;
import sinosoft.project.qcac.vo.VideoMainVo;

public interface EsVideoMainMapper {
    int deleteByPrimaryKey(String docid);

    int insert(EsVideoMain record);

    int insertSelective(EsVideoMain record);

    EsVideoMain selectByPrimaryKey(String docid);

    EsVideoMain selectByDoccode(String doccode);

    int updateByPrimaryKeySelective(EsVideoMain record);

    int updateByPrimaryKey(EsVideoMain record);

	List<EsVideoMainVo> selectByFilter(MapContext map);

	List<EsVideoMainVo> selectByFilterQC(MapContext map);

	List<EsVideoMainVo> selectByFilterQC2(MapContext map);

	List<EsVideoMainVo> selectByFilterHis(String doccode);

	List<ProductManage> selectProductsByDocid(String docid);

	EsVideoMainVo selectByPrimaryKeyHis(String docid);

	EsVideoMainVo selectByFilter(String docid);

	List<EsVideoMainVo> selectNotReply(MapContext map);

	List<EsVideoMainVo> selectNotReplyByRule(MapContext map);

	List<QcMainVo> queryQCPointDEsc(String doccode);

	List<QcMainVo> queryQCPointDEscHis(String businessno);

	VideoMainVo selectAllMain(String docid);

	List<EsVideoMainVo> selectByWaitQC(MapContext map);

	EsVideoMainVo selectByID(String docid);

	int queryNum();

	List<QcMainVo> queryQCVerdictHis(String businessno);
	//质检回退专用
	int updateBybussno(SqlParam add);

	//待整改过期专用
	int updateBybussno2(SqlParam add);

	String selectByBusinessno(String businessno);

	EsVideoMain selectDocidByBusinessno(String businessno);



}
