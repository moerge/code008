package sinosoft.project.Integrated.vo;

import java.util.Date;

public class EsVideoMainVo {
	private String docid;
	private String docidVo;
	private String beforebusinessno;
	private String channel;
	private String busstype;
	private String subtype;
	private String birthday;
	private Date createDate;
	private String createDatetime;
	private Date modifyDate;
	private String operator;
	private String pageid;
	private String hostname;
	private String filetype;
	private String url;
	private String pagename;
	private String imgtimepoint;
	private String picpathftp;
	private Date startScanDate;// 录制起始时间
	private Date endScanDate;// 录制终止时间
	private String middle;
	private String UUID;
	private String recdates;
	private String risktypename;
	private Date startDate;
	private Date endDate;
	private int days;
	private String uploaddates;// 上传日期
	private int count;// 质检节点数
	private String isFirstUpload;// 是否首次上传
	private String notify;// 消息通知
	private String player;// 视频超期能否播放
	private String isback;// 是否质检回退
	private String resoursemin;//理财室网点缩写
	private String id;//主键id
	private String buno;//业务流水号
	private String bebuno;//上次业务流水号
	private String doccode;//投保单号
	private String doccodevo;//投保单号vo
	private String risktype;//产品类型编码
	private String agentname;//代理人姓名
	private String agentid;//员工号
	private String agentPhone;//代理人电话
	private String agentWorkFlag;//代理人工作状态
	private String agentChannelname;//代理人渠道名称
	private String datatype;//文件类型--新单还是问题单反馈
	private String num;//文件个数
	private String status;//质检状态(接收传输状态或质检状态)
	private String status2;//质检状态(质检通过)
	private String status3;//质检状态(待整改)
	private String status4;//质检状态(通过提醒)
	private String status5;//质检状态(整改完成)
	private String status6;//质检状态(整改过期)
	private String status7;//质检状态(整改未完成)
	private String status8;//质检状态(待质检)
	private String verdict;//质检结论
	private String appntname;//投保人
	private String appntage;//投保人年龄
	private String polapplydate;//投保时间
	private String qcoperator;//质检人
	private String qcoperator1;//质检人查询
	private String attribute;//公共或私有
	private String risktypecode;
	private Date modifydate;//修改时间
	private String bankcode;//银行编号
	private String banknetwork;//银行出单网点
	private String properson;//专管员工号
	private String type;//类型
	private String operation;//业务类型--自营或银保
	private String inspectdate;//业务类型--自营或银保
	private String videoUrl;//视频地址
	private String imgUrl;//图片地址
	private String pointtext;//质检要点pointtext desctext
	private String desctext;//话术内容
	private String pointor;//要点顺序
	private String timpoint;//图片节点mainpointid,describeid
	private String mainpointid;//质检要点id
	private String describeid;//话术id
	private String txt;
	private String mangcode;//组织机构代码
	private Date datestar;//开始时间
	private Date dateend;//结束时间
	private Date startUploadDate;//上传开始时间
	private Date endUploadDate;//上传终止时间
	private String appntidno;//投保人身份证号
	private String appntidtype;//投保人证件类型
	private String appntidimg;//投保人证件图片
	private Date appntbirthday;//投保人生日
	private String  appntadress;//投保人地址
	private String appntsex;//投保人性别
	private String insuredname;//被保人姓名
	private String insuredtype;//被保人证件类型
	private String insuredimg;//被保人证件类型
	private String insuredno;//被保人证件号
	private String insuredbirthday;//被保人生日
	private String insuredadress;//被保人地址
	private String insuredsex;//被保人性别
	private String insuredage;//被保人年龄
	private Date recdate;//录制日期
	private String rectime;//录制时间
	private Date uploaddate;//上传日期
	private String uploadtime;//上传时间
	private String recduration;//录制时长
	private String pagesuffix;//文件后缀
	private String incode;//机构
	private String resourse;//数据来源
	private String qcrecordcount;//质检次数
	private String businessno;//业务流水号
	private String mangname;//网点名称
	private String appntno;//客户号
	private String businesstype;//业务类型
	private String productname;//产品名称
	private String productcode;//产品编码
	private String businesstypecode;//业务类型编码
	private String numpages;
	private String company;
	private String appntNo;//客户号
	private String mangShortName;//网点缩写
	private String businessTypeName;//业务类型名称
	private String productName;//产品名称
	private String financedCode;//理财室编号
	private String financedShortName;//理财室网点缩写
	private String businessTypeCode;//业务类型编码
	private String startUploadDates;//上传开始时间
	private String endUploadDates;//上传终止时间
	
	
	public String getStatus3() {
		return status3;
	}
	public void setStatus3(String status3) {
		this.status3 = status3;
	}
	public String getStatus4() {
		return status4;
	}
	public void setStatus4(String status4) {
		this.status4 = status4;
	}
	public String getStatus5() {
		return status5;
	}
	public void setStatus5(String status5) {
		this.status5 = status5;
	}
	public String getStatus6() {
		return status6;
	}
	public void setStatus6(String status6) {
		this.status6 = status6;
	}
	public String getStatus7() {
		return status7;
	}
	public void setStatus7(String status7) {
		this.status7 = status7;
	}
	public String getStatus8() {
		return status8;
	}
	public void setStatus8(String status8) {
		this.status8 = status8;
	}
	public String getStatus2() {
		return status2;
	}
	public void setStatus2(String status2) {
		this.status2 = status2;
	}
	public String getStartUploadDates() {
		return startUploadDates;
	}
	public void setStartUploadDates(String startUploadDates) {
		this.startUploadDates = startUploadDates;
	}
	public String getEndUploadDates() {
		return endUploadDates;
	}
	public void setEndUploadDates(String endUploadDates) {
		this.endUploadDates = endUploadDates;
	}
	public String getNumpages() {
		return numpages;
	}
	public void setNumpages(String numpages) {
		this.numpages = numpages;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public String getAppntNo() {
		return appntNo;
	}
	public void setAppntNo(String appntNo) {
		this.appntNo = appntNo;
	}
	public String getMangShortName() {
		return mangShortName;
	}
	public void setMangShortName(String mangShortName) {
		this.mangShortName = mangShortName;
	}
	public String getBusinessTypeName() {
		return businessTypeName;
	}
	public void setBusinessTypeName(String businessTypeName) {
		this.businessTypeName = businessTypeName;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getFinancedCode() {
		return financedCode;
	}
	public void setFinancedCode(String financedCode) {
		this.financedCode = financedCode;
	}
	public String getFinancedShortName() {
		return financedShortName;
	}
	public void setFinancedShortName(String financedShortName) {
		this.financedShortName = financedShortName;
	}
	public String getBusinessTypeCode() {
		return businessTypeCode;
	}
	public void setBusinessTypeCode(String businessTypeCode) {
		this.businessTypeCode = businessTypeCode;
	}
	public String getDocid() {
		return docid;
	}
	public void setDocid(String docid) {
		this.docid = docid;
	}
	public String getDocidVo() {
		return docidVo;
	}
	public void setDocidVo(String docidVo) {
		this.docidVo = docidVo;
	}
	public String getBeforebusinessno() {
		return beforebusinessno;
	}
	public void setBeforebusinessno(String beforebusinessno) {
		this.beforebusinessno = beforebusinessno;
	}
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public String getBusstype() {
		return busstype;
	}
	public void setBusstype(String busstype) {
		this.busstype = busstype;
	}
	public String getSubtype() {
		return subtype;
	}
	public void setSubtype(String subtype) {
		this.subtype = subtype;
	}
	public String getBirthday() {
		return birthday;
	}
	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public String getCreateDatetime() {
		return createDatetime;
	}
	public void setCreateDatetime(String createDatetime) {
		this.createDatetime = createDatetime;
	}
	public Date getModifyDate() {
		return modifyDate;
	}
	public void setModifyDate(Date modifyDate) {
		this.modifyDate = modifyDate;
	}
	public String getOperator() {
		return operator;
	}
	public void setOperator(String operator) {
		this.operator = operator;
	}
	public String getPageid() {
		return pageid;
	}
	public void setPageid(String pageid) {
		this.pageid = pageid;
	}
	public String getHostname() {
		return hostname;
	}
	public void setHostname(String hostname) {
		this.hostname = hostname;
	}
	public String getFiletype() {
		return filetype;
	}
	public void setFiletype(String filetype) {
		this.filetype = filetype;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getPagename() {
		return pagename;
	}
	public void setPagename(String pagename) {
		this.pagename = pagename;
	}
	public String getImgtimepoint() {
		return imgtimepoint;
	}
	public void setImgtimepoint(String imgtimepoint) {
		this.imgtimepoint = imgtimepoint;
	}
	public String getPicpathftp() {
		return picpathftp;
	}
	public void setPicpathftp(String picpathftp) {
		this.picpathftp = picpathftp;
	}
	public Date getStartScanDate() {
		return startScanDate;
	}
	public void setStartScanDate(Date startScanDate) {
		this.startScanDate = startScanDate;
	}
	public Date getEndScanDate() {
		return endScanDate;
	}
	public void setEndScanDate(Date endScanDate) {
		this.endScanDate = endScanDate;
	}
	public String getMiddle() {
		return middle;
	}
	public void setMiddle(String middle) {
		this.middle = middle;
	}
	public String getUUID() {
		return UUID;
	}
	public void setUUID(String uUID) {
		UUID = uUID;
	}
	public String getRisktypename() {
		return risktypename;
	}
	public void setRisktypename(String risktypename) {
		this.risktypename = risktypename;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public int getDays() {
		return days;
	}
	public void setDays(int days) {
		this.days = days;
	}
	public String getUploaddates() {
		return uploaddates;
	}
	public void setUploaddates(String uploaddates) {
		this.uploaddates = uploaddates;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public String getIsFirstUpload() {
		return isFirstUpload;
	}
	public void setIsFirstUpload(String isFirstUpload) {
		this.isFirstUpload = isFirstUpload;
	}
	public String getNotify() {
		return notify;
	}
	public void setNotify(String notify) {
		this.notify = notify;
	}
	public String getPlayer() {
		return player;
	}
	public void setPlayer(String player) {
		this.player = player;
	}
	public String getIsback() {
		return isback;
	}
	public void setIsback(String isback) {
		this.isback = isback;
	}
	public String getResoursemin() {
		return resoursemin;
	}
	public void setResoursemin(String resoursemin) {
		this.resoursemin = resoursemin;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getBuno() {
		return buno;
	}
	public void setBuno(String buno) {
		this.buno = buno;
	}
	public String getBebuno() {
		return bebuno;
	}
	public void setBebuno(String bebuno) {
		this.bebuno = bebuno;
	}
	public String getDoccode() {
		return doccode;
	}
	public void setDoccode(String doccode) {
		this.doccode = doccode;
	}
	public String getDoccodevo() {
		return doccodevo;
	}
	public void setDoccodevo(String doccodevo) {
		this.doccodevo = doccodevo;
	}
	public String getRisktype() {
		return risktype;
	}
	public void setRisktype(String risktype) {
		this.risktype = risktype;
	}
	public String getAgentname() {
		return agentname;
	}
	public void setAgentname(String agentname) {
		this.agentname = agentname;
	}
	public String getAgentid() {
		return agentid;
	}
	public void setAgentid(String agentid) {
		this.agentid = agentid;
	}
	public String getAgentPhone() {
		return agentPhone;
	}
	public void setAgentPhone(String agentPhone) {
		this.agentPhone = agentPhone;
	}
	public String getAgentWorkFlag() {
		return agentWorkFlag;
	}
	public void setAgentWorkFlag(String agentWorkFlag) {
		this.agentWorkFlag = agentWorkFlag;
	}
	public String getAgentChannelname() {
		return agentChannelname;
	}
	public void setAgentChannelname(String agentChannelname) {
		this.agentChannelname = agentChannelname;
	}
	public String getDatatype() {
		return datatype;
	}
	public void setDatatype(String datatype) {
		this.datatype = datatype;
	}
	public String getNum() {
		return num;
	}
	public void setNum(String num) {
		this.num = num;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getVerdict() {
		return verdict;
	}
	public void setVerdict(String verdict) {
		this.verdict = verdict;
	}
	public String getAppntname() {
		return appntname;
	}
	public void setAppntname(String appntname) {
		this.appntname = appntname;
	}
	public String getAppntage() {
		return appntage;
	}
	public void setAppntage(String appntage) {
		this.appntage = appntage;
	}
	public String getPolapplydate() {
		return polapplydate;
	}
	public void setPolapplydate(String polapplydate) {
		this.polapplydate = polapplydate;
	}
	public String getQcoperator() {
		return qcoperator;
	}
	public void setQcoperator(String qcoperator) {
		this.qcoperator = qcoperator;
	}
	public String getQcoperator1() {
		return qcoperator1;
	}
	public void setQcoperator1(String qcoperator1) {
		this.qcoperator1 = qcoperator1;
	}
	public String getAttribute() {
		return attribute;
	}
	public void setAttribute(String attribute) {
		this.attribute = attribute;
	}
	public String getRisktypecode() {
		return risktypecode;
	}
	public void setRisktypecode(String risktypecode) {
		this.risktypecode = risktypecode;
	}
	public Date getModifydate() {
		return modifydate;
	}
	public void setModifydate(Date modifydate) {
		this.modifydate = modifydate;
	}
	public String getBankcode() {
		return bankcode;
	}
	public void setBankcode(String bankcode) {
		this.bankcode = bankcode;
	}
	public String getBanknetwork() {
		return banknetwork;
	}
	public void setBanknetwork(String banknetwork) {
		this.banknetwork = banknetwork;
	}
	public String getProperson() {
		return properson;
	}
	public void setProperson(String properson) {
		this.properson = properson;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getOperation() {
		return operation;
	}
	public void setOperation(String operation) {
		this.operation = operation;
	}
	public String getInspectdate() {
		return inspectdate;
	}
	public void setInspectdate(String inspectdate) {
		this.inspectdate = inspectdate;
	}
	public String getVideoUrl() {
		return videoUrl;
	}
	public void setVideoUrl(String videoUrl) {
		this.videoUrl = videoUrl;
	}
	public String getImgUrl() {
		return imgUrl;
	}
	public void setImgUrl(String imgUrl) {
		this.imgUrl = imgUrl;
	}
	public String getPointtext() {
		return pointtext;
	}
	public void setPointtext(String pointtext) {
		this.pointtext = pointtext;
	}
	public String getDesctext() {
		return desctext;
	}
	public void setDesctext(String desctext) {
		this.desctext = desctext;
	}
	public String getPointor() {
		return pointor;
	}
	public void setPointor(String pointor) {
		this.pointor = pointor;
	}
	public String getTimpoint() {
		return timpoint;
	}
	public void setTimpoint(String timpoint) {
		this.timpoint = timpoint;
	}
	public String getMainpointid() {
		return mainpointid;
	}
	public void setMainpointid(String mainpointid) {
		this.mainpointid = mainpointid;
	}
	public String getDescribeid() {
		return describeid;
	}
	public void setDescribeid(String describeid) {
		this.describeid = describeid;
	}
	public String getTxt() {
		return txt;
	}
	public void setTxt(String txt) {
		this.txt = txt;
	}
	public String getMangcode() {
		return mangcode;
	}
	public void setMangcode(String mangcode) {
		this.mangcode = mangcode;
	}
	public Date getDatestar() {
		return datestar;
	}
	public void setDatestar(Date datestar) {
		this.datestar = datestar;
	}
	public Date getDateend() {
		return dateend;
	}
	public void setDateend(Date dateend) {
		this.dateend = dateend;
	}
	public Date getStartUploadDate() {
		return startUploadDate;
	}
	public void setStartUploadDate(Date startUploadDate) {
		this.startUploadDate = startUploadDate;
	}
	public Date getEndUploadDate() {
		return endUploadDate;
	}
	public void setEndUploadDate(Date endUploadDate) {
		this.endUploadDate = endUploadDate;
	}
	public String getAppntidno() {
		return appntidno;
	}
	public void setAppntidno(String appntidno) {
		this.appntidno = appntidno;
	}
	public String getAppntidtype() {
		return appntidtype;
	}
	public void setAppntidtype(String appntidtype) {
		this.appntidtype = appntidtype;
	}
	public String getAppntidimg() {
		return appntidimg;
	}
	public void setAppntidimg(String appntidimg) {
		this.appntidimg = appntidimg;
	}
	public String getAppntadress() {
		return appntadress;
	}
	public void setAppntadress(String appntadress) {
		this.appntadress = appntadress;
	}
	public String getAppntsex() {
		return appntsex;
	}
	public void setAppntsex(String appntsex) {
		this.appntsex = appntsex;
	}
	public String getInsuredname() {
		return insuredname;
	}
	public void setInsuredname(String insuredname) {
		this.insuredname = insuredname;
	}
	public String getInsuredtype() {
		return insuredtype;
	}
	public void setInsuredtype(String insuredtype) {
		this.insuredtype = insuredtype;
	}
	public String getInsuredimg() {
		return insuredimg;
	}
	public void setInsuredimg(String insuredimg) {
		this.insuredimg = insuredimg;
	}
	public String getInsuredno() {
		return insuredno;
	}
	public void setInsuredno(String insuredno) {
		this.insuredno = insuredno;
	}
	public String getInsuredbirthday() {
		return insuredbirthday;
	}
	public void setInsuredbirthday(String insuredbirthday) {
		this.insuredbirthday = insuredbirthday;
	}
	public String getInsuredadress() {
		return insuredadress;
	}
	public void setInsuredadress(String insuredadress) {
		this.insuredadress = insuredadress;
	}
	public String getInsuredsex() {
		return insuredsex;
	}
	public void setInsuredsex(String insuredsex) {
		this.insuredsex = insuredsex;
	}
	public String getInsuredage() {
		return insuredage;
	}
	public void setInsuredage(String insuredage) {
		this.insuredage = insuredage;
	}
	public String getRectime() {
		return rectime;
	}
	public void setRectime(String rectime) {
		this.rectime = rectime;
	}
	public String getUploadtime() {
		return uploadtime;
	}
	public void setUploadtime(String uploadtime) {
		this.uploadtime = uploadtime;
	}
	public String getRecduration() {
		return recduration;
	}
	public void setRecduration(String recduration) {
		this.recduration = recduration;
	}
	public String getPagesuffix() {
		return pagesuffix;
	}
	public void setPagesuffix(String pagesuffix) {
		this.pagesuffix = pagesuffix;
	}
	public String getIncode() {
		return incode;
	}
	public void setIncode(String incode) {
		this.incode = incode;
	}
	public String getResourse() {
		return resourse;
	}
	public void setResourse(String resourse) {
		this.resourse = resourse;
	}
	public String getQcrecordcount() {
		return qcrecordcount;
	}
	public void setQcrecordcount(String qcrecordcount) {
		this.qcrecordcount = qcrecordcount;
	}
	public String getBusinessno() {
		return businessno;
	}
	public void setBusinessno(String businessno) {
		this.businessno = businessno;
	}
	public String getMangname() {
		return mangname;
	}
	public void setMangname(String mangname) {
		this.mangname = mangname;
	}
	public String getAppntno() {
		return appntno;
	}
	public void setAppntno(String appntno) {
		this.appntno = appntno;
	}
	public String getBusinesstype() {
		return businesstype;
	}
	public void setBusinesstype(String businesstype) {
		this.businesstype = businesstype;
	}
	public String getProductname() {
		return productname;
	}
	public void setProductname(String productname) {
		this.productname = productname;
	}
	public String getProductcode() {
		return productcode;
	}
	public void setProductcode(String productcode) {
		this.productcode = productcode;
	}
	public String getRecdates() {
		return recdates;
	}
	public void setRecdates(String recdates) {
		this.recdates = recdates;
	}
	public Date getRecdate() {
		return recdate;
	}
	public void setRecdate(Date recdate) {
		this.recdate = recdate;
	}
	public Date getAppntbirthday() {
		return appntbirthday;
	}
	public void setAppntbirthday(Date appntbirthday) {
		this.appntbirthday = appntbirthday;
	}
	public Date getUploaddate() {
		return uploaddate;
	}
	public void setUploaddate(Date uploaddate) {
		this.uploaddate = uploaddate;
	}
	public String getBusinesstypecode() {
		return businesstypecode;
	}
	public void setBusinesstypecode(String businesstypecode) {
		this.businesstypecode = businesstypecode;
	}
}