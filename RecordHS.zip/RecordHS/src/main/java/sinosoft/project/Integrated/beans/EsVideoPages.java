package sinosoft.project.Integrated.beans;

import java.util.Date;

public class EsVideoPages {
    private String pageid;

    private String docid;

    private String hostname;

    private String businessno;

    private String busstype;

    private String subtype;

    private String filetype;

    private String url;

    private String pagename;

    private String pagesuffix;

    private String imgtimepoint;

    private String describeid;

    private Date recdate;

    private String rectime;

    private String recduration;

    private Date createDate;

    private Date modifyDate;

    private String operator;

    private String picpathftp;

    private String picftp;

    private String requestid;

    private String viocetext;
    

    public String getPageid() {
        return pageid;
    }

    public void setPageid(String pageid) {
        this.pageid = pageid == null ? null : pageid.trim();
    }

    public String getDocid() {
        return docid;
    }

    public void setDocid(String docid) {
        this.docid = docid == null ? null : docid.trim();
    }

    public String getHostname() {
        return hostname;
    }

    public void setHostname(String hostname) {
        this.hostname = hostname == null ? null : hostname.trim();
    }

    public String getBusinessno() {
        return businessno;
    }

    public void setBusinessno(String businessno) {
        this.businessno = businessno == null ? null : businessno.trim();
    }

    public String getBusstype() {
        return busstype;
    }

    public void setBusstype(String busstype) {
        this.busstype = busstype == null ? null : busstype.trim();
    }

    public String getSubtype() {
        return subtype;
    }

    public void setSubtype(String subtype) {
        this.subtype = subtype == null ? null : subtype.trim();
    }

    public String getFiletype() {
        return filetype;
    }

    public void setFiletype(String filetype) {
        this.filetype = filetype == null ? null : filetype.trim();
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url == null ? null : url.trim();
    }

    public String getPagename() {
        return pagename;
    }

    public void setPagename(String pagename) {
        this.pagename = pagename == null ? null : pagename.trim();
    }

    public String getPagesuffix() {
        return pagesuffix;
    }

    public void setPagesuffix(String pagesuffix) {
        this.pagesuffix = pagesuffix == null ? null : pagesuffix.trim();
    }

    public String getImgtimepoint() {
        return imgtimepoint;
    }

    public void setImgtimepoint(String imgtimepoint) {
        this.imgtimepoint = imgtimepoint == null ? null : imgtimepoint.trim();
    }

    public String getDescribeid() {
        return describeid;
    }

    public void setDescribeid(String describeid) {
        this.describeid = describeid == null ? null : describeid.trim();
    }

    public Date getRecdate() {
        return recdate;
    }

    public void setRecdate(Date recdate) {
        this.recdate = recdate;
    }

    public String getRectime() {
        return rectime;
    }

    public void setRectime(String rectime) {
        this.rectime = rectime == null ? null : rectime.trim();
    }

    public String getRecduration() {
        return recduration;
    }

    public void setRecduration(String recduration) {
        this.recduration = recduration == null ? null : recduration.trim();
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getModifyDate() {
        return modifyDate;
    }

    public void setModifyDate(Date modifyDate) {
        this.modifyDate = modifyDate;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator == null ? null : operator.trim();
    }

    public String getPicpathftp() {
        return picpathftp;
    }

    public void setPicpathftp(String picpathftp) {
        this.picpathftp = picpathftp == null ? null : picpathftp.trim();
    }

    public String getPicftp() {
        return picftp;
    }

    public void setPicftp(String picftp) {
        this.picftp = picftp == null ? null : picftp.trim();
    }

    public String getRequestid() {
        return requestid;
    }

    public void setRequestid(String requestid) {
        this.requestid = requestid == null ? null : requestid.trim();
    }

    public String getViocetext() {
        return viocetext;
    }

    public void setViocetext(String viocetext) {
        this.viocetext = viocetext == null ? null : viocetext.trim();
    }
}