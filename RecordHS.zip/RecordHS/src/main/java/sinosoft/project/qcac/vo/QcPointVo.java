package sinosoft.project.qcac.vo;

public class QcPointVo {
	private String idor;//主表id
	private String pointid;//要点id
	private String pointtext;//要点内容
	private String tallid;//话述要点
	private String talltext;//话述内容
	private String status;//整改状态
	private String pointAttention;//注意事项
	private String imgTimePointOrder;
	
	public String getImgTimePointOrder() {
		return imgTimePointOrder;
	}
	public void setImgTimePointOrder(String imgTimePointOrder) {
		this.imgTimePointOrder = imgTimePointOrder;
	}
	public String getPointAttention() {
		return pointAttention;
	}
	public void setPointAttention(String pointAttention) {
		this.pointAttention = pointAttention;
	}
	private String order;//话述顺序号
	private String describeid;//话述id
	private String risktypecode;//产品编码
	private String risktypename;//产品名称
	private String comcode;//组织机构编码
	
	private String risktype;//产品类型
	private String qcpointcode;//要点编码
	
	private String checkd;
	
	
	public String getQcpointcode() {
		return qcpointcode;
	}
	public void setQcpointcode(String qcpointcode) {
		this.qcpointcode = qcpointcode;
	}
	public String getRisktype() {
		return risktype;
	}
	public void setRisktype(String risktype) {
		this.risktype = risktype;
	}
	public String getCheckd() {
		return checkd;
	}
	public void setCheckd(String checkd) {
		this.checkd = checkd;
	}
	public String getIdor() {
		return idor;
	}
	public void setIdor(String idor) {
		this.idor = idor;
	}
	public String getComcode() {
		return comcode;
	}
	public void setComcode(String comcode) {
		this.comcode = comcode;
	}
	public String getRisktypename() {
		return risktypename;
	}
	public void setRisktypename(String risktypename) {
		this.risktypename = risktypename;
	}
	public String getRisktypecode() {
		return risktypecode;
	}
	public void setRisktypecode(String risktypecode) {
		this.risktypecode = risktypecode;
	}
	public String getOrder() {
		return order;
	}
	public void setOrder(String order) {
		this.order = order;
	}
	public String getDescribeid() {
		return describeid;
	}
	public void setDescribeid(String describeid) {
		this.describeid = describeid;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getPointid() {
		return pointid;
	}
	public void setPointid(String pointid) {
		this.pointid = pointid;
	}
	public String getPointtext() {
		return pointtext;
	}
	public void setPointtext(String pointtext) {
		this.pointtext = pointtext;
	}
	public String getTallid() {
		return tallid;
	}
	public void setTallid(String tallid) {
		this.tallid = tallid;
	}
	public String getTalltext() {
		return talltext;
	}
	public void setTalltext(String talltext) {
		this.talltext = talltext;
	}
	
	
}
