package sinosoft.project.qcac.vo;

import java.util.Date;

public class TroubleInfosVo {
	private String issuetypes;
	private String issuedesc;
	private String doccode;
	private String replydate;
	private String status;
	private String id;
	private String idvo; 
	private String remark;//再次质检标志
	private String qcsecondid;
    private String businessno;
    private String qcid;
    private String sum; 
    private Date issuedate;
    private Date modifyDatetime;
    private String operator;
    private String qcoperator;
    private String agentid;
	
	
	public String getBusinessno() {
		return businessno;
	}
	public void setBusinessno(String businessno) {
		this.businessno = businessno;
	}
	public String getQcid() {
		return qcid;
	}
	public void setQcid(String qcid) {
		this.qcid = qcid;
	}
	public String getSum() {
		return sum;
	}
	public void setSum(String sum) {
		this.sum = sum;
	}
	public Date getIssuedate() {
		return issuedate;
	}
	public void setIssuedate(Date issuedate) {
		this.issuedate = issuedate;
	}
	public Date getModifyDatetime() {
		return modifyDatetime;
	}
	public void setModifyDatetime(Date modifyDatetime) {
		this.modifyDatetime = modifyDatetime;
	}
	public String getOperator() {
		return operator;
	}
	public void setOperator(String operator) {
		this.operator = operator;
	}
	public String getQcoperator() {
		return qcoperator;
	}
	public void setQcoperator(String qcoperator) {
		this.qcoperator = qcoperator;
	}
	public String getAgentid() {
		return agentid;
	}
	public void setAgentid(String agentid) {
		this.agentid = agentid;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getQcsecondid() {
		return qcsecondid;
	}
	public void setQcsecondid(String qcsecondid) {
		this.qcsecondid = qcsecondid;
	}
	public String getIdvo() {
		return idvo;
	}
	public void setIdvo(String idvo) {
		this.idvo = idvo;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getIssuetypes() {
		return issuetypes;
	}
	public void setIssuetypes(String issuetypes) {
		this.issuetypes = issuetypes;
	}
	public String getIssuedesc() {
		return issuedesc;
	}
	public void setIssuedesc(String issuedesc) {
		this.issuedesc = issuedesc;
	}
	public String getDoccode() {
		return doccode;
	}
	public void setDoccode(String doccode) {
		this.doccode = doccode;
	}
	public String getReplydate() {
		return replydate;
	}
	public void setReplydate(String replydate) {
		this.replydate = replydate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
}
