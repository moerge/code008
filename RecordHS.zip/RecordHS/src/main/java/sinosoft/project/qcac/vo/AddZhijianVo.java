package sinosoft.project.qcac.vo;

import java.util.List;

public class AddZhijianVo {
    String remarks;
    String verdict;
    String doccode ;
    List<String> issuetypes;
    java.util.List<String> issuedesc;

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getVerdict() {
        return verdict;
    }

    public void setVerdict(String verdict) {
        this.verdict = verdict;
    }

    public String getDoccode() {
        return doccode;
    }

    public void setDoccode(String doccode) {
        this.doccode = doccode;
    }

    public List<String> getIssuetypes() {
        return issuetypes;
    }

    public void setIssuetypes(List<String> issuetypes) {
        this.issuetypes = issuetypes;
    }

    public List<String> getIssuedesc() {
        return issuedesc;
    }

    public void setIssuedesc(List<String> issuedesc) {
        this.issuedesc = issuedesc;
    }
}
