package sinosoft.project.entity;


public class QcMainList {
    String id;
    String qcid;
    String doccode;
    String businessno;
    String issuetypes;
    String issuedesc;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getQcid() {
        return qcid;
    }

    public void setQcid(String qcid) {
        this.qcid = qcid;
    }

    public String getDoccode() {
        return doccode;
    }

    public void setDoccode(String doccode) {
        this.doccode = doccode;
    }

    public String getBusinessno() {
        return businessno;
    }

    public void setBusinessno(String businessno) {
        this.businessno = businessno;
    }

    public String getIssuetypes() {
        return issuetypes;
    }

    public void setIssuetypes(String issuetypes) {
        this.issuetypes = issuetypes;
    }

    public String getIssuedesc() {
        return issuedesc;
    }

    public void setIssuedesc(String issuedesc) {
        this.issuedesc = issuedesc;
    }
}