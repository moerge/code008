package sinosoft.project.dockingface.qc;

import java.util.Date;

public class Quality {
    private String issueid;

    private String questiondesc;

    private String questionleix;

    private String qualityId;

    private String doccode;

    private String sum;

    private Date replydate;

    private String status;

    private Date createDatetime;
    private String createDate;
    
    private String qcrecordcount;
    
    private String remarks;
    
    
    public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getQcrecordcount() {
		return qcrecordcount;
	}

	public void setQcrecordcount(String qcrecordcount) {
		this.qcrecordcount = qcrecordcount;
	}

	public String getCreateDate() {
		return createDate;
	}

	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

	private Date modifyDatetime;

    private String operator;

    private String qcoperator;

    private String agentid;
    
    private String troubletype;
    
    private String troublerelate; 

    public String getTroubletype() {
		return troubletype;
	}

	public void setTroubletype(String troubletype) {
		this.troubletype = troubletype;
	}

	public String getTroublerelate() {
		return troublerelate;
	}

	public void setTroublerelate(String troublerelate) {
		this.troublerelate = troublerelate;
	}

	public String getIssueid() {
        return issueid;
    }

    public void setIssueid(String issueid) {
        this.issueid = issueid == null ? null : issueid.trim();
    }

    public String getQuestiondesc() {
        return questiondesc;
    }

    public void setQuestiondesc(String questiondesc) {
        this.questiondesc = questiondesc == null ? null : questiondesc.trim();
    }

    public String getQuestionleix() {
        return questionleix;
    }

    public void setQuestionleix(String questionleix) {
        this.questionleix = questionleix == null ? null : questionleix.trim();
    }

    public String getQualityId() {
        return qualityId;
    }

    public void setQualityId(String qualityId) {
        this.qualityId = qualityId == null ? null : qualityId.trim();
    }

    public String getDoccode() {
        return doccode;
    }

    public void setDoccode(String doccode) {
        this.doccode = doccode == null ? null : doccode.trim();
    }

    public String getSum() {
        return sum;
    }

    public void setSum(String sum) {
        this.sum = sum == null ? null : sum.trim();
    }

    public Date getReplydate() {
        return replydate;
    }

    public void setReplydate(Date replydate) {
        this.replydate = replydate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status == null ? null : status.trim();
    }

    public Date getCreateDatetime() {
        return createDatetime;
    }

    public void setCreateDatetime(Date createDatetime) {
        this.createDatetime = createDatetime;
    }

    public Date getModifyDatetime() {
        return modifyDatetime;
    }

    public void setModifyDatetime(Date modifyDatetime) {
        this.modifyDatetime = modifyDatetime;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator == null ? null : operator.trim();
    }

    public String getQcoperator() {
        return qcoperator;
    }

    public void setQcoperator(String qcoperator) {
        this.qcoperator = qcoperator == null ? null : qcoperator.trim();
    }

    public String getAgentid() {
        return agentid;
    }

    public void setAgentid(String agentid) {
        this.agentid = agentid == null ? null : agentid.trim();
    }
}