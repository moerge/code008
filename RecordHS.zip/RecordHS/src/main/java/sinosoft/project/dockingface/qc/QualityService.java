package sinosoft.project.dockingface.qc;

import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import sinosoft.framework.core.base.BaseServiceImpl;
import sinosoft.project.dao.TroubleMapper;
import sinosoft.project.entity.Trouble;
import sinosoft.project.qcac.vo.QcPointVo;

@Service("qualityService")
public class QualityService extends BaseServiceImpl{

	private static final Logger logger = LoggerFactory.getLogger(QualityService.class);

	@Resource
	private QualityMapper qm;
	@Resource
	private TroubleMapper troubleMapper;
	public  Quality  getQuality(String buno){
		List<Quality> quality = qm.queryQuality(buno);
//		Quality quality2 = new Quality();
		String doccode = "";
		for (Quality quality2 : quality) {
			doccode += quality2.getDoccode()+",";
		}
		doccode = doccode.substring(0,doccode.length()-1);
		for (Quality quality2 : quality) {
			quality2.setDoccode(doccode);

		}
		try {
			if(quality.get(0).getTroubletype()!=null){
				String[] arr = quality.get(0).getTroubletype().split(";");
				String troubletype = "";
				for (String tsid : arr){
					Trouble describe =  troubleMapper.selectByPrimaryKey(tsid);
					troubletype += describe.getIssueType()+";";
				}
				quality.get(0).setTroubletype(troubletype);
			}
			return quality.get(0);
		}catch (Exception e){
			logger.info("getQuality error {}",e.getMessage());
			return new Quality();
		}


	}



	public  List<Quality>  getWenTiList(String buno, String string){
		if(!"0".equalsIgnoreCase(string)){
				List<Quality> list = qm.queryWenTiList(buno, string);
				return list;

		}else{
			List<Quality> list = qm.queryWenTiList1(buno, string);
			String doccode = "";
			for (Quality quality2 : list) {
				doccode += quality2.getDoccode()+",";
			}
			doccode = doccode.substring(0,doccode.length()-1);
			for (Quality quality2 : list) {
				quality2.setDoccode(doccode);
			}
			return list;
		}


	}


	public  List<QcPointVo>  getWenTiPointList(String bussno,String risktypecode){
		String risk = "";
		String riskcode = "";
		String riskname = "";
		for (int i = 0; i < risktypecode.split(",").length; i++) {
			risk += "'"+risktypecode.split(",")[i]+"',";
			riskcode += risktypecode.split(",")[i]+",";
			riskname += getriskName(risktypecode.split(",")[i])+",";
		}
		risk = risk.substring(0,risk.length()-1);
		riskcode = riskcode.substring(0,riskcode.length()-1);
		riskname = riskname.substring(0,riskname.length()-1);
		List<QcPointVo> list = qm.queryWenTiPointList(this.newSqlParam().add("bussno", bussno).add("risktypecode", risk));
		logger.info("qm.queryWenTiPointList( bussno: {} , risktypecode: {}) >> {}",
				bussno, risk, list);
		for (QcPointVo qcPointVo : list) {
			qcPointVo.setRisktypecode(riskcode);
			qcPointVo.setRisktypename(riskname);
		}
		return list;
	}



	private String getriskName(String string) {

		return qm.getriskName(string);
	}




}
