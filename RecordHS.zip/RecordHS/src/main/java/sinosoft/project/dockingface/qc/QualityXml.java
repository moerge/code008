package sinosoft.project.dockingface.qc;

import java.io.IOException;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;
import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.context.ContextLoader;
import org.xml.sax.InputSource;

import sinosoft.platform.utils.Util;
import sinosoft.platform.webservice.axis2.util.Axis2Util;
import sinosoft.platform.webservice.axis2.util.HttpPostUtil;
import sinosoft.platform.webservice.axis2.util.XmlToJSON;
import sinosoft.platform.webservice.common.BaseXmlNodeConstants;
import sinosoft.platform.webservice.common.XmlNodeConstants;
import sinosoft.platform.webservice.service.InterFaceService;
import sinosoft.project.dockingface.util.SpringUtil;
import sinosoft.project.entity.InterfaceManage;
import sinosoft.project.qcac.vo.QcPointVo;

public class QualityXml extends BaseXmlNodeConstants {
	public static final String XML_TRANSBODY = "TRANSBODY";
	public static final String XML_QCFEEDBACKS = "QCFEEDBACKS";
	public static final String XML_QCFEEDBACKCOUNT = "QCFEEDBACKCOUNT";
	public static final String XML_QCFEEDBACK = "QCFEEDBACK";
	public static final String XML_BUSINESSNO = "BUSINESSNO";
	public static final String XML_DOCCODE = "DOCCODE";
	public static final String XML_ISSUETYPES = "ISSUETYPES";
	public static final String XML_ISSUEDESC = "ISSUEDESC";
	public static final String XML_ISSUEDATE = "ISSUEDATE";
	public static final String XML_QCOPERATOR = "QCOPERATOR";
	public static final String XML_AGENTID = "AGENTID";
	public static final String XML_ISFLAG = "ISFLAG";
	public static final String XML_QCPOINTS = "QCPOINTS";
	public static final String XML_QCPOINTCOUNT = "QCPOINTCOUNT";
	private static final String XML_QCPOINT = "QCPOINT";
	private static final String XML_DESCRIBEID = "DESCRIBEID";
	private static final String XML_QCPOINTTXT = "QCPOINTTXT";
	private static final String XML_QCTRICKTXT = "QCTRICKTXT";
	private static final String XML_ORDERNO = "ORDERNO";
	private static final String XML_QCRECORDCOUNT = "QCRECORDCOUNT";
	private static final String XML_QCQUESTIONS = "QCQUESTIONS";
	private static final String XML_RISKTYPECODE = "RISKTYPECODE";

    public final static String XML_VERBALS_VERBALCOUNT = "VERBALCOUNT";
    public final static String XML_VERBAL = "VERBAL";
    public final static String XML_VERBAL_INSCODE = "COMPANY";
    public final static String XML_VERBAL_TRICKID = "DESCRIBEID";
    public final static String XML_VERBAL_RISKTYPECODE = "RISKTYPECODE";
    public final static String XML_VERBAL_RISKTYPENAME = "RISKTYPENAME";
    public final static String XML_VERBAL_QCPOINT = "QCPOINT";
    public final static String XML_VERBAL_QCTRICK = "QCTRICK";
    public final static String XML_VERBAL_ORDERNO = "ORDERNO";
	private static final String XML_VERBAL_COMCODE = "COMCODE";
    public final static String XML_VERBAL_RISKCODE = "RISKCODE";
    public final static String XML_VERBAL_RISKNAME = "RISKNAME";
    public final static String XML_VERBAL_RISKTYPE = "RISKTYPE";
    public final static String XML_VERBAL_QCPOINTCODE = "QCPOINTCODE";
    public final static String XML_REMARKS = "REMARKS";
	public static String code = "";
    private static final Logger logger = LoggerFactory.getLogger(QualityXml.class);

    public static String generateResultXml(String code, String buno, String string) {
		String result = "";
        QualityService qualityService = (QualityService) SpringUtil.getBean("qualityService");
        try {
			// 创建xml根节点
			Element root = new Element(XmlNodeConstants.XML_ROOT);
			Element head = generateHeadXml(code);
			Quality quality = qualityService.getQuality(buno);
//			Quality quality=getQuality(doccode);
			/*List<Quality> list = qualityService.getWenTiList(buno, string);*/
//			List<Quality> list = getWenTiList(doccode, string);
			List<Quality> list = new ArrayList<Quality>();
			list.add(quality);
			List<QcPointVo> listvo = qualityService.getWenTiPointList(quality.getIssueid(), quality.getQualityId());
//			List<QcPointVo> listvo2 = new ArrayList<QcPointVo>();
//			HashMap<String, QcPointVo> hashMap = new HashMap<String,QcPointVo>();
//			for (QcPointVo qcPointVo : listvo) {
//
//				/*if(!hashMap.containsKey(qcPointVo.getQcpointcode())){
//					hashMap.put(qcPointVo.getQcpointcode(), qcPointVo);
//					listvo2.add(qcPointVo);
//				}20181026*/
//				/*if(!hashMap.containsKey(qcPointVo.getTalltext())){
//					hashMap.put(qcPointVo.getTalltext(), qcPointVo);*/
//					listvo2.add(qcPointVo);
//				/*}	*/
//			}
//			List<QcPointVo> listvo = getWenTiPointList(quality.getIssueid(), quality.getQualityId());
            Element body = generateBodyXml(quality, list, listvo, string, quality.getQualityId());
			root.addContent(head);
			root.addContent(body);
			Document doc = new Document(root);
			Format format = Format.getPrettyFormat();
			format.setEncoding("UTF-8");
			XMLOutputter out = new XMLOutputter(format);

			// 把doc转换为OutputStream
			result = out.outputString(doc);
        } catch (Exception e) {
            logger.error("生成报文失败", e);
			return null;
		}
		return result;
	}

	/**
	 * 生成报文体部信息
     *
	 * @param listvo
	 * @param quality2
	 * @param string
	 * @param risktypecode
	 * @return
	 * @throws IOException
	 */
	//开发服
    private static Element generateBodyXml(Quality quality2, List<Quality> list, List<QcPointVo> listvo, String string, String risktypecode) throws IOException {
		code = Util.readProperties("company.no");
		Element body = new Element(XML_TRANSBODY);
		Element QCFEEDBACKS = new Element(XML_QCFEEDBACKS);
		Element child1 = new Element(XML_BUSINESSNO);//业务流水号
		child1.setText(DealNull(quality2.getIssueid()));
		QCFEEDBACKS.addContent(child1);
		child1 = new Element(XML_DOCCODE);//投保单号
		child1.setText(DealNull(quality2.getDoccode()));
		QCFEEDBACKS.addContent(child1);
		child1 = new Element(XML_QCRECORDCOUNT);//第几次质检
		child1.setText(DealNull(quality2.getQcrecordcount()));
		QCFEEDBACKS.addContent(child1);
		child1 = new Element(XML_AGENTID);//代理人ID
		child1.setText(DealNull(quality2.getAgentid()));
		QCFEEDBACKS.addContent(child1);
		child1 = new Element(XML_QCOPERATOR);//质检人
		child1.setText(DealNull(quality2.getQcoperator()));
		QCFEEDBACKS.addContent(child1);
		child1 = new Element(XML_ISFLAG);
        if ("0".equalsIgnoreCase(string)) {
			child1.setText(DealNull("ExamineTrue"));//质检通过
        } else if ("3".equalsIgnoreCase(string)) {
			child1.setText(DealNull("ExamineTrueRemind"));//质检通过(提醒)
        } else if ("4".equalsIgnoreCase(string)) {
			child1.setText(DealNull("ExamineUpdateTrue"));//整改完成
        } else if ("2".equalsIgnoreCase(string)) {
			child1.setText(DealNull("ExamineUpdate"));//待整改
        } else if ("11".equalsIgnoreCase(string)) {
			child1.setText(DealNull("ExamineFalse"));//整改未完成
        } else if ("12".equalsIgnoreCase(string)) {
			child1.setText(DealNull("Examinetoqcback"));//质检回退客户端状态置为待质检
        } else if ("13".equalsIgnoreCase(string)) {
			child1.setText(DealNull("ExamineRectifyoverdue"));//待整改保单过期状态置为中间态整改过期
		}
//修改0828志伟
		QCFEEDBACKS.addContent(child1);
		child1 = new Element(XML_REMARKS);//质检备注信息
		child1.setText(DealNull(quality2.getRemarks()));


		QCFEEDBACKS.addContent(child1);
		Element QCQUESTIONS = new Element(XML_QCQUESTIONS);
		Element QCFEEDBACKCOUNT = new Element(XML_QCFEEDBACKCOUNT);
        QCFEEDBACKCOUNT.setText(DealNull(list.size() + ""));
		QCQUESTIONS.addContent(QCFEEDBACKCOUNT);
		QCFEEDBACKS.addContent(QCQUESTIONS);
        if (list != null && list.size() > 0) {
            for (Quality quality : list) {
				Element QCFEEDBACK = new Element(XML_QCFEEDBACK);
				Element child = new Element(XML_DOCCODE);//
				child = new Element(XML_ISSUETYPES);//质检问题类型
				child.setText(DealNull(quality.getTroubletype()));
				QCFEEDBACK.addContent(child);
				child = new Element(XML_ISSUEDESC);//质检问题
				child.setText(DealNull(quality.getTroublerelate()));
				QCFEEDBACK.addContent(child);
				child = new Element(XML_ISSUEDATE);//问题下发时间
			/*	if(quality.getTroubletype()==null||quality.getTroublerelate()==null){
					child.setText(DealNull(null));
				}else{
					child.setText(DealNull(quality.getCreateDate().substring(0, quality.getCreateDate().lastIndexOf("."))));
				}*/

                child.setText(DealDate(quality.getCreateDate()));
				QCQUESTIONS.addContent(QCFEEDBACK);
				QCFEEDBACK.addContent(child);
			}
        } else {
			Element QCFEEDBACK = new Element(XML_QCFEEDBACK);
			Element child = new Element(XML_DOCCODE);//
			child = new Element(XML_ISSUETYPES);//质检问题类型
			QCFEEDBACK.addContent(child);
			child = new Element(XML_ISSUEDESC);//质检问题
			QCFEEDBACK.addContent(child);
			child = new Element(XML_ISSUEDATE);//问题下发时间
			QCQUESTIONS.addContent(QCFEEDBACK);
			QCFEEDBACK.addContent(child);
		}
		Element QCPOINTS = new Element(XML_QCPOINTS);

		Element VERBALCOUNT = new Element(XML_VERBALS_VERBALCOUNT);
        VERBALCOUNT.setText(DealNull(listvo.size() + ""));
		QCPOINTS.addContent(VERBALCOUNT);
        if (listvo.size() > 0 && listvo != null) {

			for (QcPointVo pointDescribe : listvo) {
				Element VERBAL = new Element(XML_VERBAL);
				Element child = new Element(XML_VERBAL_INSCODE);//保险公司代码
				child.setText(DealNull(code));
				VERBAL.addContent(child);
				child = new Element(XML_VERBAL_COMCODE);//组织机构编码
				child.setText(DealNull(pointDescribe.getComcode()));
				VERBAL.addContent(child);
				child = new Element(XML_VERBAL_TRICKID);//话术ID
				child.setText(DealNull(pointDescribe.getDescribeid()));
				VERBAL.addContent(child);

				child = new Element(XML_VERBAL_RISKCODE);//产品编码
				child.setText(DealNull(pointDescribe.getRisktypecode()));
				VERBAL.addContent(child);
				child = new Element(XML_VERBAL_RISKNAME);//产品名称
				child.setText(DealNull(pointDescribe.getRisktypename()));
				VERBAL.addContent(child);
				child = new Element(XML_VERBAL_RISKTYPE);//产品类型
				child.setText(DealNull(pointDescribe.getRisktype()));
				VERBAL.addContent(child);
				child = new Element(XML_VERBAL_QCPOINTCODE);//质检要点编码
				child.setText(DealNull(pointDescribe.getQcpointcode()));
				VERBAL.addContent(child);

				child = new Element(XML_VERBAL_QCPOINT);//质检要点
				child.setText(DealNull(pointDescribe.getPointtext()));
				VERBAL.addContent(child);
				child = new Element(XML_VERBAL_QCTRICK);//质检说明
				child.setText(DealNull(pointDescribe.getTalltext()));
				VERBAL.addContent(child);
				child = new Element(XML_VERBAL_ORDERNO);//质检顺序
				child.setText(DealNull(pointDescribe.getOrder()));
				QCPOINTS.addContent(VERBAL);
				VERBAL.addContent(child);
			}
        } else {
			Element VERBAL = new Element(XML_VERBAL);
			Element child = new Element(XML_VERBAL_INSCODE);//保险公司代码
			VERBAL.addContent(child);
			child = new Element(XML_VERBAL_COMCODE);//组织机构编码
			VERBAL.addContent(child);
			child = new Element(XML_VERBAL_TRICKID);//话术ID
			VERBAL.addContent(child);

			child = new Element(XML_VERBAL_RISKCODE);//产品编码
			VERBAL.addContent(child);
			child = new Element(XML_VERBAL_RISKNAME);//产品名称
			VERBAL.addContent(child);
			child = new Element(XML_VERBAL_RISKTYPE);//产品类型
			VERBAL.addContent(child);
			child = new Element(XML_VERBAL_QCPOINTCODE);//质检要点编码
			VERBAL.addContent(child);


			child = new Element(XML_VERBAL_QCPOINT);//质检要点
			VERBAL.addContent(child);
			child = new Element(XML_VERBAL_QCTRICK);//质检说明
			VERBAL.addContent(child);
			child = new Element(XML_VERBAL_ORDERNO);//质检顺序
			QCPOINTS.addContent(VERBAL);
			VERBAL.addContent(child);
		}
		QCFEEDBACKS.addContent(QCPOINTS);
		body.addContent(QCFEEDBACKS);
		return body;
	}

	/**
	 * 生成报文头元素
     *
     * @param trancode
	 * @return
	 * @throws IOException
	 */
    public static Element generateHeadXml(String trancode) throws IOException {
		code = Util.readProperties("company.no");
		Element head = new Element(XmlNodeConstants.XML_HEAD);
		Element child = new Element(XmlNodeConstants.XML_HEAD_VERSION);
		child.setText(DealNull("1.0"));
		head.addContent(child);
		child = new Element(XmlNodeConstants.XML_HEAD_SYSCODE);
		child.setText(DealNull("002"));
		head.addContent(child);
		child = new Element(XmlNodeConstants.XML_HEAD_TRANUSER);
		child.setText(DealNull("admin"));
		head.addContent(child);
		child = new Element(XmlNodeConstants.XML_HEAD_TRANPASSWD);
		child.setText(DealNull("111111"));
		head.addContent(child);
		child = new Element(XmlNodeConstants.XML_HEAD_COMPANY);
		child.setText(DealNull(code));
		head.addContent(child);
		child = new Element(XmlNodeConstants.XML_HEAD_TRANSCODE);
		child.setText(DealNull(trancode));
		head.addContent(child);
		return head;
	}

	/*
	 * 处理null和“null”字符串
	 */
	public static String DealNull(Object str) {

        return (str == null || "null".equalsIgnoreCase(str.toString())) ? ""
				: str.toString();
	}

    /*
     * 处理null和“null”字符串
     */
    public static String DealDate(Object str) {

        if(str == null || "null".equalsIgnoreCase(str.toString())) {
            return "";
        }
        String str_date = str.toString();
        int end = str_date.lastIndexOf(".");
        if (end < 0) {
            return str_date;
        } else {
            return str_date.substring(0,end);
        }
    }

	/**
	 * 发送报文
     *
	 * @param string
	 * @return
	 * @throws IOException
	 */
    public String socketXml(String buno, String string) throws IOException {
        Class[] paramType = new Class[]{String.class};
        InterFaceService interFaceService = (InterFaceService) SpringUtil.getBean("interFaceService");
		List<InterfaceManage> list = interFaceService.getInterface();
		String wsdlUrl = "";
		String targetNamespace = "";
		String name = "";
		String code = "";
		String className = this.getClass().getName();
		for (InterfaceManage interfaceManage : list) {
            if ("0".equalsIgnoreCase(interfaceManage.getRole()) && className.contains(interfaceManage.getInterfaceClassName())) {
				wsdlUrl = interfaceManage.getInterfaceAddress();
				targetNamespace = interfaceManage.getSpace();
				name = interfaceManage.getMethod();
				code = interfaceManage.getInterfaceCode();
				break;
			}
		}
//		Object[] param= new Object[]{generateResultXml(code,buno,string)};
        String generateResultXml = generateResultXml(code, buno, string);


		String xml2json = XmlToJSON.xml2JSON(generateResultXml);
        logger.info("发送报文: {} \n  {} \n  {} \n  {} \n  {}",
                xml2json, wsdlUrl, targetNamespace, name, code);
		String sendPostDataByJson = HttpPostUtil.sendPostDataByJson(wsdlUrl, xml2json, "utf-8");
//		Object[] ad = Axis2Util.getResult(wsdlUrl, targetNamespace, name, param, paramType);
        logger.info("返回: {} ", sendPostDataByJson);
		return this.ReturnCode(sendPostDataByJson);


	}

	/**
	 * 解析返回报文
     *
	 * @param message
	 * @return
	 */
	private String ReturnCode(String message) {
		byte[] ab;
		String a = "";
		try {
			ab = message.getBytes("UTF-8");
			message = new String(ab, "UTF-8");
			StringReader sr = new StringReader(message);
			InputSource is = new InputSource(sr);
			Document d = null;
			d = (new SAXBuilder()).build(is);
			Element root = d.getRootElement();
			Element listbody = root.getChild(XmlNodeConstants.XML_BODY);
			Element TRANSRESULT = listbody.getChild("TRANSRESULT");
			Element returncode = TRANSRESULT.getChild(XmlNodeConstants.XML_TRANSRESULT_RETURNCODE);
			a = returncode.getText();
		} catch (UnsupportedEncodingException e) {
            logger.error(e.getMessage(), e);// e.printStackTrace();
            throw new RuntimeException(e);
		} catch (JDOMException e) {
            logger.error(e.getMessage(), e);
            throw new RuntimeException(e);
		} catch (IOException e) {
            logger.error(e.getMessage(), e);
            throw new RuntimeException(e);
		}
		return a;

}

	public static void main(String[] args) throws IOException {
        Class[] paramType = new Class[]{String.class};
		InterFaceService interFaceService = (InterFaceService) ContextLoader.getCurrentWebApplicationContext().getBean("interFaceService");
        List<InterfaceManage> list = interFaceService.getInterface();
		String wsdlUrl = "";
		String targetNamespace = "";
		String name = "";
		String code = "";
		String className = Thread.currentThread().getStackTrace()[1].getClassName();
		for (InterfaceManage interfaceManage : list) {
            if ("0".equalsIgnoreCase(interfaceManage.getRole()) && className.contains(interfaceManage.getInterfaceClassName())) {
				wsdlUrl = interfaceManage.getInterfaceAddress();
				targetNamespace = interfaceManage.getSpace();
				name = interfaceManage.getMethod();
				code = interfaceManage.getInterfaceCode();
				break;
			}
		}
        Object[] param = new Object[]{generateResultXml(code, "39883", "1")};
		System.out.println(wsdlUrl);
		System.out.println(targetNamespace);
		System.out.println(name);
		System.out.println(className);
		System.out.println(param[0]);
	}
}
