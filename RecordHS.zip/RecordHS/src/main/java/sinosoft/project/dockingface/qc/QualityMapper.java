package sinosoft.project.dockingface.qc;

import java.util.List;

import sinosoft.framework.core.beans.SqlParam;
import sinosoft.project.qcac.vo.QcPointVo;

public interface QualityMapper {
		
	
	List<Quality> queryQuality(String doccode);
	List<Quality>  queryWenTiList(String doccode, String string);
	List<Quality>  queryWenTiList1(String doccode,String string);
	List<QcPointVo>  queryWenTiPointList(SqlParam add);
	String getriskName(String string);
}
