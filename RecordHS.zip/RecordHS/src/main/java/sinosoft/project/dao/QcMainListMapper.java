package sinosoft.project.dao;

import org.apache.ibatis.annotations.Param;
import sinosoft.project.entity.QcMainList;

import java.util.List;

public interface QcMainListMapper {
    
    QcMainList selectByPrimaryKey(String id);
    
    List<QcMainList> queryByBusno(String businessno);

    int insertQCMainList(QcMainList qcMainList);

    int deleteQcMainListByDoccodeAndBussno(@Param("doccode") String doccode, @Param("businessno") String businessno);
}
