package sinosoft.project.dao;

import java.util.List;

import sinosoft.framework.core.beans.SqlParam;
import sinosoft.project.Integrated.vo.QcBackVo;
import sinosoft.project.entity.QcMain;
import sinosoft.project.qcac.vo.QcMainVo;

public interface QcMainMapper {
    int deleteByPrimaryKey(String id);

	int insert(QcMain record);

	int insertSelective(QcMain record);

	QcMain selectByPrimaryKey(String id);

	int updateByPrimaryKeySelective(QcMain record);

	int updateByPrimaryKey(QcMain record);

	List<QcMainVo> selectByDoccode(SqlParam sqlParam);

	int updateByDoccodeSelective(QcMain qcMain);
	
	int updateByDoccodeSelective2(QcMain qcMain);
	
	int updateByDoccodeSelectiveSecond(QcMain qcMain);
	//用于修改整改时间过长直接设置为不通过
	int updatSelective(QcMain qcMain);

	void cztruble(String doccode);

	String selectMaxId();

	List<QcMainVo> queryQCPointDEsc(String doccode);

	QcMain selectByStatus(String qcid);

	String selectBussno(String doccode);

	List<QcMainVo> selectByBussno(SqlParam add);

	List<QcMainVo> queryQCPointFlsg(String doccode);
	
	List<QcMainVo> queryQCPointFlsgSecond(String doccode);	

	QcMain queryByBusno(String businessno);
	
	
	int insertQCBack(QcBackVo record);

	List<QcMainVo> selectCountQc(String buno);

	String selectinspectdate(String businessno);
	
	String selectRemarks(String businessno);

	int deletebybusinessno(String businessno);
	
}