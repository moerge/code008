package sinosoft.platform.filter;

import java.io.IOException;
import java.util.List;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.subject.Subject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import sinosoft.platform.log.util.LogUtil;
import sinosoft.platform.permission.menu.beans.Function;
import sinosoft.platform.permission.menu.util.FunctionUtil;
import sinosoft.platform.utils.CacheUtil;
import sinosoft.platform.utils.Util;
import sinosoft.platform.utils.WebUtil;

/**
 * 菜单功能日志记录
 * 
 * @author zhenglei
 *
 */
public class MenuLogFilter implements Filter {
	private static final Logger logger = LoggerFactory.getLogger(MenuLogFilter.class);
	public void destroy() {
	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		// 获得在下面代码中要用的request,response,session对象
		HttpServletResponse resp = (HttpServletResponse) response;
		HttpServletRequest req = (HttpServletRequest) request;
		Subject subject = WebUtil.getSubject();
		if (subject.isAuthenticated()) {//是否登录
			saveLog(req);
		}
		chain.doFilter(req, resp);
	}
	
	/**
	 * 增加日志
	 */
	private void saveLog(HttpServletRequest req ){
		// 获得用户请求的URI
					String uri = req.getRequestURI();
					List<Function> funs=FunctionUtil.getFunctionByUserId(WebUtil.getUserId());
					String ip=WebUtil.getIpAddr(req);
					if(funs!=null&&!funs.isEmpty()){
						for (Function function : funs) {
							if(function.getChildren()!=null&&function.getChildren().size()>0){
								for (Function function1 : function.getChildren()) {
									if (StringUtils.isNotEmpty(function1.getMenuUrl())&&uri.substring(uri.lastIndexOf("/"), uri.lastIndexOf(".")).equals(function1.getMenuUrl().substring(function1.getMenuUrl().lastIndexOf("/"), function1.getMenuUrl().lastIndexOf(".")))) {
										try {
											LogUtil.addMenuLog(function1.getMenuNameZh(), function1.getMenuUrl(),ip);
										} catch (Exception e) {
											logger.info("日志记录出错："+e.getMessage());
										}
										break;
									}
								}
							}
						}
					}
	}

	public void init(FilterConfig filterConfig) throws ServletException {
	}

}
