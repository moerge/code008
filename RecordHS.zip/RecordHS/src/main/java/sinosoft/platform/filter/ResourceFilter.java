package sinosoft.platform.filter;

import java.io.IOException;
import java.util.List;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.quartz.SchedulerException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import sinosoft.platform.permission.menu.util.FunctionUtil;
import sinosoft.platform.threadPool.ThreadPoolUtil;
import sinosoft.platform.time.service.ScheduleJobService;
import sinosoft.platform.utils.BeanUtil;
import sinosoft.platform.utils.CacheUtil;

/**
 * 资源权限过滤
 * @author zhenglei
 *
 */
public class ResourceFilter implements Filter {
	private static final Logger logger = LoggerFactory.getLogger(ResourceFilter.class);
	public void destroy() {
		ThreadPoolUtil.shutdown();//关闭线程池
	}

	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		// 获得在下面代码中要用的request,response,session对象
		HttpServletResponse resp = (HttpServletResponse)response;
		HttpServletRequest req = (HttpServletRequest) request;
		//获得用户请求的URI
		String uri = req.getRequestURI();
//		System.out.println("MobileLoginFilter uri="+uri);
		
		String ctx = req.getContextPath();
		String code=uri.substring(ctx.length()+1);
//		System.out.println(code+"------------");
		
		if(code.contains(".js")||code.contains(".css")||code.contains("/sys/auth/login")){
			chain.doFilter(req, resp);
		}else{
			//权限校验。判断是否包含权限。
			Subject subject = SecurityUtils.getSubject();
			if(subject.isAuthenticated()){
				//具体响应ShiroDbRealm。doGetAuthorizationInfo，判断是否包含此url的响应权限
				// boolean isPermitted = subject.isPermitted(code);
				// if(isPermitted) {
				// 	chain.doFilter(req, resp);
				// }else{
					//不包含权限FunctionUti
//				    resp.sendRedirect(ctx+"/sys/auth/login/local.html");
//				    req.getRequestDispatcher("/platform/common/error/403.jsp").forward( request, response);
					//List<String> functions= FunctionUtil.getAllFunctions();
//					List<String> functions = new ArrayList<>();
					
						//不包含权限
						req.getRequestDispatcher("/platform/common/error/403.jsp").forward( request, response);
					
				// }
			}else{
				chain.doFilter(req, resp);
			}
		}
	}

	public void init(FilterConfig filterConfig) throws ServletException {
		ThreadPoolUtil.createThread();//初始化线程池
		CacheUtil.add("_version", System.currentTimeMillis());
		
		//初始化任务
		ScheduleJobService scheduleJobService=(ScheduleJobService)BeanUtil.getBean("scheduleJobService");
		try {
			scheduleJobService.initJob();
		} catch (SchedulerException e) {
			logger.debug("批处理任务启动错误："+e.getMessage());
		}
	}

}
