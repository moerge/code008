package sinosoft.platform.riskType.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import sinosoft.framework.core.beans.DictVo;
import sinosoft.platform.riskType.beans.RiskPointDescribe;
import sinosoft.platform.riskType.beans.RiskType;

public interface RiskTypeMapper {
    int deleteByPrimaryKey(String id);

    int insert(RiskType record);

    int insertSelective(RiskType record);

    RiskType selectByPrimaryKey(String id);
    List<RiskType> selectByPrimaryKeyByList(List keys);

    int updateByPrimaryKeySelective(RiskType record); //新增更新中文内容

    int updateByPrimaryKey(RiskType record);
    
    int updateByPrimaryKeyList(String[] id);

	List<RiskType> selectRiskTypeNameByCode(String risktypecode);

	String selectBusinessType(String risktypecode);

	String selectRiskTypeNo(String productCode);

	String selectRiskTypeIdByCode(String risktypecode);

	List<DictVo> getRiskTypeCodeList(String businessType);

	List<DictVo> getRiskTypeCodeList1(@Param(value = "businessType") String businessType);

	List<DictVo> getPointNameAndPointCodeList(String risktypecode);

	String selectBusinessType2(String risktypecode);

	int getRiskTypeForRelease(@Param("id")String id);

	int getRiskTypeForCancelRelease(@Param("id")String id);


}