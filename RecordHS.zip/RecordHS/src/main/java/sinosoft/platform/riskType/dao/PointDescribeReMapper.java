package sinosoft.platform.riskType.dao;

import java.util.List;

import sinosoft.framework.core.beans.SqlParam;
import sinosoft.platform.riskType.beans.PointDescribeRe;
import sinosoft.platform.riskType.beans.PointDescribeReKey;

public interface PointDescribeReMapper {
    int deleteByPrimaryKey(PointDescribeReKey key);

    int insert(PointDescribeRe record);

    int insertSelective(PointDescribeRe record);

    PointDescribeRe selectByPrimaryKey(PointDescribeReKey key);

    int updateByPrimaryKeySelective(PointDescribeRe record);

    int updateByPrimaryKey(PointDescribeRe record);
    
    List<PointDescribeRe> selectByPointId(SqlParam sqlParam);
    
    
}