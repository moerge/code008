package sinosoft.platform.riskType.beans;

import java.util.Date;

public class RiskPointDescribeVo {
	private String id;	

	private String risktypeId;

    private String risktypeName;

    private String mainpointId;

    private String describeId;

    private String operator;

    private Date createDatetime;

    private Date modifyDatetime;
    
    //要点名称
    private String mainpointName;
    
    //话述名称
    private String describeContent;
    
    private String oragancode;
    
    private String describeOrder;
    
    private String pointOrder;
    
    private String risktype;
    
    private String activationState;
    
    private Date failureTime;
    
    private String model;
    
    private String risktypecode;
    
    private String describeIdVo;
       
    private String productTypeCode;
    
    private String businessTypeCode;
    
    private String businessTypeName;


	private String auditor;//延时审核人

	private String effectivetime;//延时生效时间

	private String modifyDatetime1; //接收前端参数

	public String getModifyDatetime1() {
		return modifyDatetime1;
	}

	public void setModifyDatetime1(String modifyDatetime1) {
		this.modifyDatetime1 = modifyDatetime1;
	}

	public String getAuditor() {
		return auditor;
	}

	public void setAuditor(String auditor) {
		this.auditor = auditor;
	}

	public String getEffectivetime() {
		return effectivetime;
	}

	public void setEffectivetime(String effectivetime) {
		this.effectivetime = effectivetime;
	}

	public String getBusinessTypeName() {
		return businessTypeName;
	}

	public void setBusinessTypeName(String businessTypeName) {
		this.businessTypeName = businessTypeName;
	}

	public String getBusinessTypeCode() {
		return businessTypeCode;
	}

	public void setBusinessTypeCode(String businessTypeCode) {
		this.businessTypeCode = businessTypeCode;
	}

	public String getProductTypeName() {
		return productTypeName;
	}

	public void setProductTypeName(String productTypeName) {
		this.productTypeName = productTypeName;
	}

	private String productTypeName;

	public String getProductTypeCode() {
		return productTypeCode;
	}

	public void setProductTypeCode(String productTypeCode) {
		this.productTypeCode = productTypeCode;
	}

	public String getDescribeIdVo() {
		return describeIdVo;
	}

	public void setDescribeIdVo(String describeIdVo) {
		this.describeIdVo = describeIdVo;
	}
    
    public String getRisktypecode() {
		return risktypecode;
	}

	public void setRisktypecode(String risktypecode) {
		this.risktypecode = risktypecode;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getActivationState() {
		return activationState;
	}

	public void setActivationState(String activationState) {
		this.activationState = activationState;
	}

	public Date getFailureTime() {
		return failureTime;
	}

	public void setFailureTime(Date failureTime) {
		this.failureTime = failureTime;
	}

	public String getRisktype() {
		return risktype;
	}

	public void setRisktype(String risktype) {
		this.risktype = risktype;
	}

	public String getPointOrder() {
		return pointOrder;
	}

	public void setPointOrder(String pointOrder) {
		this.pointOrder = pointOrder;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
    
    public String getDescribeOrder() {
		return describeOrder;
	}

	public void setDescribeOrder(String describeOrder) {
		this.describeOrder = describeOrder;
	}

	public String getOragancode() {
		return oragancode;
	}

	public void setOragancode(String oragancode) {
		this.oragancode = oragancode;
	}

	//增加所有id
    private String keys;
    

	public String getKeys() {
		return keys;
	}

	public void setKeys(String keys) {
		this.keys = keys;
	}

	public String getDescribeContent() {
		return describeContent;
	}

	public void setDescribeContent(String describeContent) {
		this.describeContent = describeContent;
	}

	public String getMainpointName() {
		return mainpointName;
	}

	public void setMainpointName(String mainpointName) {
		this.mainpointName = mainpointName;
	}


	public String getRisktypeId() {
        return risktypeId;
    }

    public void setRisktypeId(String risktypeId) {
        this.risktypeId = risktypeId == null ? null : risktypeId.trim();
    }

    public String getRisktypeName() {
        return risktypeName;
    }

    public void setRisktypeName(String risktypeName) {
        this.risktypeName = risktypeName == null ? null : risktypeName.trim();
    }

    public String getMainpointId() {
        return mainpointId;
    }

    public void setMainpointId(String mainpointId) {
        this.mainpointId = mainpointId == null ? null : mainpointId.trim();
    }

    public String getDescribeId() {
        return describeId;
    }

    public void setDescribeId(String describeId) {
        this.describeId = describeId == null ? null : describeId.trim();
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator == null ? null : operator.trim();
    }

    public Date getCreateDatetime() {
        return createDatetime;
    }

    public void setCreateDatetime(Date createDatetime) {
        this.createDatetime = createDatetime;
    }

    public Date getModifyDatetime() {
        return modifyDatetime;
    }

    public void setModifyDatetime(Date modifyDatetime) {
        this.modifyDatetime = modifyDatetime;
    }
}