package sinosoft.platform.riskType.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import sinosoft.framework.core.beans.SqlParam;
import sinosoft.platform.riskType.beans.Describe;
import sinosoft.platform.riskType.beans.Point;
import sinosoft.platform.riskType.beans.RiskPointDescribeVo;
import sinosoft.platform.utils.MapContext;
import sinosoft.project.entity.Example;

public interface DescribeMapper {
    int deleteByPrimaryKey(String describeId);

    int insert(Describe record);

    int insertSelective(Describe record);

    Describe selectByPrimaryKey(String describeId);
    
    Describe selectByIdAndNoDelete(String describeId);

    int updateByPrimaryKeySelective(Describe record);

    int updateByPrimaryKey(Describe record);
    
    List<Describe> selectdescribeList(SqlParam sqlParam);
    
    List<Describe> selectdescribeListnodel(SqlParam sqlParam);
    
    List<Describe> getTree();

	Describe selectDesename(String describeId);
	
	List<Describe> getDescribe(String describeId);
	
	List<Describe> selectdescribe(String  mainpointId);
	
	int deleteRiskTypeByDescribe(String describeId);
	
	List<RiskPointDescribeVo> riskTypeQuery(String  mainpointId);
	
	List<RiskPointDescribeVo> riskTypeQueryByDescribe(String  describeId);
	
	int deleteByPoint(String mainpointId);

	List<Point> SelectExcelPoi(MapContext map);

	List<Describe> selectdescribeListByMainpointId(@Param("oldmainpointId")String oldmainpointId);

	int updateDescribeByPrimaryKey(Describe record);
	

		
}