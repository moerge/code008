package sinosoft.platform.riskType.beans;

import java.util.Date;

public class RiskType {
    private String id;

    private String risktypecode;

    private String risktypename;

    private String mainpointid;

    private String describeid;

    private String organid;

    private String operator;//操作人

    private Date createdatetime;

    private Date modifydatetime;

    private String pointorder;
    
    private String activationState;
    
    private Date failureTime;
    
    private String model;
    
    private String businessTypeNo;
    
    private String modifier;//创建操作人
    
    private String releaseOperator;//发布操作人
    
    //起售时间
    private Date saleTime;
    //停售时间
    private Date stopTime;
    
    //中文内容
    private String describeContent;

    private String updater;//上一次操作人 页面展示

    private String auditor;//延时审核人

    private String effectivetime;//延时生效时间 页面展示

    private Date updateTime;//修改时间 页面展示

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getUpdater() {
        return updater;
    }

    public void setUpdater(String updater) {
        this.updater = updater;
    }

    public String getAuditor() {
        return auditor;
    }

    public void setAuditor(String auditor) {
        this.auditor = auditor;
    }

    public String getEffectivetime() {
        return effectivetime;
    }

    public void setEffectivetime(String effectivetime) {
        this.effectivetime = effectivetime;
    }

    public String getDescribeContent() {
        return describeContent;
    }

    public void setDescribeContent(String describeContent) {
        this.describeContent = describeContent;
    }

    public Date getSaleTime() {
		return saleTime;
	}

	public void setSaleTime(Date saleTime) {
		this.saleTime = saleTime;
	}

	public Date getStopTime() {
		return stopTime;
	}

	public void setStopTime(Date stopTime) {
		this.stopTime = stopTime;
	}

	public String getModifier() {
		return modifier;
	}

	public void setModifier(String modifier) {
		this.modifier = modifier;
	}

	public String getReleaseOperator() {
		return releaseOperator;
	}

	public void setReleaseOperator(String releaseOperator) {
		this.releaseOperator = releaseOperator;
	}

	public String getBusinessTypeNo() {
		return businessTypeNo;
	}

	public void setBusinessTypeNo(String businessTypeNo) {
		this.businessTypeNo = businessTypeNo;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getActivationState() {
		return activationState;
	}

	public void setActivationState(String activationState) {
		this.activationState = activationState;
	}

	public Date getFailureTime() {
		return failureTime;
	}

	public void setFailureTime(Date failureTime) {
		this.failureTime = failureTime;
	}

	public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getRisktypecode() {
        return risktypecode;
    }

    public void setRisktypecode(String risktypecode) {
        this.risktypecode = risktypecode == null ? null : risktypecode.trim();
    }

    public String getRisktypename() {
        return risktypename;
    }

    public void setRisktypename(String risktypename) {
        this.risktypename = risktypename == null ? null : risktypename.trim();
    }

    public String getMainpointid() {
        return mainpointid;
    }

    public void setMainpointid(String mainpointid) {
        this.mainpointid = mainpointid == null ? null : mainpointid.trim();
    }

    public String getDescribeid() {
        return describeid;
    }

    public void setDescribeid(String describeid) {
        this.describeid = describeid == null ? null : describeid.trim();
    }

    public String getOrganid() {
        return organid;
    }

    public void setOrganid(String organid) {
        this.organid = organid == null ? null : organid.trim();
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator == null ? null : operator.trim();
    }

    public Date getCreatedatetime() {
        return createdatetime;
    }

    public void setCreatedatetime(Date createdatetime) {
        this.createdatetime = createdatetime;
    }

    public Date getModifydatetime() {
        return modifydatetime;
    }

    public void setModifydatetime(Date modifydatetime) {
        this.modifydatetime = modifydatetime;
    }

    public String getPointorder() {
        return pointorder;
    }

    public void setPointorder(String pointorder) {
        this.pointorder = pointorder == null ? null : pointorder.trim();
    }
}