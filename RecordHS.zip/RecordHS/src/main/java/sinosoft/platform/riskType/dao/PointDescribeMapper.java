package sinosoft.platform.riskType.dao;

import java.util.List;

import sinosoft.framework.core.beans.SqlParam;
import sinosoft.platform.riskType.beans.PointDescribe;
import sinosoft.platform.riskType.beans.RiskPointDescribeVo;

public interface PointDescribeMapper {
    int deleteByPrimaryKey(String describeId);

    int insert(PointDescribe record);

    int insertSelective(PointDescribe record);

    List<PointDescribe> selectByPrimaryKey(SqlParam sqlParam);

    int updateByPrimaryKeySelective(PointDescribe record);

    int updateByPrimaryKey(PointDescribe record);
    
    List<PointDescribe> selectByDescribeId(String describeId);
    
    List<PointDescribe> selectdescribeList(SqlParam sqlParam);
    
    PointDescribe queryId(String describeId);
    
    PointDescribe selectId(String mainpointName);

    List<PointDescribe> selectdescribe(String  mainpointId);
    
    List<PointDescribe> queryDescribe(SqlParam sqlParam);

	String selectOrganname(String oragancode);
}