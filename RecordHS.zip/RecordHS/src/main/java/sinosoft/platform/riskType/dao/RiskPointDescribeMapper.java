package sinosoft.platform.riskType.dao;

import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Param;
import sinosoft.framework.core.beans.SqlParam;
import sinosoft.platform.riskType.beans.RiskPointDescribe;
import sinosoft.platform.utils.MapContext;

public interface RiskPointDescribeMapper {
    int deleteByPrimaryKey(String risktypeId);

    int insert(RiskPointDescribe record);

    int insertSelective(RiskPointDescribe record);

    RiskPointDescribe selectByPrimaryKey(String risktypeId);

    int updateByPrimaryKeySelective(RiskPointDescribe record);

    int updateByPrimaryKey(RiskPointDescribe record);
    
   /* List<RiskPointDescribeVo> selectRiskType(SqlParam sqlParam);*/
    
    List<RiskPointDescribe> selectRiskType(SqlParam sqlParam);
    
    List<String> selectproducttypecodelist(SqlParam sqlParam);
    
    RiskPointDescribe getRiskType(String risktypeId);
       
    List<RiskPointDescribe> queryRiskType(SqlParam sqlParam);
    
	String  queryDic(String riskTypeName);
	
	RiskPointDescribe queryRiskTypeTime();
	
	RiskPointDescribe queryRiskTime();
	
	List<RiskPointDescribe> selectByRiskCode(String  insuranceCode);
	
	List<RiskPointDescribe> selectByProductCode(String  insuranceCode);

	List<RiskPointDescribe> selectByFilter(MapContext map);

	List<RiskPointDescribe> selectRiskPointDescribes(String risktypecode, String pointOrder);

	int selectByMainpointId(String mainpointId);
	
	List<RiskPointDescribe> selectRiskPointByRiskType(String risktypecode);
	
	List<RiskPointDescribe> selectRiskPointByProduct(String risktypename);
	
	List<RiskPointDescribe> selectRiskPointByProductCodeNodel(String risktypename);

	int selectByRiskPointDescribe(RiskPointDescribe riskPointDescribe);

	int selectByMaincodeAndDescribeid(String mainpointId, String describeId, String string);
	
	int selectByOrderAndProductTypeCode(String pointOrder, String risktypecode);

	int selectByProductCodeAndPointOrder(String risktypecode, String pointOrder);

	List<RiskPointDescribe> selectRiskPointDescribesfornorelease(String risktypecode, String pointOrder);
	//延时发布
	List<RiskPointDescribe> selectRiskPointDescribesfornoreleaseDelayed(String risktypecode, String pointOrder);

	 int deleteByProducttypecode(String productTypeCode);

	int queryriskpoint(String string);

	int updateRiskPointDescribe(String productCode, String productCode2);

	int selectRiskPointDescribeByProductCode(String productCode);

	int updateRiskPointDescribeToDel(String productCode, String userNo);

	String SelectValidUser(String userNo, String id);

	List<RiskPointDescribe> searchDescribeInfoByKeys(List lists);

	RiskPointDescribe selectNewRiskPointInfoByid(String riskPointId);

	/**
	 *
	 * @param saleTime 延时时间
	 * @param userNo	用户id
	 * @param active_state 延时状态
	 * @param updater  上次操作人
	 * @param businessType 业务类型
	 * @param productTypeCode 产品类型
	 * @param pointOrder 顺序号
	 * @return
	 */
    int UpdateDelayedTimeAndDelayedUserNo(@Param("saleTime") String saleTime, @Param("userNo") String userNo, @Param("active_state") String active_state, @Param("updateTime") Date updateTime,
										  @Param("updater") String updater,
										  @Param("businessType") String businessType, @Param("productTypeCode") String productTypeCode, @Param("pointOrder") String pointOrder);
}