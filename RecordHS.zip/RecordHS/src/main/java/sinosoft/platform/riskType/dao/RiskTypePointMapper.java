package sinosoft.platform.riskType.dao;

import java.util.List;

import sinosoft.platform.riskType.beans.RiskTypePoint;
import sinosoft.platform.utils.MapContext;

public interface RiskTypePointMapper {
    int deleteByPrimaryKey(String mainpointId);

    int insert(RiskTypePoint record);

    int insertSelective(RiskTypePoint record);

    RiskTypePoint selectByPrimaryKey(String mainpointId);

    int updateByPrimaryKeySelective(RiskTypePoint record);

    int updateByPrimaryKey(RiskTypePoint record);
    
    List<RiskTypePoint> selectByFilter(MapContext map);
    
    List<RiskTypePoint> selectById(String mainpointId);
    
    RiskTypePoint queryId(String mainpointId);
    
    RiskTypePoint select();
}