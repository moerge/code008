package sinosoft.platform.riskType.beans;

import java.util.Date;

public class RiskPointDescribe {
	public static final String SEQ_RISKTYPEID = "SEQ_RISKTYPEID";
	
	private String id;
	
    private String risktypeId;

    private String risktypeName;

    private String mainpointId;

    private String describeId;

    private String operator;//操作人

    private Date createDatetime;

    private Date modifyDatetime;
    
    private String oragancode;   
    
    private String pointOrder;
    
    private String risktype;
    
    private String activationState;
    
    private Date failureTime;
    
    private String describeContent;//  中文内容
    
    private String risktypenames;
    
    private String risktypecode;
    
    private String model;
    
    private String describeIdVo;
       
    private String businessType;
    
    private String isAdd;//是否是新增
    
 private String modifier;//创建操作人
    
    private String releaseOperator;//发布操作人
    
    private String productTypeName;
  //产品类型编码
    private String productTypeCode;
    
    private String businessTypeCode;
    
    private String businessTypeName;

    private String auditor;//延时审核人

    private String effectivetime;//延时生效时间

	private String  updater;//上一次操作者

	private Date updateTime;//修改时间

	private String modifyDatetime1;//前端参数

	public String getModifyDatetime1() {
		return modifyDatetime1;
	}

	public void setModifyDatetime1(String modifyDatetime1) {
		this.modifyDatetime1 = modifyDatetime1;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public String getUpdater() {
		return updater;
	}

	public void setUpdater(String updater) {
		this.updater = updater;
	}

	public String getAuditor() {
		return auditor;
	}

	public void setAuditor(String auditor) {
		this.auditor = auditor;
	}

	public String getEffectivetime() {
		return effectivetime;
	}

	public void setEffectivetime(String effectivetime) {
		this.effectivetime = effectivetime;
	}

	public String getBusinessTypeCode() {
		return businessTypeCode;
	}

	public void setBusinessTypeCode(String businessTypeCode) {
		this.businessTypeCode = businessTypeCode;
	}

	public String getBusinessTypeName() {
		return businessTypeName;
	}

	public void setBusinessTypeName(String businessTypeName) {
		this.businessTypeName = businessTypeName;
	}

	public String getProductTypeCode() {
		return productTypeCode;
	}

	public void setProductTypeCode(String productTypeCode) {
		this.productTypeCode = productTypeCode;
	}

	public String getProductTypeName() {
		return productTypeName;
	}

	public void setProductTypeName(String productTypeName) {
		this.productTypeName = productTypeName;
	}

	public String getModifier() {
		return modifier;
	}

	public void setModifier(String modifier) {
		this.modifier = modifier;
	}

	public String getReleaseOperator() {
		return releaseOperator;
	}

	public void setReleaseOperator(String releaseOperator) {
		this.releaseOperator = releaseOperator;
	}

    
    
public String getIsAdd() {
		return isAdd;
	}

	public void setIsAdd(String isAdd) {
		this.isAdd = isAdd;
	}

private String mainpointName;


	public String getMainpointName() {
	return mainpointName;
}

public void setMainpointName(String mainpointName) {
	this.mainpointName = mainpointName;
}

	public String getBusinessType() {
		return businessType;
	}

	public void setBusinessType(String businessType) {
		this.businessType = businessType;
	}

	public String getDescribeIdVo() {
		return describeIdVo;
	}

	public void setDescribeIdVo(String describeIdVo) {
		this.describeIdVo = describeIdVo;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getRisktypecode() {
		return risktypecode;
	}

	public void setRisktypecode(String risktypecode) {
		this.risktypecode = risktypecode;
	}

	public String getRisktypenames() {
		return risktypenames;
	}

	public void setRisktypenames(String risktypenames) {
		this.risktypenames = risktypenames;
	}

	public String getDescribeContent() {
		return describeContent;
	}

	public void setDescribeContent(String describeContent) {
		this.describeContent = describeContent;
	}

	public String getActivationState() {
		return activationState;
	}

	public void setActivationState(String activationState) {
		this.activationState = activationState;
	}

	public Date getFailureTime() {
		return failureTime;
	}

	public void setFailureTime(Date failureTime) {
		this.failureTime = failureTime;
	}

	public String getRisktype() {
		return risktype;
	}

	public void setRisktype(String risktype) {
		this.risktype = risktype;
	}

	public String getPointOrder() {
		return pointOrder;
	}

	public void setPointOrder(String pointOrder) {
		this.pointOrder = pointOrder;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}


	public String getOragancode() {
		return oragancode;
	}

	public void setOragancode(String oragancode) {
		this.oragancode = oragancode;
	}

	public String getRisktypeId() {
        return risktypeId;
    }

    public void setRisktypeId(String risktypeId) {
        this.risktypeId = risktypeId == null ? null : risktypeId.trim();
    }

    public String getRisktypeName() {
        return risktypeName;
    }

    public void setRisktypeName(String risktypeName) {
        this.risktypeName = risktypeName == null ? null : risktypeName.trim();
    }

    public String getMainpointId() {
        return mainpointId;
    }

    public void setMainpointId(String mainpointId) {
        this.mainpointId = mainpointId == null ? null : mainpointId.trim();
    }

    public String getDescribeId() {
        return describeId;
    }

    public void setDescribeId(String describeId) {
        this.describeId = describeId == null ? null : describeId.trim();
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator == null ? null : operator.trim();
    }

    public Date getCreateDatetime() {
        return createDatetime;
    }

    public void setCreateDatetime(Date createDatetime) {
        this.createDatetime = createDatetime;
    }

    public Date getModifyDatetime() {
        return modifyDatetime;
    }

    public void setModifyDatetime(Date modifyDatetime) {
        this.modifyDatetime = modifyDatetime;
    }

    
}