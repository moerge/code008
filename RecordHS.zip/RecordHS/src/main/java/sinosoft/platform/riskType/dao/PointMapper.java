package sinosoft.platform.riskType.dao;

import java.util.List;

import sinosoft.framework.core.beans.SqlParam;
import sinosoft.platform.riskType.beans.Point;
import sinosoft.platform.utils.MapContext;

public interface PointMapper {
    int deleteByPrimaryKey(String mainpointId);

    int insert(Point record);

    int insertSelective(Point record);

    Point selectByPrimaryKey(String mainpointId);

    int updateByPrimaryKeySelective(Point record);
    
    int updateByPrimaryKeySelective2(Point record);

    int updateByPrimaryKey(Point record);
    
    List<Point> selectPoint(SqlParam sqlParam);

    Point selectOrganname(String oragancode);
    
	List<Point> selectDescribeByOrgan(String oragancode);
	
	Point queryId(String mainpointId);
	
	int deleteRiskTypeByPoint(String mainpointId);
	
	Point query(String mainpointId);
	
	 List<Point> selectPoint1();
	
	List<Point> selectByFilter(MapContext map);//查看员工信息

	Point queryIdAndNoDelete(String mainpointId);

	
	
}