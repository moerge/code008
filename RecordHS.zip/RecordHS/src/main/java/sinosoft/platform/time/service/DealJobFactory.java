package sinosoft.platform.time.service;

import java.lang.reflect.Method;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Enumeration;

import org.apache.commons.lang3.StringUtils;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import sinosoft.platform.time.beans.ScheduleJob;
import sinosoft.project.dockingface.util.WebSocketFace;
import sinosoft.platform.utils.Util;


//这里我们实现的是无状态的Job，如果要实现有状态的Job在以前是实现StatefulJob接口，在我使用的quartz 2.2.1中，StatefulJob接口已经不推荐使用了，换成了注解的方式，只需要给你实现的Job类加上注解@DisallowConcurrentExecution即可实现有状态： 
@DisallowConcurrentExecution
public class DealJobFactory implements Job {
	private static final Logger logger = LoggerFactory.getLogger(QuartzJobFactory.class);
    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
    	ScheduleJob scheduleJob = (ScheduleJob)context.getMergedJobDataMap().get("scheduleJob");
        String url=scheduleJob.getUrl();
        String ids =scheduleJob.getInfor();//1025调整
        String ip;
        ip = Util.readProperties("serverpoint");
		logger.info("任务运行");
		logger.info("任务名称 = [" + scheduleJob.getJobName() + "]");
		logger.info("任务id = [" + scheduleJob.getId() + "]");
		logger.info("任务group = [" + scheduleJob.getJobGroup() + "]");
		if(ip.equalsIgnoreCase(scheduleJob.getInfor())){
			if(StringUtils.isNotEmpty(url)){
				System.out.println("任务成功运行");
		        System.out.println("任务名称 = [" + scheduleJob.getJobName() + "]");
		    	try {
		    		Class<?> cls = Class.forName(scheduleJob.getJobName());
		    		WebSocketFace te = (WebSocketFace)cls.newInstance();
					Class clazz = te.getClass();
				    Method m1 = clazz.getDeclaredMethod(url);
				    te.setIds(scheduleJob.getInfor());
//				    te.setIds("wewe");
				    m1.invoke(te);
				} catch (Exception e) {
					logger.debug(scheduleJob.getJobName()+"运行出错地址："+url+"错误信息"+e.getMessage());
				}
		    }
		}else{
			if(scheduleJob.getInfor()!=null&&!"".equals(scheduleJob.getInfor())&&scheduleJob.getInfor().contains(",")){
				if(StringUtils.isNotEmpty(url)){
					if ("updateProductManagetorelease".equals(url) || "updateRiskPointDescribetorelease".equals(url) || "updateProductManagetoCancelRelease".equals(url) || "updateRiskPointDescribetocancelrelease".equals(url)){
						try {
							Class<?> cls = Class.forName(scheduleJob.getJobName());
							WebSocketFace te = (WebSocketFace)cls.newInstance();
							Class clazz = te.getClass();
							Method m1 = clazz.getDeclaredMethod(url,String.class);
//					    te.setIds("wewe");
							m1.invoke(te,scheduleJob.getInfor());
						} catch (Exception e) {
							logger.debug(scheduleJob.getJobName()+"运行出错地址："+url+"错误信息"+e.getMessage());
						}
					}else {
						try {
							Class<?> cls = Class.forName(scheduleJob.getJobName());
							WebSocketFace te = (WebSocketFace)cls.newInstance();
							Class clazz = te.getClass();
							Method m1 = clazz.getDeclaredMethod(url);
							te.setIds(scheduleJob.getInfor());
//					    te.setIds("wewe");
							m1.invoke(te);
						} catch (Exception e) {
							logger.debug(scheduleJob.getJobName()+"运行出错地址："+url+"错误信息"+e.getMessage());
						}
					}
			    }
			}
		}
        
    }
    private String getIP(){
    	Enumeration allNetInterfaces;
    	String host = "";
		try {
			allNetInterfaces = NetworkInterface.getNetworkInterfaces();
			InetAddress ip = null;
	    	while (allNetInterfaces.hasMoreElements()){
	    	NetworkInterface netInterface = (NetworkInterface) allNetInterfaces.nextElement();
	    	//System.out.println(netInterface.getName());
	    	Enumeration addresses = netInterface.getInetAddresses();
		    	while (addresses.hasMoreElements()){
		    		ip = (InetAddress) addresses.nextElement();
		    		if (ip != null && ip instanceof Inet4Address){
		    			host = ip.getHostAddress();
//		    			System.out.println("本机的IP = " + ip.getHostAddress());
		    		}
		    	}
	    	}
	    	return host;
		} catch (SocketException e) {
			logger.debug("IP.....Error");
			e.printStackTrace();
		}
		return host;
    }
    public static void main(String[] args) {
    	System.out.println(getMyIp());
	}
    public static String getMyIp() {
        String localip = null;// 本地IP，如果没有配置外网IP则返回它
        String netip = null;// 外网IP
        try {
            Enumeration netInterfaces = NetworkInterface.getNetworkInterfaces();
            InetAddress ip = null;
            boolean finded = false;// 是否找到外网IP
            while (netInterfaces.hasMoreElements() && !finded) {
                NetworkInterface ni = (NetworkInterface) netInterfaces.nextElement();
                Enumeration address = ni.getInetAddresses();
                while (address.hasMoreElements()) {
                    ip = (InetAddress) address.nextElement();
                    if (!ip.isSiteLocalAddress() && !ip.isLoopbackAddress() && ip.getHostAddress().indexOf(":") == -1) {// 外网IP
                        netip = ip.getHostAddress();
                        finded = true;
                        break;
                    } else if (ip.isSiteLocalAddress() && !ip.isLoopbackAddress() && ip.getHostAddress().indexOf(":") == -1) {// 内网IP
                        localip = ip.getHostAddress();
                    }
                }
            }
        } catch (SocketException e) {
            e.printStackTrace();
        }

        if (netip != null && !"".equalsIgnoreCase(netip)) {
            return netip;
        } else {
            return localip;
        }
    }
}