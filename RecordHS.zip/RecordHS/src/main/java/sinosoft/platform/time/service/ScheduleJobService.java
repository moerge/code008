package sinosoft.platform.time.service;

import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.quartz.CronScheduleBuilder;
import org.quartz.CronTrigger;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.TriggerBuilder;
import org.quartz.TriggerKey;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import sinosoft.framework.core.base.BaseServiceImpl;
import sinosoft.framework.core.beans.PageParam;
import sinosoft.framework.core.beans.PageVo;
import sinosoft.platform.time.beans.ScheduleJob;
import sinosoft.platform.time.dao.ScheduleJobMapper;
import sinosoft.platform.utils.BeanUtil;
import sinosoft.platform.utils.MapContext;
import sinosoft.platform.utils.PageUtil;

/**
 * 定时任务
 * 
 * @author zhenglei
 *
 */
@Service("scheduleJobService")
@Scope("prototype")
public class ScheduleJobService extends BaseServiceImpl {
	
	@Resource(name = "schedulerFactoryBean")
	private Scheduler scheduler;  //注入任务容器
	
	@Resource
	private ScheduleJobMapper scheduleJobMapper; // 注入dao

	// *************************************任务通用API开始*********************************************
	/**
	 * 增加修改任务
	 * 
	 * @param jobList
	 *            //这里获取任务信息数据
	 * @throws SchedulerException
	 */
	public void addJob(ScheduleJob job) throws SchedulerException {
		// schedulerFactoryBean 由spring创建注入
		// Scheduler scheduler =
		// (Scheduler)BeanUtil.getBean("schedulerFactoryBean");
		// 这里获取任务信息数据
		TriggerKey triggerKey = TriggerKey.triggerKey(job.getJobName(), job.getJobGroup());
		// 获取trigger，即在spring配置文件中定义的 bean id="myTrigger"
		CronTrigger trigger = (CronTrigger) scheduler.getTrigger(triggerKey);
		// 不存在，创建一个
		if (null == trigger) {
			//测试注掉
//			JobDetail jobDetail = JobBuilder.newJob(QuartzJobFactory.class)
//					.withIdentity(job.getJobName(), job.getJobGroup()).build();
			JobDetail jobDetail = JobBuilder.newJob(DealJobFactory.class)
					.withIdentity(job.getJobName(), job.getJobGroup()).build();
			jobDetail.getJobDataMap().put("scheduleJob", job);
			// 表达式调度构建器
			CronScheduleBuilder scheduleBuilder = CronScheduleBuilder.cronSchedule(job.getCronExpression());
			// 按新的cronExpression表达式构建一个新的trigger
			trigger = TriggerBuilder.newTrigger().withIdentity(job.getJobName(), job.getJobGroup())
					.withSchedule(scheduleBuilder).build();
			scheduler.scheduleJob(jobDetail, trigger);
		} else {
			// Trigger已存在，那么更新相应的定时设置
			// 表达式调度构建器
			CronScheduleBuilder scheduleBuilder = CronScheduleBuilder.cronSchedule(job.getCronExpression());
			// 按新的cronExpression表达式重新构建trigger
			trigger = trigger.getTriggerBuilder().withIdentity(triggerKey).withSchedule(scheduleBuilder).build();
			// 按新的trigger重新设置job执行
			scheduler.rescheduleJob(triggerKey, trigger);
		}
	}

	/**
	 * 删除任务
	 * 
	 * @param jobList
	 *            //这里获取任务信息数据
	 * @throws SchedulerException
	 */
	public void deleteJob(ScheduleJob job) throws SchedulerException {
		// schedulerFactoryBean 由spring创建注入
		// Scheduler scheduler =
		// (Scheduler)BeanUtil.getBean("schedulerFactoryBean");
		// 这里获取任务信息数据
		TriggerKey triggerKey = TriggerKey.triggerKey(job.getJobName(), job.getJobGroup());
		// 获取trigger，即在spring配置文件中定义的 bean id="myTrigger"
		CronTrigger trigger = (CronTrigger) scheduler.getTrigger(triggerKey);
		// 删除任务
		if(trigger!=null){
			scheduler.deleteJob(trigger.getJobKey());
		}
	}

	// **********************************************************************************
	
	/**
	 * 初始化任务
	 * 
	 * @throws SchedulerException
	 */
	public void initJob() throws SchedulerException {
		ScheduleJob scheduleJob = new ScheduleJob();
		scheduleJob.setJobStatus("1");// 已启动的任务
		List<ScheduleJob> list = getScheduleJob(scheduleJob);
		if (list != null && !list.isEmpty()) {
			for (ScheduleJob scheduleJob2 : list) {
				addJob(scheduleJob2);
			}
		}
	}
	
	/**
	 * 保存实体
	 * 
	 * @param scheduleJob
	 * @return
	 * @throws Exception
	 */
	public boolean saveScheduleJob(ScheduleJob scheduleJob) throws Exception {
		if (StringUtils.isNotEmpty(scheduleJob.getId())) {// 修改
			scheduleJob.setJobStatus("0");
			// 更新任务
			return updateScheduleJob(scheduleJob);
		} else {
			// 启动任务
			scheduleJob.setId(this.getMaxNo(ScheduleJob.SEQ_ID));
			scheduleJob.setCreateDate(new Date());
			scheduleJob.setJobStatus("1");
			scheduleJob.setJobGroup(scheduleJob.getJobGroup() + scheduleJob.getId());
			addJob(scheduleJob);
			return scheduleJobMapper.insertSelective(scheduleJob) > 0;
		}
	}

	/**
	 * 修改实体
	 * 
	 * @param scheduleJob
	 * @return
	 */
	public boolean updateScheduleJob(ScheduleJob scheduleJob) {
		return scheduleJobMapper.updateByPrimaryKeySelective(scheduleJob) > 0;
	}

	/**
	 * 删除实体
	 * 
	 * @param scheduleJob
	 * @return
	 */
	public boolean deleteScheduleJob(String id) {
		return scheduleJobMapper.deleteByPrimaryKey(id) > 0;
	}

	/**
	 * 删除实体
	 * 
	 * @param scheduleJob
	 * @return
	 * @throws SchedulerException
	 */
	public boolean deleteScheduleJobs(String ids) throws SchedulerException {
		if (StringUtils.isNotEmpty(ids)) {
			String[] strs = ids.split(",");
			for (String id : strs) {
				deleteJob(getScheduleJob(id));
				deleteScheduleJob(id);
			}
			return true;
		}
		return false;
	}
	
	/**
	 * 删除实体
	 * 
	 * @param scheduleJob
	 * @return
	 * @throws SchedulerException
	 */
	public boolean updateScheduleJobs(String ids,String status) throws SchedulerException {
		if (StringUtils.isNotEmpty(ids)) {
			String[] strs = ids.split(",");
			for (String id : strs) {
				ScheduleJob scheduleJob=getScheduleJob(id);
				if(status.equalsIgnoreCase("1")){
					addJob(scheduleJob);
				}else{
					deleteJob(scheduleJob);
				}
				scheduleJob.setJobStatus(status);
				updateScheduleJob(scheduleJob);
			}
			return true;
		}
		return false;
	}

	/**
	 * 得到实体
	 * 
	 * @param id
	 * @return
	 */
	public ScheduleJob getScheduleJob(String id) {
		return scheduleJobMapper.selectByPrimaryKey(id);
	}

	/**
	 * 得到实体分页
	 * 
	 * @param example
	 * @return
	 */
	public PageVo<ScheduleJob> getScheduleJobPage(ScheduleJob scheduleJob, PageParam pageParam) {
		MapContext map = MapContext.newOne();
		map.put("scheduleJob", scheduleJob);
		map.put(PageUtil.PAGEPARAM, pageParam);
		List<ScheduleJob> list = scheduleJobMapper.selectByFilter(map);
		if(list!=null&&!list.isEmpty()){
			for (ScheduleJob scheduleJob2 : list) {
				scheduleJob2.setJobStatus(scheduleJob2.getJobStatus().equalsIgnoreCase("1")?"启用":"禁用");
			}
		}
		return PageUtil.getPage(list, pageParam);
	}

	/**
	 * 得到实体
	 * 
	 * @param scheduleJob
	 * @return
	 */
	public List<ScheduleJob> getScheduleJob(ScheduleJob scheduleJob) {
		MapContext map = MapContext.newOne();
		map.put("scheduleJob", scheduleJob);
		return scheduleJobMapper.selectByFilter(map);
	}

}
