package sinosoft.platform.time.service;

import java.lang.reflect.Method;

import org.apache.commons.lang3.StringUtils;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import sinosoft.platform.time.beans.ScheduleJob;

//这里我们实现的是无状态的Job，如果要实现有状态的Job在以前是实现StatefulJob接口，在我使用的quartz 2.2.1中，StatefulJob接口已经不推荐使用了，换成了注解的方式，只需要给你实现的Job类加上注解@DisallowConcurrentExecution即可实现有状态： 
//@DisallowConcurrentExecution
public class QuartzJobFactory implements Job {
	private static final Logger logger = LoggerFactory.getLogger(QuartzJobFactory.class);
    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        System.out.println("任务成功运行");
        ScheduleJob scheduleJob = (ScheduleJob)context.getMergedJobDataMap().get("scheduleJob");
        System.out.println("任务名称 = [" + scheduleJob.getJobName() + "]");
        String url=scheduleJob.getUrl();
        if(StringUtils.isNotEmpty(url)){
        	try {
//        		if(url.contains("http://")){
//        			HttpClientUtil.get(url);
//        		}
        		Class<?> cls = Class.forName(scheduleJob.getJobName());
//    			WebSocketFace te = (WebSocketFace)cls.newInstance();
//    			Class clazz = te.getClass();
//    		    Method m1 = clazz.getDeclaredMethod(url);
//    		    m1.invoke(te);
			} catch (Exception e) {
				logger.debug(scheduleJob.getJobName()+"运行出错地址："+url+"错误信息"+e.getMessage());
			}
        }
    }
   
}