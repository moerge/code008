$(function($) {
	$('#t_grid').datagrid('resize',{height:$(window).height()-$("[class='forms margin_top']").height()-115});
	$('#point_grid').datagrid({
			
			onClickRow: function(rowIndex,rowData){
				var mainpointId = rowData["mainpointIdVo"];

				queryData('/describe/queryDescribe.html?mainpointId='+mainpointId, 'q_frm', 'describe_grid', 'getParams');
				
				}

	});
	var obj = {'total':10,'rows':[{
			describetype:'粤语',
			voicename:'粤语voice',
			voicesize:'1024kb',
			operator:'admin',
			createstatue:'待发布',
			modifyDatetime:'2017-09-07 18:35'
		},{
			describetype:'四川话',
			voicename:'四川话voice',
			voicesize:'2048kb',
			operator:'admin',
			createstatue:'待发布',
			modifyDatetime:'2017-09-08 19:45'
			},{
				describetype:'东北话',
				voicename:'东北话voice',
				voicesize:'6735kb',
				operator:'admin',
				createstatue:'待发布',
				modifyDatetime:'2017-09-08 12:32'
			},{
				describetype:'河南话',
				voicename:'河南话voice',
				voicesize:'9823kb',
				operator:'admin',
				createstatue:'待发布',
				modifyDatetime:'2017-09-09 16:15'
			},{
				describetype:'河北话',
				voicename:'河北话voice',
				voicesize:'1628kb',
				operator:'admin',
				createstatue:'待发布',
				modifyDatetime:'2017-09-10 11:45'
			},{
				describetype:'闽南语',
				voicename:'闽南语voice',
				voicesize:'1024kb',
				operator:'admin',
				createstatue:'待发布',
				modifyDatetime:'2017-09-11 10:30'
			},{
				describetype:'客家语',
				voicename:'客家语voice',
				voicesize:'5437kb',
				operator:'admin',
				createstatue:'待发布',
				modifyDatetime:'2017-09-12 16:15'
			},{
				describetype:'甘肃话',
				voicename:'甘肃话voice',
				voicesize:'7654kb',
				operator:'admin',
				createstatue:'待发布',
				modifyDatetime:'2017-09-17 14:35'
			},{
				describetype:'陕西话',
				voicename:'陕西话voice',
				voicesize:'6432kb',
				operator:'admin',
				createstatue:'待发布',
				modifyDatetime:'2017-09-18 12:30'
				}]};   
	$("#describetxt_grid").datagrid('loadData',obj);
});
//封闭查询的条件
queryparamsfunc.getParams = function() {	      
//    queryParams.mainpointId = $('#q_mainpointId').textbox('getValue');
//    queryParams.mainpointId = rowData["mainpointId"];
    /*var row = $('#point_grid').datagrid('getSelected');
    queryParams.mainpointId=row.mainpointId;*/
//    if (row){
//    	alert('Item ID:'+row.mainpointId);
//    }
};
//封闭查询的条件
queryparamsfunc.getQueryParams = function(queryParams) {	      
	     /*queryParams.mainpointNo = $('#q_mainpointNo').textbox('getValue');*/
	     queryParams.mainpointName = $('#q_mainpointName').textbox('getValue');
	     queryParams.businessType = $('#q_businessType').combobox('getValue');
	     queryParams.mainpointId = $('#q_yaodianId').textbox('getValue');
	     queryParams.isReadable = $('#q_isRead').combobox('getValue');
	     //二期 加参数
	     //激活状态
	 /*    queryParams.activationState = $('#q_activationState').combobox('getValue');*/
	    /* queryParams.oragancode = $("#q_organ").combobox('getValue');*/
	    
};

//查询
function queryPoint() {
	queryData('/describe/point/list.html', 'q_frm', 'point_grid', 'getQueryParams')
}

function queryDescribe(){
	queryData('/describe/queryDescribe.html', 'q_frm', 'describe_grid', 'getParams')
}

//增加
function add() {
	//具体使用请参考common.js中说明
	/*/platform/describe/pointAdd.jsp要点添加页面位置*/
	openPage(webRoot+'/describe/riskTypePoint/add.html',"增加",700,500);
/*	refreshParentGrid("point_grid");*/
}
//增加话述
function addDescribeToPoint() {
	//具体使用请参考common.js中说明
var cks=$("[name=mainpointIdVo]:checked");
	
	if(cks.length==1){
		var key =$(cks).val();
		openPage(webRoot+'/describe/addDescribeToPointPage.html?key='+key,"增加话述到要点",700,500);
		refreshParentGrid("describe_grid");//刷新列表

	}else{
		$.messager.alert("警告!","请选择一条要点",  "warning");
	}
	
}
function opendescribetxt(){
var cks=$("[name=mainpointIdVo]:checked");
	
	if(cks.length==1){
		var key =$(cks).val();
		openPage(webRoot+'/basec/menu/platform/describe/addDescribeTxt.html?key='+key,"话术语音导入信息",800,600);
	}else{
		$.messager.alert("警告!","请选择一条要点",  "warning");
	}
}
function uploadMP3(){
	var row = $('#describe_grid').datagrid('getSelected');
	var row1 = JSON.stringify(row)
	if(row1 != "null"){
		var key =row.describeIdVo;
		openPage(webRoot+'/basec/menu/platform/describe/addMp3.html?key='+key,"mp3导入信息",400,200);
	}else{
		$.messager.alert("警告!","请选择一条质检话术",  "warning");
	}
	refreshParentGrid("describe_grid");//刷新列表
}
function downloadMP3(){
	var row = $('#describe_grid').datagrid('getSelected');
	var row1 = JSON.stringify(row);
	if(row1 != "null"){
		if(row.isUpload=="否"){
			$.messager.alert("警告!","该条话术没有上传mp3文件，请确认！",  "warning");
		}else{
			var key = row.describeIdVo;
			window.location=webRoot+"/mp3Upload/downloadMP3.html?key="+key;
		}
	}else{
		$.messager.alert("警告!","请选择一条质检话术",  "warning");
	}
}
function addDescribe(){
	openPage(webRoot+'/describe/describeAdd.html',"增加",700,500);
}
//导出文件
function exitFile(formId){
	var datastring = $('#' + formId).formSerialize();
	window.location=webRoot+"/describe/exp.html?"+datastring;
}

//修改
function update() {
	var cks=$("[name=mainpointIdVo]:checked");
	
	if(cks.length==1){
		var key =$(cks).val();
		openPage(webRoot+'/describe/riskTypePoint/update.html?key='+key,"修改",700,500);
	}else{
		$.messager.alert("警告!","请选择一条要点数据",  "warning");
	}
}
//要点修改
function pointUpdateJsp(){
	var data = isSelected('grid', true);
	if(data!=null){
		toJsp('/describe/findsPointById.html?id='+data.pointId,updateTitle);
	}
}

//修改话术跳转
function updateDescribe() {
	var cks=$("[name=describeIdVo]:checked");
	
	if(cks.length==1){
		var key =$(cks).val();
		openPage(webRoot+'/describe/updateDescribePage.html?key='+key,"修改",700,500);
	}else{
		$.messager.alert("警告!","请选择一条话述数据",  "warning");
	}
}
//要点修改
/*function pointUpdateJsp(){
	var data = isSelected('describe_grid', true);
	if(data!=null){
		toJsp('/describe/findsPointById.html?id='+data.pointId,updateTitle);
	}
}*/

//删除要点
function del() {
		var cks=$("[name=mainpointIdVo]:checked");
		if(cks.length==1){	
			var	keys=$(cks).val();	
		$.ajax({
	        data:{keys:keys},
	        type:"post",
	        url:webRoot+"/describe/riskTypePoint/query.html",
	        dataType:"json",
	        beforeSend:function(XMLHttpRequest){},
	        success:function(data, textStatus){  //data:返回的内容，可以是XML文档，JSON文件，HTML片段等等      //textStatus:请求状态：success、error、notmodified、timeout4种   
	        	var result=data;
	        	if(result.success){
	        		$.messager.alert("操作提示",result.msg, "info",function(){
	        		});
	        	}else{
	        		$.messager.confirm("操作提示", "您确定要执行操作吗？", function(data) {
	        			if (data) {
	        				var	keys=$(cks).val();
	        				keys=_enc(keys);//加密
	        				$.ajax({
	        			        data:{keys:keys},
	        			        type:"post",
	        			        url:webRoot+"/describe/riskTypePoint/del.html",
	        			        dataType:"json",
	        			        beforeSend:function(XMLHttpRequest){},
	        			        success:function(data, textStatus){  //data:返回的内容，可以是XML文档，JSON文件，HTML片段等等      //textStatus:请求状态：success、error、notmodified、timeout4种   
	        			        	var result=data;
	        			        	if(result.success){
	        			        		$.messager.alert("操作提示",result.msg, "info",function(){
	        			        			refreshParentGrid("describe_grid");//刷新话述列表
	        			        			refreshParentGrid("point_grid");//刷新要点列表
	        			        			
	        			        		});
	        			        	}else{
	        			        		$.messager.alert("操作提示",result.msg, "error");
	        			        	}
	        			        },
	        			        complete:function(XMLHttpRequest, textStatus){},
	        			        error:function(){	        			        	
	        			        }
	        			    });
	        			}
	        		});
	        	}
	        },
	        complete:function(XMLHttpRequest, textStatus){},
	        error:function(){
	        }
	    });
	}else if(cks.length>1){
		$.messager.confirm("操作提示", "您确定要执行操作吗？", function(data) {
			if (data) {
				var keys="";
				for(var i=0;i<cks.length;i++){
					keys+=$(cks[i]).val()+",";
				}
				keys=keys.substring(0,keys.length-1);
				keys=_enc(keys);//加密
				$.ajax({
			        data:{keys:keys},
			        type:"post",
			        url:webRoot+"/describe/riskTypePoint/del.html",
			        dataType:"json",
			        beforeSend:function(XMLHttpRequest){},
			        success:function(data, textStatus){  //data:返回的内容，可以是XML文档，JSON文件，HTML片段等等      //textStatus:请求状态：success、error、notmodified、timeout4种   
			        	var result=data;
			        	if(result.success){
			        		$.messager.alert("操作提示",result.msg, "info",function(){
			        			refreshParentGrid("describe_grid");//刷新话述列表
			        			refreshParentGrid("point_grid");//刷新要点列表			        			
			        		});
			        	}else{
			        		$.messager.alert("操作提示",result.msg, "error");
			        	}
			        },
			        complete:function(XMLHttpRequest, textStatus){},
			        error:function(){			        	
			        }
			    });
			}
		});
	}else{
		$.messager.alert("警告!","请选择数据",  "warning");
	}
}


//删除话述
function deletePiontDescribe() {
			var cks=$("[name=describeIdVo]:checked");
			if(cks.length>0){	
				var keys="";
				for(var i=0;i<cks.length;i++){
					keys+=$(cks[i]).val()+",";
				}
				keys=keys.substring(0,keys.length-1);
			$.ajax({
		        data:{keys:keys},
		        type:"post",
		        url:webRoot+"/describe/riskTypeDescribe/query.html",
		        dataType:"json",
		        beforeSend:function(XMLHttpRequest){},
		        success:function(data, textStatus){  //data:返回的内容，可以是XML文档，JSON文件，HTML片段等等      //textStatus:请求状态：success、error、notmodified、timeout4种   
		        	var result=data;
		        	if(!result.success){
		        		$.messager.alert("操作提示",result.msg, "info",function(){
		        		});
		        	}else{
		        		$.messager.confirm("操作提示", "您确定要执行操作吗？", function(data) {
		        			if (data) {
		        				var keys="";
		        				for(var i=0;i<cks.length;i++){
		        					keys+=$(cks[i]).val()+",";
		        				}
		        				keys=keys.substring(0,keys.length-1);
		        				
		        				keys=_enc(keys);//加密
		        				$.ajax({
		        			        data:{keys:keys},
		        			        type:"post",
		        			        url:webRoot+"/describe/deletePiontDescribe.html",
		        			        dataType:"json",
		        			        beforeSend:function(XMLHttpRequest){},
		        			        success:function(data, textStatus){  //data:返回的内容，可以是XML文档，JSON文件，HTML片段等等      //textStatus:请求状态：success、error、notmodified、timeout4种   
		        			        	var result=data;
		        			        	if(result.success){
		        			        		$.messager.alert("操作提示",result.msg, "info",function(){
		        			        			refreshParentGrid("describe_grid");//刷新列表
		        			        		});
		        			        	}else{
		        			        		$.messager.alert("操作提示",result.msg, "error");
		        			        	}
		        			        },
		        			        complete:function(XMLHttpRequest, textStatus){},
		        			        error:function(){

		        			        }
		        			    });
		        			}
		        		});
		        	}
		        },
		        complete:function(XMLHttpRequest, textStatus){},
		        error:function(){
		        	
		        }
		    });
		}else{
			$.messager.alert("警告!","请选择数据",  "warning");
		}
			
	/*if(cks.length>0){
		
		$.messager.confirm("操作提示", "删除话述将会删除对应保险信息，您确定要执行操作吗？", function(data) {
			if (data) {
				var keys="";
				for(var i=0;i<cks.length;i++){
					keys+=$(cks[i]).val()+",";
				}
				keys=keys.substring(0,keys.length-1);
				
				keys=_enc(keys);//加密
				$.ajax({
			        data:{keys:keys},
			        type:"post",
			        url:webRoot+"/describe/deletePiontDescribe.html",
			        dataType:"json",
			        beforeSend:function(XMLHttpRequest){},
			        success:function(data, textStatus){  //data:返回的内容，可以是XML文档，JSON文件，HTML片段等等      //textStatus:请求状态：success、error、notmodified、timeout4种   
			        	var result=data;
			        	if(result.success){
			        		$.messager.alert("操作提示",result.msg, "info",function(){
			        			refreshParentGrid("describe_grid");//刷新列表
			        		});
			        	}else{
			        		$.messager.alert("操作提示",result.msg, "error");
			        	}
			        },
			        complete:function(XMLHttpRequest, textStatus){},
			        error:function(){

			        }
			    });
			}
		});
	}else{
		$.messager.alert("警告!","请选择一条话述",  "warning");
	}*/
}

function operat(){
	queryDescribe()
}

function queryDescribe(mainpointIdVo){
	var cks=$("[name=mainpointIdVo]:checked");
	
	if(cks.length==1){
		var key =_enc($(cks).val());
		/*openPage(webRoot+'/riskTypePoint/riskTypePoint/update.html?key='+key,"修改",700,500);*/
		queryData('/describe/describeQuery.html?mainpointId='+mainpointId, 'q_frm', 'describe_grid', 'getQueryParams')	
	}else{
		$.messager.alert("警告!","请选择一条数据",  "warning");
	}
}
/*function updateDescribe() {
	var cks=$("[name=describeId]:checked");
	
	if(cks.length==1){
		var key =$(cks).val();
		openPage(webRoot+'/describe/updateDescribePage.html?key='+key,"修改",700,500);
	}else{
		$.messager.alert("警告!","请选择一条话述数据",  "warning");
	}
}*/
//激活要点
function activationPoint(){
	var cks=$("[name=mainpointIdVo]:checked");
	if(cks.length==1){
		var key =_enc($(cks).val());	
		updateData('/describe/pointActivation.html?keys='+key, 'q_frm', 'point_grid')	
	}else{
		$.messager.alert("警告!","请选择一条数据",  "warning");
	}
}
//要点失效
function InvalidPoint(){
	var cks=$("[name=mainpointIdVo]:checked");
	if(cks.length==1){
		var key =_enc($(cks).val());	
		updateData('/describe/InvalidPoint.html?keys='+key, 'q_frm', 'point_grid')	
	}else{
		$.messager.alert("警告!","请选择一条数据",  "warning");
	}
}
//激活话述
function activationDescribe(){
	var cks=$("[name=describeId]:checked");
	if(cks.length==1){
		var key =_enc($(cks).val());	
		updateData('/describe/describeActivation.html?keys='+key, 'q_frm', 'describe_grid')	
	}else{
		$.messager.alert("警告!","请选择一条数据",  "warning");
	}
}
//话述失效
function InvalidDescribe(){
	var cks=$("[name=describeId]:checked");
	if(cks.length==1){
		var key =_enc($(cks).val());	
		updateData('/describe/InvalidDescribe.html?keys='+key, 'q_frm', 'describe_grid')	
	}else{
		$.messager.alert("警告!","请选择一条数据",  "warning");
	}
}
