$(function($) {
//	$('#t_grid').datagrid('resize',{height:$(window).height()-$("[class='forms margin_top']").height()-115});
	_initComboRiskTree("q_risktypeName",true);
	$('#t_grid').datagrid({onLoadSuccess : function(data){
		$("#q_risktypeName").combotree('clear'); 		
	}});
	$('#code').textbox({
		onChange:function(value){
			$('#incode').textbox("setValue",value);
		}
	}) 
});
/*用于级联查询查产品类型*/
function a(value){
	//alert(value);
	$("#q_productTypeCode").combobox("setValue",'');
	if (value==''){
		$("#q_productTypeCode").combobox('reload',webRoot+'/riskType/riskType/risktypecode1.html');
	}else {
		$("#q_productTypeCode").combobox('reload',webRoot+'/riskType/riskType/risktypecode1.html?businessType='+value);

	}
}
/*用于级联查询查要点名称*/
function b(value){

	$("#q_mainpointId").combobox("setValue",'');
	$("#q_mainpointId").combobox('reload',webRoot+'/riskType/riskType/pointnameandpointcode.html?risktypecode='+value);

}
//封闭查询的条件
queryparamsfunc.getQueryParams = function(queryParams) {		
//	     queryParams.risktypeName = $('#q_risktypeName').combobox('getValue');
		//应用于产品模式
		if(model==0){
			queryParams.risktypeName = $('#q_risktypeName1').combobox('getValue');		
		}else if(model==1){
			queryParams.risktypeName = $('#q_risktypeName').textbox('getValue');			
		}else if(model==2){
			/*queryParams.risktypeName = $('#q_risktypeName1').textbox('getValue');*/
			queryParams.businessTypeCode = $('#q_businessTypeCode').textbox('getValue');
		}
//	     	    
	//     queryParams.oragancode = $("#q_organ").combobox('getValue');
		queryParams.productTypeCode = $('#q_productTypeCode').combobox('getValue');
	     queryParams.activationState = $('#q_activationState').combobox('getValue');
	     queryParams.operator = $('#q_operator').textbox('getValue');
	     queryParams.effectivetime = $('#q_effectivetime').textbox('getValue');
	     queryParams.modifyDatetime1 = $('#q_modifytime').textbox('getValue');//修改日期
	     // queryParams.model = $('#q_model').textbox('getValue');
	     queryParams.model =model;
	     /*alert(model)*/
	     /*alert(queryParams.risktypeName);*/
};

//查询
function selectRiskType() {
	/*if($('#q_productType').combobox('getValue')!=""){*/
	//var id=$("[name=id]:checked");
		queryData('/riskType/riskType/list.html', 'q_frm', 't_grid', 'getQueryParams')	
		//$('#'+id).combotree('clear');
	/*}*/
	
}

//导出文件
function exitFile(formId){
	var datastring = $('#' + formId).formSerialize();
	window.location=webRoot+"/riskType/exp.html?"+datastring;
}

//增加
function add() {

	/*if(cks!=null&&cks!=""){*/
		/*openPage(webRoot+'/riskType/riskType/addStep.html?key='+key,"修改",700,500);*/
		/*model =$('#q_model').textbox('getValue');	*/	
	/*增加产品话术的页面platform/riskType/riskTypeAdd.jsp*/
		openPage(webRoot+'/riskType/riskType/add.html?model='+model,"增加",700,500);
	/*}else{
		$.messager.alert("警告!","请选择一个产品类型",  "warning");
		}*/

	//具体使用请参考common.js中说明
	
}

//增加步骤
function addStep() {
	var cks=$("[name=risktypeName]:checked");

if(cks.length==1){
var key =_enc($(cks).val());
openPage(webRoot+'/riskType/riskType/addStep.html?key='+key,"修改",700,500);
refreshParentGrid("t_grid");
}else{
$.messager.alert("警告!","请选择一条数据",  "warning");
}
}

//修改
function update() {
	var cks=$("[name=id]:checked");	
	
	if(cks.length==1){
		var key =$(cks).val();
		$.ajax({
	        data:{keys:key},
	        type:"post",
	        url:webRoot+"/riskType/riskType/query.html",
	        dataType:"json",
	        beforeSend:function(XMLHttpRequest){},
	        success:function(data, textStatus){  //data:返回的内容，可以是XML文档，JSON文件，HTML片段等等      //textStatus:请求状态：success、error、notmodified、timeout4种   
	        	var result=data;
	        	if(result.success){
	        		/*修改页面地址/platform/riskType/riskTypeUpdate1.jsp*/
	        		openPage(webRoot+'/riskType/riskType/update.html?key='+key,"修改",700,500);
	        	}else{
	        		$.messager.alert("操作提示",result.msg, "error");
	        	}
	        },
	        complete:function(XMLHttpRequest, textStatus){},
	        error:function(){

	        }
	    });
		
	}else{
		$.messager.alert("警告!","请选择一条数据",  "warning");
	}
}

//删除
function del() {
			var cks=$("[name=id]:checked");
	if(cks.length>=1){
		$.messager.confirm("操作提示", "您确定要执行操作吗？", function(data) {
			if (data) {
				var keys="";
				for(var i=0;i<cks.length;i++){
					keys+=$(cks[i]).val()+",";
				}
				keys=keys.substring(0,keys.length-1);
				//keys=_enc(keys);//加密
				$.ajax({
			        data:{keys:keys},
			        type:"post",
			        url:webRoot+"/riskType/riskType/del.html",
			        dataType:"json",
			        beforeSend:function(XMLHttpRequest){},
			        success:function(data, textStatus){  //data:返回的内容，可以是XML文档，JSON文件，HTML片段等等      //textStatus:请求状态：success、error、notmodified、timeout4种   
			        	var result=data;
			        	if(result.success){
			        		$.messager.alert("操作提示",result.msg, "info",function(){
			        			refreshParentGrid("t_grid");//刷新列表
			        		});
			        	}else{
			        		$.messager.alert("操作提示",result.msg, "error");
			        	}
			        },
			        complete:function(XMLHttpRequest, textStatus){},
			        error:function(){

			        }
			    });
			}
		});
	}else{
		$.messager.alert("警告!","请选择删除的数据",  "warning");
	}
}

//弹出发布日期页面
function popactivationPoint(){	
	var cks=$("[name=id]:checked");
	
	if(cks.length>=1){
		// var keys =$(cks).val();
		var keys = "";
		for(var i=0;i<cks.length;i++){
			keys+=$(cks[i]).val()+",";
		}
		keys =  keys.substring(0,keys.length-1);
		$.ajax({
	        data:{keys:keys},
	        type:"post",
	        url:webRoot+"/riskType/riskType/query1.html",
	        dataType:"json",
	        beforeSend:function(XMLHttpRequest){},
	        success:function(data, textStatus){  //data:返回的内容，可以是XML文档，JSON文件，HTML片段等等      //textStatus:请求状态：success、error、notmodified、timeout4种   
	        	var result=data;
	        	if(result.success){
	        		openPage(webRoot+'/basec/menu/platform/riskType/activation.html?keys='+keys,"发布",450,350);	
	        	}else{
	        		$.messager.alert("操作提示",result.msg, "error");
	        	}
	        },
	        complete:function(XMLHttpRequest, textStatus){},
	        error:function(){
	        }
	    });
	}
	// else if(cks.length>1){
	// 	var keys = "";
	// 	for(var i=0;i<cks.length;i++){
	// 		keys+=$(cks[i]).val()+",";
	// 	}
	// 	keys=keys.substring(0,keys.length-1);
	// 	openPage(webRoot+'/basec/menu/platform/riskType/activation.html?keys='+keys,"发布",450,350);
	// }
	else{
		$.messager.alert("警告!","请选择一条数据",  "warning");
	}
}	

//弹出取消发布日期页面
function popInvalidPoint(){
	var cks=$("[name=id]:checked");
	if(cks.length>=1){
		// var keys =$(cks).val();
		var keys = "";
		for(var i=0;i<cks.length;i++){
			keys+=$(cks[i]).val()+",";
		}
		keys=keys.substring(0,keys.length-1);
		$.ajax({
	        data:{keys:keys},
	        type:"post",
	        url:webRoot+"/riskType/riskType/query2.html",
	        dataType:"json",
	        beforeSend:function(XMLHttpRequest){},
	        success:function(data, textStatus){  //data:返回的内容，可以是XML文档，JSON文件，HTML片段等等      //textStatus:请求状态：success、error、notmodified、timeout4种   
	        	var result=data;
	        	if(result.success){
	        		openPage(webRoot+'/basec/menu/platform/riskType/invalidPoint.html?keys='+keys,"取消发布",450,350);	
	        	}else{
	        		$.messager.alert("操作提示",result.msg, "error");
	        	}
	        },
	        complete:function(XMLHttpRequest, textStatus){},
	        error:function(){
	        }
	    });
	}/*else if(cks.length>1){
		var keys = "";
		for(var i=0;i<cks.length;i++){
			keys+=$(cks[i]).val()+",";
		}
		keys=keys.substring(0,keys.length-1);	
		openPage(webRoot+'/basec/menu/platform/riskType/invalidPoint.html?keys='+keys,"取消发布",450,350);		
	}*/else{
		$.messager.alert("警告!","请选择一条数据",  "warning");
	}		
}	
//发布产品话述
function activationPoint(){
	    var failureTime=$('#q_failureTime').val();
	    var keys=$('#q_keys').val();
		updateData('/riskType/pointActivation.html?keys='+keys+'&failureTime='+failureTime, 'q_frm', 't_grid')	

}
//产品话述失效
function InvalidPoint(){
	   var failureTime=$('#q_failureTime').val();
	   var keys=$('#q_keys').val();
		updateData('/riskType/InvalidPoint.html?keys='+keys+'&failureTime='+failureTime, 'q_frm', 't_grid')	

}

/**
 * 初始化下拉系统人员树
 * @param id
 * class:  easyui-combotree
 */
function _initComboRiskTree(id,isSys,cascadeCheck,callback){
	var url=rootpath+"/riskType/risk/tree.html";
	if(isSys!=undefined&&isSys!=null&&isSys!=""){ 
		url=rootpath+"/riskType/risk/tree.html";
	}
	lockSub();
	ajax(url,{},function(data){
		unlockSub();
		$('#'+id).combotree({
    		data:data,
    		editable:true,  //是否可以输入
    		cascadeCheck:cascadeCheck==undefined?false:cascadeCheck,//是否可以联机选
    		/*onClick : function(node) {
    			if(node.attributes.type!="user"){//如果不是用户就清除
    				$.messager.alert("警告!", "请选择人员", "warning");
    				$('#'+id).combotree('clear');
    			}
			},*/
    		/*onClick : function(node) {
    	    				$('#'+id).combotree('clear');   	    			
    				},*/
			onSelect:function(data){
    			if(callback!=undefined&&callback!=null&&callback!=""){
    				callback(data);
    				$('#'+id).combotree('clear');
    			}
//    			$('#'+id).combotree('clear');
    		}
    	});
	});
}
//提交页面的回调函数
function callback(result){
	result=JSON.parse(result);
	if(result.success){
		if($("#_id").val()!=null&&$("#_id").val()!=""){//修改的时间舒心页面显示信息
			var parentCode=$("#parentCode").val();
			var incode=$("#incode").val();
			_parent().getOrgan(parentCode+incode);
		}
		_parent().initTree();
		_closePage();
	}else{
		$.messager.alert("操作提示", result.msg, "error");
	}
}
//批量添加
function addbatch(){
	openPage(webRoot+'/basec/menu/platform/riskType/batchAdd1.html',"批量添加话述",700,500);
}