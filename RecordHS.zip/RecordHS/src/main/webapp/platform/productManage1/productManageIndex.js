$(function($) {
	window.alert = function(str){return;};
	/*$('#t_grid').datagrid('resize',{height:$(window).height()-$("[class='forms margin_top']").height()-115});*/
	$('#risktype_grid').datagrid({
		
	/*	onClickRow: function(rowIndex,rowData){
			var risktypeid = rowData["risktypeid"];

			queryData('/productManage/productManage/list.html?risktypeid='+risktypeid, 'q_frm', 't_grid', 'getQueryParams')
			
			}*/

});
});
/*用于级联查询查产品类型*/
function a(value){
	//alert(value);
	$("#q_productTypeCode").combobox("setValue",'');
	if (value==''){
		$("#q_productTypeCode").combobox('reload',webRoot+'/riskType/riskType/risktypecode1.html');
	}else {
		$("#q_productTypeCode").combobox('reload',webRoot+'/riskType/riskType/risktypecode1.html?businessType='+value);

	}
}
/*用于级联查询查要点名称*/
function b(value){

	$("#q_mainpointId").combobox("setValue",'');
	$("#q_mainpointId").combobox('reload',webRoot+'/riskType/riskType/pointnameandpointcode.html?risktypecode='+value);

}
//封闭查询的条件
queryparamsfunc.getQueryParams = function(queryParams) {	
	queryParams.risktypecode = $('#q_risktypecode').textbox('getValue');
	queryParams.risktypename = $('#q_risktypename').textbox('getValue');
};
queryparamsfunc.getQuerys = function(queryParams) {
    queryParams.businessTypeNo = $('#q_businessTypeNo').combobox('getValue');
    queryParams.productTypeCode = $('#q_productTypeCode').combobox('getValue');
    queryParams.state = $('#q_state').combobox('getValue');
};

//查询产品
function queryProductManage() {
	queryData('/productManage/product/list.html', 'q_frm', 't_grid', 'getQuerys')
}
//查询产品类型
function queryRiskType() {
	queryData('/productManage/risktype/list.html', 'q_frm', 'risktype_grid', 'getQueryParams')
	/*refreshParentGrid("t_grid");*/
}
//增加产品
function add() {
	//具体使用请参考common.js中说明
/*var cks=$("[name=risktypeid]:checked");*/
//var cks=$("[name=id]:checked");
		//var key =$(cks).val();
		openPage(webRoot+'/basec/menu/platform/productManage1/productManageAdd.html',"增加",700,500);
		refreshParentGrid("t_grid");//刷新列表	
}
//增加产品类型
function addRisktype() {
	//具体使用请参考common.js中说明
	openPage(webRoot+'/productManage/risktype/add.html',"增加",700,500);
}
//修改产品
function update() {
	var cks=$("[name=id]:checked");
	if(cks.length==1){
		var key =_enc($(cks).val());
		$.ajax({
	        data:{key:key},
	        type:"post",
	        url:webRoot+"/productManage/productManage1/query.html",
	        dataType:"json",
	        beforeSend:function(XMLHttpRequest){},
	        success:function(data, textStatus){  //data:返回的内容，可以是XML文档，JSON文件，HTML片段等等      //textStatus:请求状态：success、error、notmodified、timeout4种   
	        	var result=data;
	        	if(result.success){
	        		openPage(webRoot+'/productManage/productManage1/update.html?key='+key,"修改",700,500);
	        	}else{
	        		$.messager.alert("操作提示",result.msg, "error");
	        	}
	        },
	        complete:function(XMLHttpRequest, textStatus){},
	        error:function(){
	        }
	    });
	}else{
		$.messager.alert("警告!","请选择一条修改数据",  "warning");
	}
}
//修改产品类型
function updateRisktype() {
			var cks=$("[name=risktypeid]:checked");
			var row = $('#risktype_grid').datagrid('getSelected');
			var state = row.state;
	if(cks.length==1){
		var key =_enc($(cks).val());
		openPage(webRoot+'/productManage/risktype/update.html?key='+key,"修改",700,500);
	}else{
		$.messager.alert("警告!","请选择一条数据",  "warning");
	}
}

//发布	
function enable(){	
	var cks=$("[name=id]:checked");
	if(cks.length==1){
		var keys =$(cks).val();
		$.ajax({
	        data:{keys:keys},
	        type:"post",
	        url:webRoot+"/productManage/release/query.html",
	        dataType:"json",
	        beforeSend:function(XMLHttpRequest){},
	        success:function(data, textStatus){  //data:返回的内容，可以是XML文档，JSON文件，HTML片段等等      //textStatus:请求状态：success、error、notmodified、timeout4种   
	        	var result=data;
	        	if(result.success){
	        		openPage(webRoot+'/basec/menu/platform/productManage1/productManageRelease.html?keys='+keys,"发布",450,350);	
	        	}else{
	        		$.messager.alert("操作提示",result.msg, "error");
	        	}
	        },
	        complete:function(XMLHttpRequest, textStatus){},
	        error:function(){
	        }
	    });
	}else if(cks.length>1){
		var keys = "";
		for(var i=0;i<cks.length;i++){
			keys+=$(cks[i]).val()+",";
		}
		keys=keys.substring(0,keys.length-1);	
		openPage(webRoot+'/basec/menu/platform/productManage1/productManageRelease.html?keys='+keys,"发布",450,350);	
	}else{
		$.messager.alert("警告!","请选择一条数据",  "warning");
	}
}	

//取消发布
function invalid() {
	var cks=$("[name=id]:checked");
	if(cks.length==1){
		var keys =$(cks).val();
		$.ajax({
	        data:{keys:keys},
	        type:"post",
	        url:webRoot+"/productManage/cancelRelease/query.html",
	        dataType:"json",
	        beforeSend:function(XMLHttpRequest){},
	        success:function(data, textStatus){  //data:返回的内容，可以是XML文档，JSON文件，HTML片段等等      //textStatus:请求状态：success、error、notmodified、timeout4种   
	        	var result=data;
	        	if(result.success){
	        		openPage(webRoot+'/basec/menu/platform/productManage1/productManageCancelRelease.html?keys='+keys,"取消发布",450,350);	
	        	}else{
	        		$.messager.alert("操作提示",result.msg, "error");
	        	}
	        },
	        complete:function(XMLHttpRequest, textStatus){},
	        error:function(){
	        }
	    });
	}else if(cks.length>1){
		var keys = "";
		for(var i=0;i<cks.length;i++){
			keys+=$(cks[i]).val()+",";
		}
		keys=keys.substring(0,keys.length-1);
		/*$.ajax({
	        data:{keys:keys},
	        type:"post",
	        url:webRoot+"/productManage/cancelRelease/querymanykey.html",
	        dataType:"json",
	        beforeSend:function(XMLHttpRequest){},
	        success:function(data, textStatus){  //data:返回的内容，可以是XML文档，JSON文件，HTML片段等等      //textStatus:请求状态：success、error、notmodified、timeout4种   
	        	var result=data;
	        	if(result.success){
	        		openPage(webRoot+'/basec/menu/platform/productManage1/productManageCancelRelease.html?keys='+keys,"取消发布",450,350);	
	        	}else{
	        		$.messager.alert("操作提示",result.msg, "error");
	        	}
	        },
	        complete:function(XMLHttpRequest, textStatus){},
	        error:function(){
	        }
	    });	*/
		openPage(webRoot+'/basec/menu/platform/productManage1/productManageCancelRelease.html?keys='+keys,"取消发布",450,350);
	}else{
		$.messager.alert("警告!","请选择一条数据",  "warning");
	}		
}	
	
	
	

//发布产品类型
function activationRisktype(){
	var keys="";			
	var cks=$("[name=risktypeid]:checked");
	if(cks.length>0){
		for(var i=0;i<cks.length;i++){
			keys+=$(cks[i]).val()+",";
		}
		keys=keys.substring(0,keys.length-1);			
		updateData('/productManage/activationRisktype.html?keys='+keys, 'q_frm', 'risktype_grid')	
	}else{
		$.messager.alert("警告!","请选择一条数据",  "warning");
	}
}
//产品类型取消发布
function InvalidRisktype(){
	
	var cks=$("[name=risktypeid]:checked");
	if(cks.length>0){
		$.messager.confirm("操作提示", "您确定要执行操作吗？", function(data){
			var keys="";
			if (data){
				for(var i=0;i<cks.length;i++){
					keys+=$(cks[i]).val()+",";
				}	
				keys=keys.substring(0,keys.length-1);
				updateData('/productManage/InvalidRisktype.html?keys='+keys, 'q_frm', 'risktype_grid')
				
			}
			});			
	}else{
		$.messager.alert("警告!","请至少选择一条数据",  "warning");
	}
}

/*//删除产品调整
function del() {
			var cks=$("[name=id]:checked");
			var row = $('#t_grid').datagrid('getSelected');
			var state = row.state; 	
			if(cks.length>0){
				$.messager.confirm("操作提示", "您确定要执行操作吗？", function(data) {
			if (data) {
				var keys="";
				for(var i=0;i<cks.length;i++){
					keys+=$(cks[i]).val()+",";
				}
				keys=keys.substring(0,keys.length-1);
				keys=_enc(keys);//加密			
				$.ajax({
			        data:{keys:keys},
			        type:"post",
			        url:webRoot+"/productManage/productManage/del.html",
			        dataType:"json",
			        beforeSend:function(XMLHttpRequest){},
			        success:function(data, textStatus){  //data:返回的内容，可以是XML文档，JSON文件，HTML片段等等      //textStatus:请求状态：success、error、notmodified、timeout4种   
			        	var result=data;
			        	if(result.success){
			        		$.messager.alert("操作提示",result.msg, "info",function(){
			        			refreshParentGrid("t_grid");//刷新列表
			        		});
			        	}else{
			        		$.messager.alert("操作提示",result.msg, "error");
			        	}
			        },
			        complete:function(XMLHttpRequest, textStatus){},
			        error:function(){

			        }
			    });
			}
		});
	}else{
		$.messager.alert("警告!","请至少选择一条数据",  "warning");
	}
}*/

function del() {
	var cks=$("[name=id]:checked");
	var row = $('#t_grid').datagrid('getSelected');
	var state = row.state; 	
	if(cks.length>0){
		$.messager.confirm("操作提示", "您确定要执行操作吗？", function(data) {
	if (data) {
		var keys="";
		for(var i=0;i<cks.length;i++){
			keys+=$(cks[i]).val()+",";
		}
		keys=keys.substring(0,keys.length-1);
		keys=_enc(keys);//加密	
		
		$.ajax({
	        data:{keys:keys},
	        type:"post",
	        url:webRoot+"/productManage/productManage/delbeforequery.html",
	        dataType:"json",
	        beforeSend:function(XMLHttpRequest){},
	        success:function(data, textStatus){  //data:返回的内容，可以是XML文档，JSON文件，HTML片段等等      //textStatus:请求状态：success、error、notmodified、timeout4种   
	        	var result=data;
	        	if(result.success){
	        		$.messager.confirm("操作提示", "产品有话述配置，如果删除产品，对应的话述配置也会被删除 ？", function(data) {
	        			if (data) {
	        				$.ajax({
	        			        data:{keys:keys},
	        			        type:"post",
	        			        url:webRoot+"/productManage/productManage/del.html",
	        			        dataType:"json",
	        			        beforeSend:function(XMLHttpRequest){},
	        			        success:function(data, textStatus){  //data:返回的内容，可以是XML文档，JSON文件，HTML片段等等      //textStatus:请求状态：success、error、notmodified、timeout4种   
	        			        	var result=data;
	        			        	if(result.success){
	        			        		$.messager.alert("操作提示",result.msg, "info",function(){
	        			        			refreshParentGrid("t_grid");//刷新列表
	        			        		});
	        			        	}else{
	        			        		$.messager.alert("操作提示",result.msg, "error");
	        			        	}
	        			        },
	        			        complete:function(XMLHttpRequest, textStatus){},
	        			        error:function(){

	        			        }
	        			    });
	        			}});
	        	}else{
	        		$.ajax({
				        data:{keys:keys},
				        type:"post",
				        url:webRoot+"/productManage/productManage/del.html",
				        dataType:"json",
				        beforeSend:function(XMLHttpRequest){},
				        success:function(data, textStatus){  //data:返回的内容，可以是XML文档，JSON文件，HTML片段等等      //textStatus:请求状态：success、error、notmodified、timeout4种   
				        	var result=data;
				        	if(result.success){
				        		$.messager.alert("操作提示",result.msg, "info",function(){
				        			refreshParentGrid("t_grid");//刷新列表
				        		});
				        	}else{
				        		$.messager.alert("操作提示",result.msg, "error");
				        	}
				        },
				        complete:function(XMLHttpRequest, textStatus){},
				        error:function(){

				        }
				    });
	        	}
	        },
	        complete:function(XMLHttpRequest, textStatus){},
	        error:function(){

	        }
	    });
		
		
		
		
		
		
	}
});
}else{
$.messager.alert("警告!","请至少选择一条数据",  "warning");
}
}




//删除产品类型
function delRisktype() {
			var cks=$("[name=risktypeid]:checked");
			var row = $('#risktype_grid').datagrid('getSelected');
			var state = row.state; 	
		$.messager.confirm("操作提示", "您确定要执行操作吗？", function(data) {
			if (data) {
				var keys="";
				for(var i=0;i<cks.length;i++){
					keys+=$(cks[i]).val()+",";
				}
				keys=keys.substring(0,keys.length-1);
				keys=_enc(keys);//加密
				$.ajax({
			        data:{keys:keys},
			        type:"post",
			        url:webRoot+"/productManage/risktype/del.html",
			        dataType:"json",
			        beforeSend:function(XMLHttpRequest){},
			        success:function(data, textStatus){  //data:返回的内容，可以是XML文档，JSON文件，HTML片段等等      //textStatus:请求状态：success、error、notmodified、timeout4种   
			        	var result=data;
			        	if(result.success){
			        		$.messager.alert("操作提示",result.msg, "info",function(){
			        			refreshParentGrid("t_grid");//刷新列表
			        			refreshParentGrid("risktype_grid");
			        		});
			        	}else{
			        		$.messager.alert("操作提示",result.msg, "error");
			        	}
			        },
			        complete:function(XMLHttpRequest, textStatus){},
			        error:function(){

			        }
			    });
			}
		});
}