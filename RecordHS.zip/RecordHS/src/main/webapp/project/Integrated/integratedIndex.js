$(function($) {
	$('#t_grid').datagrid('resize',{height:$(window).height()-$("[class='forms margin_top']").height()-115});
	$('#tt_grid').datagrid({
		
		onClickRow: function(rowIndex,rowData){
			var docid = rowData["docid"];
			/*var doccode = rowData["doccode"];*/						
				 /*window.open(webRoot+'/integrated/toVideo.html?docid='+docid+'&doccode='+doccode);*/
				 queryData('/integrated/selectAllHis.html?key='+docid, 'q_frm', 'tp_grid',
					'getQueryParams');
												
		}
	});
	/*	$('#q_startScanDate').datebox().datebox('calendar').calendar({
			validator: function(date){
				var now = new Date();
				var d1 = new Date(now.getFullYear(), now.getMonth()-1, now.getDate());
				var d2 = new Date(now.getFullYear(), now.getMonth(), now.getDate());
				$('#q_startScanDate').datebox('setValue',d1);
				document.getElementById("q_startScanDate").value="d1";
//					RETURN D1<=DATE && DATE<=D2;
				
			}
		});*/
		/*var ss=$('#q_startScanDate').val;
		alert(ss);
		var qq=document.getElementById('q_startScanDate');
		alert(qq);*/
		
		/*var x = document.getElementsByName("score")[0];
		alert(x);//测试是否取到这个对象,结果是已经取到了
		alert(x.value);*/
		
		
		
//	_initComboRiskTree("q_risktypecode",true);
	/*$('#tt_grid').datagrid({onLoadSuccess : function(data){
		$("#q_risktypecode").combotree('clear'); 		
	}});*/
//	$('#tp_grid').datagrid({		
//			onClickRow: function(rowIndex,rowData){
//				var docid = rowData["docid"];
//				var doccode = rowData["doccode"];
//				/*window.open(webRoot+'/integrated/toVideoHis.html?docid='+docid+'&doccode='+doccode);*/			
//				/* window.open(webRoot+'/integrated/toVideoHis.html?docid='+docid+'&doccode='+doccode);*/ 
//				queryVideoMainHis();
//													
//			}
//		});
});


$(function()  
	    {     
	  /*   var curr_time=new Date();     
	        var strDate=curr_time.getFullYear()+"-";     
	        strDate +=curr_time.getMonth()+1+"-";     
	        strDate +=curr_time.getDate();       
	        strDate +=" "+curr_time.getHours()+":";     
	        strDate +=curr_time.getMinutes()+":";     
	        strDate +=curr_time.getSeconds();    
	        $("#q_startScanDate").datebox("setValue",strDate);  
	        $("#q_endScanDate").datebox("setValue",strDate); */
	    });  

//封闭查询的条件
queryparamsfunc.getQueryParams = function(queryParams) {
	 queryParams.appntNo = $('#q_appntNo').textbox('getValue');
	 queryParams.agentid = $('#q_agentid').textbox('getValue');
	 queryParams.status = $('#q_status').textbox('getValue');
	 queryParams.businessTypeCode = $('#q_businessTypeCode').textbox('getValue');
	 queryParams.productName = $('#q_productName').combobox("getValue");
	 queryParams.risktypecode = $('#q_risktypecode').textbox('getValue');
	 queryParams.startScanDate = $('#q_startScanDate').textbox('getValue');
	 queryParams.endScanDate = $('#q_endScanDate').textbox('getValue');	   
	 queryParams.doccode = $('#q_doccode').textbox('getValue');    
	 queryParams.qcoperator = $('#q_qcoperator').textbox('getValue');
	 queryParams.qcoperator1 = $('#q_qcoperator1').textbox('getValue');
};
function download() {
	 appntNo = $('#q_appntNo').textbox('getValue');
	 agentid = $('#q_agentid').textbox('getValue');
	 status = $('#q_status').textbox('getValue');
	 businessTypeCode = $('#q_businessTypeCode').textbox('getValue');
	 productName = $('#q_productName').combobox("getValue");
	 risktypecode = $('#q_risktypecode').textbox('getValue');
	 startScanDate = $('#q_startScanDate').textbox('getValue');
	 endScanDate = $('#q_endScanDate').textbox('getValue');	   
	 doccode = $('#q_doccode').textbox('getValue');	 
   if(appntNo==""&& agentid==""&& status==""&& businessTypeCode==""&& productName==""&& risktypecode==""&& startScanDate==""&&endScanDate==""
   	&&doccode==""){
		$.messager.confirm("操作提示", "将下载三个月内的数据，您确定要执行操作吗？", function(data) {
			if (data) {
				startScanDate = new Date();
				endScanDate=new Date();
				/*startScanDate.setMonth(startScanDate.getMonth()-3);*/
				var strDate2=startScanDate.getFullYear()+"-";     
		        strDate2 +=startScanDate.getMonth()-2+"-";     
		        strDate2 +=startScanDate.getDate();
		        var strDate3=endScanDate.getFullYear()+"-";     
		        strDate3 +=endScanDate.getMonth()+1+"-";     
		        strDate3 +=endScanDate.getDate();
		        $("#q_startScanDate").datebox("setValue",strDate2);  
		        $("#q_endScanDate").datebox("setValue",strDate3); 
		        startScanDate = $('#q_startScanDate').textbox('getValue');
		   	 endScanDate = $('#q_endScanDate').textbox('getValue');	
		    window.location.href =webRoot+"/integrated/integratedExport_excel.html?appntNo="+appntNo+"&agentid="+agentid+
		    "&status="+status+"&businessTypeCode="+businessTypeCode+"&productName="+productName+
		    "&risktypecode="+risktypecode+"&startScanDate="+startScanDate+"&endScanDate="+endScanDate+"&doccode="+doccode;
			}
		});
   }else{
	   /*alert(startScanDate);
	   alert(endScanDate);*/
   	window.location.href =webRoot+"/integrated/integratedExport_excel.html?appntNo="+appntNo+"&agentid="+agentid+
		    "&status="+status+"&businessTypeCode="+businessTypeCode+"&productName="+productName+
		    "&risktypecode="+risktypecode+"&startScanDate="+startScanDate+"&endScanDate="+endScanDate+"&doccode="+doccode;
   }
}
//查询
/*function queryIntegrated() {
	queryData('/esdocMain/integrated/list.html', 'q_frm', 't_grid', 'getQueryParams')
}*/
//查询所有
function queryVideoMain() {
	queryData('/integrated/selectAll.html?middle=0', 'q_frm', 'tt_grid',
			'getQueryParams');

}
function queryMessage(){
	var cks=$("[name=docid]:checked");
	var row = $('#tt_grid').datagrid('getSelected');
	var docid =$(cks).val();
	var player=row.player;
	var status=row.status;
	var doccode=row.doccode;
	if(cks.length==1){
		
			var docCCTV='';
			docCCTV=doccode.substring(0,4);
			if(docCCTV!="CCTV"){
				
				var targetWndName = "MyWindow";    
				   var wnd = window.open("",targetWndName);    
				   var link = document.getElementById("link");    
				   link.target = targetWndName;    
				   link.href = webRoot+'/integrated/toVideo.html?docid='+docid;    
				   link.click();  
				
				
				
				
				
				/*window.open(webRoot+'/integrated/toVideo.html?docid='+docid);*/
		}else{
			$.messager.alert("警告!","CCTV上传单无法影像信息",  "warning");
		}
		/*if(player=="否"){
			$.messager.confirm("操作提示", "该视频已经超出了期限，暂时无法播放，可以进行恢复，质检基本信息没有影响，是否继续查看？", function(data) {
				if(data){
					window.open(webRoot+'/integrated/toVideo.html?docid='+docid);
				}			
			});
		}else if(status=="质检通过"||status=="待整改"||status=="质检通过(提醒)"||status=="整改完成"
			||status=="整改过期"||status=="待质检"){*/
			
		/*}else{
			$.messager.alert("警告!","数据流转状态的影像信息无法查看",  "warning");
		}*/	
	}else{
		$.messager.alert("警告!","请选择一条数据",  "warning");
	}
	/*window.open(webRoot+'/integrated/toVideo.html?docid='+docid+'&doccode='+doccode);*/
	
}
function queryCCTV(){
	var cks=$("[name=docid]:checked");
	var row = $('#tt_grid').datagrid('getSelected');
	var docid =$(cks).val();
	var doccode=row.doccode;
	if(cks.length==1){
		var docCCTV='';
		docCCTV=doccode.substring(0,4);
		if(docCCTV=="CCTV"){
		//window.open(webRoot+'/integrated/queryCCTV.html?docid='+docid);
			
		openPage(webRoot+'/integrated/queryCCTV.html?docid='+docid,"附件下载地址",300,225);
		}else{
				$.messager.alert("警告!","此单无法去往CCTV附件下载页面",  "warning");
		}	
	}else{
		$.messager.alert("警告!","请选择一条数据",  "warning");
	}
}
function queryVideoMainHis(){
	var row = $('#tp_grid').datagrid('getSelected');
	var rows = $('#tp_grid').datagrid('getSelections');
	var docidVo = row.docid;
	var player=row.player;
	var cks=$("[name=docid]:checked");
	if(rows&&rows.length==1){
		if(player=="否"){
			$.messager.confirm("操作提示", "该视频已经超出了期限，暂时无法播放，可以进行恢复，质检基本信息没有影响，是否继续查看？", function(data) {
				if(data){
					
					var targetWndName = "MyWindow";    
					   var wnd = window.open("",targetWndName);    
					   var link = document.getElementById("link");    
					   link.target = targetWndName;    
					   link.href = webRoot+'/integrated/toVideoHis.html?docid='+docidVo;    
					   link.click();
					
					/*window.open(webRoot+'/integrated/toVideoHis.html?docid='+docidVo);*/
				}			
			});
		}else{
			var targetWndName = "MyWindow1";    
			   var wnd = window.open("",targetWndName);    
			   var link = document.getElementById("link");    
			   link.target = targetWndName;    
			   link.href = webRoot+'/integrated/toVideoHis.html?docid='+docidVo;    
			   link.click();
			/*window.open(webRoot+'/integrated/toVideoHis.html?docid='+docidVo);*/
		}
	}else{
		$.messager.alert("警告!","请选择一条数据",  "warning");
	}
		
}
//增加
function add() {
	//具体使用请参考common.js中说明
	openPage(webRoot+'/integrated/integrated/add.html',"增加",700,500);
}

//修改
function update() {
			var cks=$("[name=docid]:checked");
	
	if(cks.length==1){
		var key =_enc($(cks).val());
		openPage(webRoot+'/integrated/integrated/update.html?key='+key,"修改",700,500);
	}else{
		$.messager.alert("警告!","请选择一条数据",  "warning");
	}
}


/**
 * 初始化下拉系统人员树
 * @param id
 * class:  easyui-combotree
 */
function _initComboRiskTree(id,isSys,cascadeCheck,callback){
	var url=rootpath+"/riskType/risk/tree.html";
	if(isSys!=undefined&&isSys!=null&&isSys!=""){ 
		url=rootpath+"/riskType/risk/tree.html";
	}
	lockSub();
	ajax(url,{},function(data){
		unlockSub();
		$('#'+id).combotree({
    		data:data,
    		editable:true,  //是否可以输入
    		cascadeCheck:cascadeCheck==undefined?false:cascadeCheck,//是否可以联机选
    		/*onClick : function(node) {
    			if(node.attributes.type!="user"){//如果不是用户就清除
    				$.messager.alert("警告!", "请选择人员", "warning");
    				$('#'+id).combotree('clear');
    			}
			},*/
    		/*onClick : function(node) {
    	    				$('#'+id).combotree('clear');   	    			
    				},*/
			onSelect:function(data){
    			if(callback!=undefined&&callback!=null&&callback!=""){
    				callback(data);
    				$('#'+id).combotree('clear');
    			}
//    			$('#'+id).combotree('clear');
    		}
    	});
	});
}
//提交页面的回调函数
function callback(result){
	result=JSON.parse(result);
	if(result.success){
		if($("#_id").val()!=null&&$("#_id").val()!=""){//修改的时间舒心页面显示信息
			var parentCode=$("#parentCode").val();
			var incode=$("#incode").val();
			_parent().getOrgan(parentCode+incode);
		}
		_parent().initTree();
		_closePage();
	}else{
		$.messager.alert("操作提示", result.msg, "error");
	}
}