$(function($) {
	$('#t_grid').datagrid('resize',{height:$(window).height()-$("[class='forms margin_top']").height()-115});
	$('#tt_grid').datagrid({
		
		onClickRow: function(rowIndex,rowData){
			var docid = rowData["docid"];
			/*var doccode = rowData["doccode"];*/						
				 /*window.open(webRoot+'/integrated/toVideo.html?docid='+docid+'&doccode='+doccode);*/
				 queryData('/integrated/selectAllHis.html?key='+docid, 'q_frm', 'tp_grid',
					'getQueryParams');
												
		}
	});

	_initComboRiskTree("q_risktypecode",true);
	$('#tt_grid').datagrid({onLoadSuccess : function(data){
		$("#q_risktypecode").combotree('clear'); 		
	}});
//	$('#tp_grid').datagrid({		
//			onClickRow: function(rowIndex,rowData){
//				var docid = rowData["docid"];
//				var doccode = rowData["doccode"];
//				/*window.open(webRoot+'/integrated/toVideoHis.html?docid='+docid+'&doccode='+doccode);*/			
//				/* window.open(webRoot+'/integrated/toVideoHis.html?docid='+docid+'&doccode='+doccode);*/ 
//				queryVideoMainHis();
//													
//			}
//		});
});

//封闭查询的条件
queryparamsfunc.getQueryParams = function(queryParams) {
	queryParams.appntno = $("#q_appntno").textbox("getValue");
	queryParams.agentid = $("#q_agentid").textbox("getValue");	
	queryParams.status = $("#q_status").textbox("getValue");
	queryParams.businesstype = $("#q_businesstype").textbox("getValue");
	queryParams.productname = $("#q_productname").combobox("getValue");
	queryParams.productcode = $("#q_productcode").textbox("getValue");
	queryParams.startScanDate = $("#q_startscandate").textbox("getValue");
	queryParams.endScanDate = $("#q_endscandate").textbox("getValue");
	queryParams.businessno = $("#q_businessno").textbox("getValue");  
	queryParams.financedCode = $("#q_financedCode").textbox("getValue");
	queryParams.qcoperator = $('#q_qcoperator').textbox('getValue');
	queryParams.qcoperator1 = $('#q_qcoperator1').textbox('getValue');
	
};

//查询
/*function queryIntegrated() {
	queryData('/esdocMain/integrated/list.html', 'q_frm', 't_grid', 'getQueryParams')
}*/
//查询所有
function queryVideoMain() {
	
//	queryData('/esvideoMain/queryAllByCondition.html', 'q_frm', 'tt_grid',
//			'getQueryParams');
	queryData('/sampling/selectAll.html', 'q_frm', 'tt_grid',
			'getQueryParams');

}
function qcTaskAllocation(){
	var cks=$("[name=doccodevo]:checked");
	var doccodevo =$(cks).val();
	if(cks.length==1){
		/*同级目录samplingAllot.jsp*/
		openPage(webRoot+'/sampling/toAllocation.html?doccodevo='+doccodevo,"抽检任务分配",700,500);
	}else{
		$.messager.alert("警告!","请选择一条数据",  "warning");
	}
	
	
}

//增加
function add() {
	//具体使用请参考common.js中说明
	openPage(webRoot+'/integrated/integrated/add.html',"增加",700,500);
}

//修改
function update() {
			var cks=$("[name=docid]:checked");
	
	if(cks.length==1){
		var key =_enc($(cks).val());
		openPage(webRoot+'/integrated/integrated/update.html?key='+key,"修改",700,500);
	}else{
		$.messager.alert("警告!","请选择一条数据",  "warning");
	}
}

/**
 * 初始化下拉系统人员树
 * @param id
 * class:  easyui-combotree
 */
function _initComboRiskTree(id,isSys,cascadeCheck,callback){
	var url=rootpath+"/riskType/risk/tree.html";
	if(isSys!=undefined&&isSys!=null&&isSys!=""){ 
		url=rootpath+"/riskType/risk/tree.html";
	}
	lockSub();
	ajax(url,{},function(data){
		unlockSub();
		$('#'+id).combotree({
    		data:data,
    		editable:true,  //是否可以输入
    		cascadeCheck:cascadeCheck==undefined?false:cascadeCheck,//是否可以联机选
    		/*onClick : function(node) {
    			if(node.attributes.type!="user"){//如果不是用户就清除
    				$.messager.alert("警告!", "请选择人员", "warning");
    				$('#'+id).combotree('clear');
    			}
			},*/
    		/*onClick : function(node) {
    	    				$('#'+id).combotree('clear');   	    			
    				},*/
			onSelect:function(data){
    			if(callback!=undefined&&callback!=null&&callback!=""){
    				callback(data);
    				$('#'+id).combotree('clear');
    			}
//    			$('#'+id).combotree('clear');
    		}
    	});
	});
}
//提交页面的回调函数
function callback(result){
	result=JSON.parse(result);
	if(result.success){
		if($("#_id").val()!=null&&$("#_id").val()!=""){//修改的时间舒心页面显示信息
			var parentCode=$("#parentCode").val();
			var incode=$("#incode").val();
			_parent().getOrgan(parentCode+incode);
		}
		_parent().initTree();
		_closePage();
	}else{
		$.messager.alert("操作提示", result.msg, "error");
	}
}